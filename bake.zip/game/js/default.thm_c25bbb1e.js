window.skins=window.skins||{};
                var __extends = this && this.__extends|| function (d, b) {
                    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
                        function __() {
                            this.constructor = d;
                        }
                    __.prototype = b.prototype;
                    d.prototype = new __();
                };
                window.generateEUI = window.generateEUI||{};
                generateEUI.paths = generateEUI.paths||{};
                generateEUI.styles = undefined;
                generateEUI.skins = {"eui.Button":"resource/eui_skins/ButtonSkin.exml","eui.CheckBox":"resource/eui_skins/CheckBoxSkin.exml","eui.HScrollBar":"resource/eui_skins/HScrollBarSkin.exml","eui.HSlider":"resource/eui_skins/HSliderSkin.exml","eui.Panel":"resource/eui_skins/PanelSkin.exml","eui.TextInput":"resource/eui_skins/TextInputSkin.exml","eui.ProgressBar":"resource/eui_skins/ProgressBarSkin.exml","eui.RadioButton":"resource/eui_skins/RadioButtonSkin.exml","eui.Scroller":"resource/eui_skins/ScrollerSkin.exml","eui.ToggleSwitch":"resource/eui_skins/ToggleSwitchSkin.exml","eui.VScrollBar":"resource/eui_skins/VScrollBarSkin.exml","eui.VSlider":"resource/eui_skins/VSliderSkin.exml","eui.ItemRenderer":"resource/eui_skins/ItemRendererSkin.exml"};generateEUI.paths['resource/eui_skins/ButtonSkin.exml'] = window.skins.ButtonSkin = (function (_super) {
	__extends(ButtonSkin, _super);
	function ButtonSkin() {
		_super.call(this);
		this.skinParts = ["labelDisplay","iconDisplay"];
		
		this.minHeight = 50;
		this.minWidth = 100;
		this.elementsContent = [this._Image1_i(),this.labelDisplay_i(),this.iconDisplay_i()];
		this.states = [
			new eui.State ("up",
				[
				])
			,
			new eui.State ("down",
				[
					new eui.SetProperty("_Image1","source","button_down_png")
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("_Image1","alpha",0.5)
				])
		];
	}
	var _proto = ButtonSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.percentHeight = 100;
		t.scale9Grid = new egret.Rectangle(1,3,8,8);
		t.source = "button_up_png";
		t.percentWidth = 100;
		return t;
	};
	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.bottom = 8;
		t.left = 8;
		t.right = 8;
		t.size = 20;
		t.textAlign = "center";
		t.textColor = 0xFFFFFF;
		t.top = 8;
		t.verticalAlign = "middle";
		return t;
	};
	_proto.iconDisplay_i = function () {
		var t = new eui.Image();
		this.iconDisplay = t;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		return t;
	};
	return ButtonSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/CheckBoxSkin.exml'] = window.skins.CheckBoxSkin = (function (_super) {
	__extends(CheckBoxSkin, _super);
	function CheckBoxSkin() {
		_super.call(this);
		this.skinParts = ["labelDisplay"];
		
		this.elementsContent = [this._Group1_i()];
		this.states = [
			new eui.State ("up",
				[
				])
			,
			new eui.State ("down",
				[
					new eui.SetProperty("_Image1","alpha",0.7)
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("_Image1","alpha",0.5)
				])
			,
			new eui.State ("upAndSelected",
				[
					new eui.SetProperty("_Image1","source","checkbox_select_up_png")
				])
			,
			new eui.State ("downAndSelected",
				[
					new eui.SetProperty("_Image1","source","checkbox_select_down_png")
				])
			,
			new eui.State ("disabledAndSelected",
				[
					new eui.SetProperty("_Image1","source","checkbox_select_disabled_png")
				])
		];
	}
	var _proto = CheckBoxSkin.prototype;

	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.percentHeight = 100;
		t.percentWidth = 100;
		t.layout = this._HorizontalLayout1_i();
		t.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
		return t;
	};
	_proto._HorizontalLayout1_i = function () {
		var t = new eui.HorizontalLayout();
		t.verticalAlign = "middle";
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.alpha = 1;
		t.fillMode = "scale";
		t.source = "checkbox_unselect_png";
		return t;
	};
	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.fontFamily = "Tahoma";
		t.size = 20;
		t.textAlign = "center";
		t.textColor = 0x707070;
		t.verticalAlign = "middle";
		return t;
	};
	return CheckBoxSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/HScrollBarSkin.exml'] = window.skins.HScrollBarSkin = (function (_super) {
	__extends(HScrollBarSkin, _super);
	function HScrollBarSkin() {
		_super.call(this);
		this.skinParts = ["thumb"];
		
		this.minHeight = 8;
		this.minWidth = 20;
		this.elementsContent = [this.thumb_i()];
	}
	var _proto = HScrollBarSkin.prototype;

	_proto.thumb_i = function () {
		var t = new eui.Image();
		this.thumb = t;
		t.height = 8;
		t.scale9Grid = new egret.Rectangle(3,3,2,2);
		t.source = "roundthumb_png";
		t.verticalCenter = 0;
		t.width = 30;
		return t;
	};
	return HScrollBarSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/HSliderSkin.exml'] = window.skins.HSliderSkin = (function (_super) {
	__extends(HSliderSkin, _super);
	function HSliderSkin() {
		_super.call(this);
		this.skinParts = ["track","thumb"];
		
		this.minHeight = 8;
		this.minWidth = 20;
		this.elementsContent = [this.track_i(),this.thumb_i()];
	}
	var _proto = HSliderSkin.prototype;

	_proto.track_i = function () {
		var t = new eui.Image();
		this.track = t;
		t.height = 6;
		t.scale9Grid = new egret.Rectangle(1,1,4,4);
		t.source = "track_sb_png";
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto.thumb_i = function () {
		var t = new eui.Image();
		this.thumb = t;
		t.source = "thumb_png";
		t.verticalCenter = 0;
		return t;
	};
	return HSliderSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/ItemRendererSkin.exml'] = window.skins.ItemRendererSkin = (function (_super) {
	__extends(ItemRendererSkin, _super);
	function ItemRendererSkin() {
		_super.call(this);
		this.skinParts = ["labelDisplay"];
		
		this.minHeight = 50;
		this.minWidth = 100;
		this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
		this.states = [
			new eui.State ("up",
				[
				])
			,
			new eui.State ("down",
				[
					new eui.SetProperty("_Image1","source","button_down_png")
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("_Image1","alpha",0.5)
				])
		];
		
		eui.Binding.$bindProperties(this, ["hostComponent.data"],[0],this.labelDisplay,"text");
	}
	var _proto = ItemRendererSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.percentHeight = 100;
		t.scale9Grid = new egret.Rectangle(1,3,8,8);
		t.source = "button_up_png";
		t.percentWidth = 100;
		return t;
	};
	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.bottom = 8;
		t.fontFamily = "Tahoma";
		t.left = 8;
		t.right = 8;
		t.size = 20;
		t.textAlign = "center";
		t.textColor = 0xFFFFFF;
		t.top = 8;
		t.verticalAlign = "middle";
		return t;
	};
	return ItemRendererSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/PanelSkin.exml'] = window.skins.PanelSkin = (function (_super) {
	__extends(PanelSkin, _super);
	function PanelSkin() {
		_super.call(this);
		this.skinParts = ["titleDisplay","moveArea","closeButton"];
		
		this.minHeight = 230;
		this.minWidth = 450;
		this.elementsContent = [this._Image1_i(),this.moveArea_i(),this.closeButton_i()];
	}
	var _proto = PanelSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.scale9Grid = new egret.Rectangle(2,2,12,12);
		t.source = "border_png";
		t.top = 0;
		return t;
	};
	_proto.moveArea_i = function () {
		var t = new eui.Group();
		this.moveArea = t;
		t.height = 45;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.elementsContent = [this._Image2_i(),this.titleDisplay_i()];
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.source = "header_png";
		t.top = 0;
		return t;
	};
	_proto.titleDisplay_i = function () {
		var t = new eui.Label();
		this.titleDisplay = t;
		t.fontFamily = "Tahoma";
		t.left = 15;
		t.right = 5;
		t.size = 20;
		t.textColor = 0xFFFFFF;
		t.verticalCenter = 0;
		t.wordWrap = false;
		return t;
	};
	_proto.closeButton_i = function () {
		var t = new eui.Button();
		this.closeButton = t;
		t.bottom = 5;
		t.horizontalCenter = 0;
		t.label = "close";
		return t;
	};
	return PanelSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/ProgressBarSkin.exml'] = window.skins.ProgressBarSkin = (function (_super) {
	__extends(ProgressBarSkin, _super);
	function ProgressBarSkin() {
		_super.call(this);
		this.skinParts = ["thumb","labelDisplay"];
		
		this.minHeight = 18;
		this.minWidth = 30;
		this.elementsContent = [this._Image1_i(),this.thumb_i(),this.labelDisplay_i()];
	}
	var _proto = ProgressBarSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.percentHeight = 100;
		t.scale9Grid = new egret.Rectangle(1,1,4,4);
		t.source = "track_pb_png";
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto.thumb_i = function () {
		var t = new eui.Image();
		this.thumb = t;
		t.percentHeight = 100;
		t.source = "thumb_pb_png";
		t.percentWidth = 100;
		return t;
	};
	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.fontFamily = "Tahoma";
		t.horizontalCenter = 0;
		t.size = 15;
		t.textAlign = "center";
		t.textColor = 0x707070;
		t.verticalAlign = "middle";
		t.verticalCenter = 0;
		return t;
	};
	return ProgressBarSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/RadioButtonSkin.exml'] = window.skins.RadioButtonSkin = (function (_super) {
	__extends(RadioButtonSkin, _super);
	function RadioButtonSkin() {
		_super.call(this);
		this.skinParts = ["labelDisplay"];
		
		this.elementsContent = [this._Group1_i()];
		this.states = [
			new eui.State ("up",
				[
				])
			,
			new eui.State ("down",
				[
					new eui.SetProperty("_Image1","alpha",0.7)
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("_Image1","alpha",0.5)
				])
			,
			new eui.State ("upAndSelected",
				[
					new eui.SetProperty("_Image1","source","radiobutton_select_up_png")
				])
			,
			new eui.State ("downAndSelected",
				[
					new eui.SetProperty("_Image1","source","radiobutton_select_down_png")
				])
			,
			new eui.State ("disabledAndSelected",
				[
					new eui.SetProperty("_Image1","source","radiobutton_select_disabled_png")
				])
		];
	}
	var _proto = RadioButtonSkin.prototype;

	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.percentHeight = 100;
		t.percentWidth = 100;
		t.layout = this._HorizontalLayout1_i();
		t.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
		return t;
	};
	_proto._HorizontalLayout1_i = function () {
		var t = new eui.HorizontalLayout();
		t.verticalAlign = "middle";
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.alpha = 1;
		t.fillMode = "scale";
		t.source = "radiobutton_unselect_png";
		return t;
	};
	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.fontFamily = "Tahoma";
		t.size = 20;
		t.textAlign = "center";
		t.textColor = 0x707070;
		t.verticalAlign = "middle";
		return t;
	};
	return RadioButtonSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/ScrollerSkin.exml'] = window.skins.ScrollerSkin = (function (_super) {
	__extends(ScrollerSkin, _super);
	function ScrollerSkin() {
		_super.call(this);
		this.skinParts = ["horizontalScrollBar","verticalScrollBar"];
		
		this.minHeight = 20;
		this.minWidth = 20;
		this.elementsContent = [this.horizontalScrollBar_i(),this.verticalScrollBar_i()];
	}
	var _proto = ScrollerSkin.prototype;

	_proto.horizontalScrollBar_i = function () {
		var t = new eui.HScrollBar();
		this.horizontalScrollBar = t;
		t.bottom = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto.verticalScrollBar_i = function () {
		var t = new eui.VScrollBar();
		this.verticalScrollBar = t;
		t.percentHeight = 100;
		t.right = 0;
		return t;
	};
	return ScrollerSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/TextInputSkin.exml'] = window.skins.TextInputSkin = (function (_super) {
	__extends(TextInputSkin, _super);
	function TextInputSkin() {
		_super.call(this);
		this.skinParts = ["textDisplay","promptDisplay"];
		
		this.height = 100;
		this.minHeight = 40;
		this.minWidth = 300;
		this.elementsContent = [this._Image1_i(),this._Rect1_i(),this.textDisplay_i()];
		this.promptDisplay_i();
		
		this.states = [
			new eui.State ("normal",
				[
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("textDisplay","textColor",0xff0000)
				])
			,
			new eui.State ("normalWithPrompt",
				[
					new eui.AddItems("promptDisplay","",1,"")
				])
			,
			new eui.State ("disabledWithPrompt",
				[
					new eui.AddItems("promptDisplay","",1,"")
				])
		];
	}
	var _proto = TextInputSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.percentHeight = 100;
		t.scale9Grid = new egret.Rectangle(1,3,8,8);
		t.source = "button_up_png";
		t.percentWidth = 100;
		return t;
	};
	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.fillColor = 0xffffff;
		t.percentHeight = 100;
		t.percentWidth = 100;
		return t;
	};
	_proto.textDisplay_i = function () {
		var t = new eui.EditableText();
		this.textDisplay = t;
		t.bottom = "8";
		t.fontFamily = "norfolkBold";
		t.left = "10";
		t.right = "10";
		t.size = 31;
		t.text = "";
		t.textAlign = "center";
		t.textColor = 0x666666;
		t.top = "2";
		t.verticalAlign = "bottom";
		t.percentWidth = 100;
		return t;
	};
	_proto.promptDisplay_i = function () {
		var t = new eui.Label();
		this.promptDisplay = t;
		t.bottom = 8;
		t.fontFamily = "norfolkBold";
		t.left = 10;
		t.right = 10;
		t.size = 30;
		t.text = "";
		t.textAlign = "center";
		t.textColor = 0xa9a9a9;
		t.top = 2;
		t.touchEnabled = false;
		t.verticalAlign = "bottom";
		t.percentWidth = 100;
		return t;
	};
	return TextInputSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/ToggleSwitchSkin.exml'] = window.skins.ToggleSwitchSkin = (function (_super) {
	__extends(ToggleSwitchSkin, _super);
	function ToggleSwitchSkin() {
		_super.call(this);
		this.skinParts = [];
		
		this.elementsContent = [this._Image1_i(),this._Image2_i()];
		this.states = [
			new eui.State ("up",
				[
					new eui.SetProperty("_Image1","source","off_png")
				])
			,
			new eui.State ("down",
				[
					new eui.SetProperty("_Image1","source","off_png")
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("_Image1","source","off_png")
				])
			,
			new eui.State ("upAndSelected",
				[
					new eui.SetProperty("_Image2","horizontalCenter",18)
				])
			,
			new eui.State ("downAndSelected",
				[
					new eui.SetProperty("_Image2","horizontalCenter",18)
				])
			,
			new eui.State ("disabledAndSelected",
				[
					new eui.SetProperty("_Image2","horizontalCenter",18)
				])
		];
	}
	var _proto = ToggleSwitchSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.source = "on_png";
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		this._Image2 = t;
		t.horizontalCenter = -18;
		t.source = "handle_png";
		t.verticalCenter = 0;
		return t;
	};
	return ToggleSwitchSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/VScrollBarSkin.exml'] = window.skins.VScrollBarSkin = (function (_super) {
	__extends(VScrollBarSkin, _super);
	function VScrollBarSkin() {
		_super.call(this);
		this.skinParts = ["thumb"];
		
		this.minHeight = 20;
		this.minWidth = 8;
		this.elementsContent = [this.thumb_i()];
	}
	var _proto = VScrollBarSkin.prototype;

	_proto.thumb_i = function () {
		var t = new eui.Image();
		this.thumb = t;
		t.height = 30;
		t.horizontalCenter = 0;
		t.scale9Grid = new egret.Rectangle(3,3,2,2);
		t.source = "roundthumb_png";
		t.width = 8;
		return t;
	};
	return VScrollBarSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/VSliderSkin.exml'] = window.skins.VSliderSkin = (function (_super) {
	__extends(VSliderSkin, _super);
	function VSliderSkin() {
		_super.call(this);
		this.skinParts = ["track","thumb"];
		
		this.minHeight = 30;
		this.minWidth = 25;
		this.elementsContent = [this.track_i(),this.thumb_i()];
	}
	var _proto = VSliderSkin.prototype;

	_proto.track_i = function () {
		var t = new eui.Image();
		this.track = t;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.scale9Grid = new egret.Rectangle(1,1,4,4);
		t.source = "track_png";
		t.width = 7;
		return t;
	};
	_proto.thumb_i = function () {
		var t = new eui.Image();
		this.thumb = t;
		t.horizontalCenter = 0;
		t.source = "thumb_png";
		return t;
	};
	return VSliderSkin;
})(eui.Skin);generateEUI.paths['resource/eui/AdvertisementPage.exml'] = window.AdvertisementPage = (function (_super) {
	__extends(AdvertisementPage, _super);
	var AdvertisementPage$Skin1 = 	(function (_super) {
		__extends(AdvertisementPage$Skin1, _super);
		var AdvertisementPage$Skin1$Skin2 = 		(function (_super) {
			__extends(AdvertisementPage$Skin1$Skin2, _super);
			function AdvertisementPage$Skin1$Skin2() {
				_super.call(this);
				this.skinParts = ["thumb"];
				
				this.elementsContent = [this._Rect1_i(),this.thumb_i()];
			}
			var _proto = AdvertisementPage$Skin1$Skin2.prototype;

			_proto._Rect1_i = function () {
				var t = new eui.Rect();
				t.fillColor = 0x8FE09E;
				t.percentHeight = 100;
				t.percentWidth = 100;
				return t;
			};
			_proto.thumb_i = function () {
				var t = new eui.Rect();
				this.thumb = t;
				t.fillColor = 0xf5f5f5;
				t.height = 30;
				t.width = 20;
				return t;
			};
			return AdvertisementPage$Skin1$Skin2;
		})(eui.Skin);

		function AdvertisementPage$Skin1() {
			_super.call(this);
			this.skinParts = ["verticalScrollBar"];
			
			this.elementsContent = [this.verticalScrollBar_i()];
		}
		var _proto = AdvertisementPage$Skin1.prototype;

		_proto.verticalScrollBar_i = function () {
			var t = new eui.VScrollBar();
			this.verticalScrollBar = t;
			t.autoVisibility = false;
			t.percentHeight = 100;
			t.right = 5;
			t.width = 20;
			t.skinName = AdvertisementPage$Skin1$Skin2;
			return t;
		};
		return AdvertisementPage$Skin1;
	})(eui.Skin);

	function AdvertisementPage() {
		_super.call(this);
		this.skinParts = ["bg","banner","banner0","content","title","close"];
		
		this.height = 1392;
		this.width = 750;
		this.elementsContent = [this.bg_i(),this.banner_i(),this.banner0_i(),this._Image1_i(),this._Image2_i(),this._Scroller1_i(),this.title_i(),this._Image3_i(),this._Image4_i(),this.close_i()];
	}
	var _proto = AdvertisementPage.prototype;

	_proto.bg_i = function () {
		var t = new eui.Rect();
		this.bg = t;
		t.bottom = 0;
		t.fillAlpha = 0.01;
		t.fillColor = 0xffffff;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto.banner_i = function () {
		var t = new eui.Image();
		this.banner = t;
		t.anchorOffsetY = 0;
		t.horizontalCenter = 0;
		t.scale9Grid = new egret.Rectangle(243,338,240,177);
		t.source = "advertisement_bg_ch_png";
		t.verticalCenter = 0;
		t.visible = false;
		return t;
	};
	_proto.banner0_i = function () {
		var t = new eui.Image();
		this.banner0 = t;
		t.anchorOffsetY = 0;
		t.bottom = 240;
		t.horizontalCenter = 0;
		t.scale9Grid = new egret.Rectangle(243,338,240,177);
		t.source = "frame_bg_png";
		t.top = 240;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.source = "frame_close_png";
		t.top = 276;
		t.x = 653.82;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.anchorOffsetY = 0;
		t.bottom = 362;
		t.horizontalCenter = 0.5;
		t.source = "frame_txt_bg_png";
		t.top = 432;
		return t;
	};
	_proto._Scroller1_i = function () {
		var t = new eui.Scroller();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bottom = 395;
		t.scrollPolicyV = "on";
		t.top = 476;
		t.width = 617.55;
		t.x = 66;
		t.skinName = AdvertisementPage$Skin1;
		t.viewport = this._Group1_i();
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.elementsContent = [this.content_i()];
		return t;
	};
	_proto.content_i = function () {
		var t = new eui.Image();
		this.content = t;
		t.scaleX = 1.25;
		t.scaleY = 1.25;
		t.source = "frame_content_en_png";
		t.x = 19;
		t.y = 0;
		return t;
	};
	_proto.title_i = function () {
		var t = new eui.Image();
		this.title = t;
		t.source = "frame_title_en_png";
		t.x = 61;
		t.y = 382;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.right = 70;
		t.source = "frame_arrow_up_png";
		t.top = 450;
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.bottom = 374;
		t.right = 70;
		t.source = "frame_arrow_down_png";
		return t;
	};
	_proto.close_i = function () {
		var t = new eui.Rect();
		this.close = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillAlpha = 0;
		t.height = 80;
		t.width = 80;
		t.x = 635.82;
		t.y = 258;
		return t;
	};
	return AdvertisementPage;
})(eui.Skin);generateEUI.paths['resource/eui/BackBtn.exml'] = window.BackBtn = (function (_super) {
	__extends(BackBtn, _super);
	function BackBtn() {
		_super.call(this);
		this.skinParts = ["img"];
		
		this.height = 80;
		this.width = 80;
		this.elementsContent = [this._Rect1_i(),this.img_i()];
	}
	var _proto = BackBtn.prototype;

	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.bottom = 0;
		t.fillAlpha = 0.001;
		t.fillColor = 0xffffff;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.touchEnabled = false;
		return t;
	};
	_proto.img_i = function () {
		var t = new eui.Image();
		this.img = t;
		t.horizontalCenter = 0;
		t.source = "icon_back_png";
		t.touchEnabled = false;
		t.verticalCenter = 0;
		return t;
	};
	return BackBtn;
})(eui.Skin);generateEUI.paths['resource/eui/MyButton3Skin.exml'] = window.skins.MyButton3Skin = (function (_super) {
	__extends(MyButton3Skin, _super);
	function MyButton3Skin() {
		_super.call(this);
		this.skinParts = ["bg","labelDisplay","iconDisplay"];
		
		this.minHeight = 50;
		this.minWidth = 100;
		this.elementsContent = [this.bg_i(),this.labelDisplay_i(),this.iconDisplay_i()];
		this.states = [
			new eui.State ("up",
				[
					new eui.SetProperty("bg","fillColor",0x2db9b8)
				])
			,
			new eui.State ("down",
				[
					new eui.SetProperty("bg","fillColor",0x2db9b8),
					new eui.SetProperty("labelDisplay","textColor",0x1d7272)
				])
			,
			new eui.State ("disabled",
				[
				])
		];
	}
	var _proto = MyButton3Skin.prototype;

	_proto.bg_i = function () {
		var t = new eui.Rect();
		this.bg = t;
		t.ellipseHeight = 50;
		t.ellipseWidth = 50;
		t.fillColor = 0xff9604;
		t.percentHeight = 100;
		t.percentWidth = 100;
		return t;
	};
	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.bottom = 1;
		t.left = 22;
		t.right = 22;
		t.size = 28;
		t.text = "aa";
		t.textAlign = "center";
		t.textColor = 0xffffff;
		t.top = 1;
		t.verticalAlign = "middle";
		return t;
	};
	_proto.iconDisplay_i = function () {
		var t = new eui.Image();
		this.iconDisplay = t;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		return t;
	};
	return MyButton3Skin;
})(eui.Skin);generateEUI.paths['resource/eui/bzItem.exml'] = window.bzItem = (function (_super) {
	__extends(bzItem, _super);
	function bzItem() {
		_super.call(this);
		this.skinParts = ["t1","t2","btn"];
		
		this.height = 180;
		this.width = 250;
		this.elementsContent = [this._Group1_i(),this.t2_i(),this.btn_i()];
	}
	var _proto = bzItem.prototype;

	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.horizontalCenter = 0;
		t.y = 0;
		t.elementsContent = [this._Image1_i(),this.t1_i()];
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.source = "icon_certificate_max_png";
		t.touchEnabled = false;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.t1_i = function () {
		var t = new eui.Label();
		this.t1 = t;
		t.bold = true;
		t.fontFamily = "norfolkBold";
		t.size = 28;
		t.text = "0";
		t.textColor = 0xfe9601;
		t.touchEnabled = false;
		t.x = 58.1;
		t.y = 10;
		return t;
	};
	_proto.t2_i = function () {
		var t = new eui.Label();
		this.t2 = t;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.horizontalCenter = 0;
		t.size = 24;
		t.text = "";
		t.textColor = 0xffffff;
		t.touchEnabled = false;
		t.y = 72.69;
		return t;
	};
	_proto.btn_i = function () {
		var t = new eui.Button();
		this.btn = t;
		t.anchorOffsetX = 0;
		t.label = "Vote";
		t.name = "vote55";
		t.skinName = "skins.MyButton3Skin";
		t.width = 153;
		t.x = 48.5;
		t.y = 120.64;
		return t;
	};
	return bzItem;
})(eui.Skin);generateEUI.paths['resource/eui/ChatIcon.exml'] = window.ChatIcon = (function (_super) {
	__extends(ChatIcon, _super);
	function ChatIcon() {
		_super.call(this);
		this.skinParts = [];
		
		this.height = 83;
		this.width = 83;
		this.elementsContent = [this._Image1_i(),this._Image2_i()];
	}
	var _proto = ChatIcon.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.left = 0;
		t.source = "team_char_bg_png";
		t.top = 0;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "team_char_img_png";
		t.y = 17;
		return t;
	};
	return ChatIcon;
})(eui.Skin);generateEUI.paths['resource/eui/ComingUI.exml'] = window.ComingUI = (function (_super) {
	__extends(ComingUI, _super);
	function ComingUI() {
		_super.call(this);
		this.skinParts = ["content","image","close"];
		
		this.height = 1334;
		this.width = 750;
		this._TweenGroup1_i();
		this.elementsContent = [this._Rect1_i(),this._Image1_i(),this.content_i(),this.image_i(),this.close_i()];
		
		eui.Binding.$bindProperties(this, ["image"],[0],this._TweenItem1,"target");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object1,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object1,"rotation");
		eui.Binding.$bindProperties(this, [1.2],[],this._Object1,"scaleX");
		eui.Binding.$bindProperties(this, [1.2],[],this._Object1,"scaleY");
		eui.Binding.$bindProperties(this, [1],[],this._Object2,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object2,"rotation");
		eui.Binding.$bindProperties(this, [1.4],[],this._Object2,"scaleX");
		eui.Binding.$bindProperties(this, [1.4],[],this._Object2,"scaleY");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object3,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object3,"rotation");
		eui.Binding.$bindProperties(this, [1.2],[],this._Object3,"scaleX");
		eui.Binding.$bindProperties(this, [1.2],[],this._Object3,"scaleY");
	}
	var _proto = ComingUI.prototype;

	_proto._TweenGroup1_i = function () {
		var t = new egret.tween.TweenGroup();
		t.items = [this._TweenItem1_i()];
		return t;
	};
	_proto._TweenItem1_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem1 = t;
		t.paths = [this._Set1_i(),this._To1_i(),this._To2_i()];
		return t;
	};
	_proto._Set1_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object1_i();
		return t;
	};
	_proto._Object1_i = function () {
		var t = {};
		this._Object1 = t;
		return t;
	};
	_proto._To1_i = function () {
		var t = new egret.tween.To();
		t.duration = 2000;
		t.ease = "circIn";
		t.props = this._Object2_i();
		return t;
	};
	_proto._Object2_i = function () {
		var t = {};
		this._Object2 = t;
		return t;
	};
	_proto._To2_i = function () {
		var t = new egret.tween.To();
		t.duration = 2000;
		t.ease = "circOut";
		t.props = this._Object3_i();
		return t;
	};
	_proto._Object3_i = function () {
		var t = {};
		this._Object3 = t;
		return t;
	};
	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.bottom = 0;
		t.fillAlpha = 0.05;
		t.fillColor = 0xffffff;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.height = 323;
		t.horizontalCenter = 0;
		t.scale9Grid = new egret.Rectangle(88,76,533,461);
		t.source = "mainv_img5_png";
		t.y = 516;
		return t;
	};
	_proto.content_i = function () {
		var t = new eui.Label();
		this.content = t;
		t.anchorOffsetX = 0;
		t.fontFamily = "norfolk";
		t.horizontalCenter = 0;
		t.size = 32;
		t.text = "Coming Soon";
		t.textAlign = "center";
		t.textColor = 0x7f93b4;
		t.width = 282;
		t.y = 650;
		return t;
	};
	_proto.image_i = function () {
		var t = new eui.Image();
		this.image = t;
		t.anchorOffsetX = 138.5;
		t.anchorOffsetY = 89;
		t.scaleX = 1.4;
		t.scaleY = 1.4;
		t.source = "coming_img_bg_png";
		t.x = 367;
		t.y = 666;
		return t;
	};
	_proto.close_i = function () {
		var t = new eui.Image();
		this.close = t;
		t.height = 35;
		t.source = "icon_close_png";
		t.width = 35;
		t.x = 650;
		t.y = 540;
		return t;
	};
	return ComingUI;
})(eui.Skin);generateEUI.paths['resource/eui/commLoading.exml'] = window.commLoading = (function (_super) {
	__extends(commLoading, _super);
	function commLoading() {
		_super.call(this);
		this.skinParts = ["imgLoading"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this._Rect1_i(),this.imgLoading_i()];
	}
	var _proto = commLoading.prototype;

	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.bottom = 0;
		t.fillAlpha = 0.15;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto.imgLoading_i = function () {
		var t = new eui.Image();
		this.imgLoading = t;
		t.anchorOffsetX = 100.5;
		t.anchorOffsetY = 100.5;
		t.horizontalCenter = 0;
		t.source = "tool_loading_max_png";
		t.verticalCenter = 0;
		return t;
	};
	return commLoading;
})(eui.Skin);generateEUI.paths['resource/eui/ContactusPage.exml'] = window.ContactusPage = (function (_super) {
	__extends(ContactusPage, _super);
	function ContactusPage() {
		_super.call(this);
		this.skinParts = ["back","btn1","btn2","btn3","content","title"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this._Rect1_i(),this._Image1_i(),this.back_i(),this._Image3_i(),this._Rect3_i(),this.btn1_i(),this.btn2_i(),this.btn3_i(),this.content_i(),this.title_i()];
	}
	var _proto = ContactusPage.prototype;

	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.bottom = 0;
		t.fillColor = 0xFFFFFF;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0.5;
		t.source = "contactus_title_png";
		t.visible = false;
		t.y = 65.2;
		return t;
	};
	_proto.back_i = function () {
		var t = new eui.Group();
		this.back = t;
		t.height = 80;
		t.x = 8.03;
		t.y = 25;
		t.elementsContent = [this._Rect2_i(),this._Image2_i()];
		return t;
	};
	_proto._Rect2_i = function () {
		var t = new eui.Rect();
		t.fillColor = 0xFFFFFF;
		t.height = 80;
		t.width = 80;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "icon_back22_png";
		t.verticalCenter = 0;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 443;
		t.horizontalCenter = 0;
		t.source = "contactus_content_png";
		t.verticalCenter = 36;
		return t;
	};
	_proto._Rect3_i = function () {
		var t = new eui.Rect();
		t.anchorOffsetY = 0;
		t.fillColor = 0xffffff;
		t.height = 77.34;
		t.horizontalCenter = 0;
		t.verticalCenter = -140.5;
		t.width = 750;
		return t;
	};
	_proto.btn1_i = function () {
		var t = new eui.Rect();
		this.btn1 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillAlpha = 0;
		t.fillColor = 0xFFFFFF;
		t.height = 200;
		t.horizontalCenter = 0;
		t.verticalCenter = -300;
		t.width = 600;
		return t;
	};
	_proto.btn2_i = function () {
		var t = new eui.Rect();
		this.btn2 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillAlpha = 0;
		t.fillColor = 0xFFFFFF;
		t.height = 200;
		t.horizontalCenter = 0;
		t.verticalCenter = 30;
		t.width = 600;
		return t;
	};
	_proto.btn3_i = function () {
		var t = new eui.Rect();
		this.btn3 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillAlpha = 0;
		t.fillColor = 0xFFFFFF;
		t.height = 200;
		t.horizontalCenter = 0;
		t.verticalCenter = 366;
		t.width = 600;
		return t;
	};
	_proto.content_i = function () {
		var t = new eui.Label();
		this.content = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.height = 75.34;
		t.horizontalCenter = -0.5;
		t.lineSpacing = 6;
		t.size = 18;
		t.text = "If you have ANY QUESTIONS, PLEASE CONTACE US BY EMAIL. WE WILL SOLVE YOUR PROBLEMS AS SOON AS POSSIBLE";
		t.textAlign = "center";
		t.textColor = 0x8c8da3;
		t.verticalAlign = "top";
		t.verticalCenter = -138.5;
		t.width = 591.34;
		return t;
	};
	_proto.title_i = function () {
		var t = new eui.Label();
		this.title = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolkBold";
		t.horizontalCenter = -0.5;
		t.lineSpacing = 6;
		t.size = 48;
		t.text = "Contact us";
		t.textAlign = "center";
		t.textColor = 0x5969af;
		t.verticalAlign = "top";
		t.width = 591.34;
		t.y = 41;
		return t;
	};
	return ContactusPage;
})(eui.Skin);generateEUI.paths['resource/eui/DownSBAlert.exml'] = window.DownSBAlert = (function (_super) {
	__extends(DownSBAlert, _super);
	var DownSBAlert$Skin3 = 	(function (_super) {
		__extends(DownSBAlert$Skin3, _super);
		function DownSBAlert$Skin3() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","d_btn_cancel_off_png")
					])
				,
				new eui.State ("disabled",
					[
						new eui.SetProperty("_Image1","source","d_btn_cancel_off_png")
					])
			];
		}
		var _proto = DownSBAlert$Skin3.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.percentHeight = 100;
			t.source = "d_btn_cancel_on_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return DownSBAlert$Skin3;
	})(eui.Skin);

	var DownSBAlert$Skin4 = 	(function (_super) {
		__extends(DownSBAlert$Skin4, _super);
		function DownSBAlert$Skin4() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","d_btn_open_off_png")
					])
				,
				new eui.State ("disabled",
					[
						new eui.SetProperty("_Image1","source","d_btn_open_off_png")
					])
			];
		}
		var _proto = DownSBAlert$Skin4.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.percentHeight = 100;
			t.source = "d_btn_open_on_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return DownSBAlert$Skin4;
	})(eui.Skin);

	var DownSBAlert$Skin5 = 	(function (_super) {
		__extends(DownSBAlert$Skin5, _super);
		function DownSBAlert$Skin5() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","d_btn_install_off_png")
					])
				,
				new eui.State ("disabled",
					[
						new eui.SetProperty("_Image1","source","d_btn_install_off_png")
					])
			];
		}
		var _proto = DownSBAlert$Skin5.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.percentHeight = 100;
			t.source = "d_btn_install_on_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return DownSBAlert$Skin5;
	})(eui.Skin);

	function DownSBAlert() {
		_super.call(this);
		this.skinParts = ["bg","contents","account_warn","account_warn0","close_btn","cancelBtn","openBtn","installBtn"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this.bg_i(),this._Image1_i(),this.contents_i(),this.account_warn_i(),this.account_warn0_i(),this.close_btn_i(),this.cancelBtn_i(),this.openBtn_i(),this.installBtn_i()];
	}
	var _proto = DownSBAlert.prototype;

	_proto.bg_i = function () {
		var t = new eui.Rect();
		this.bg = t;
		t.bottom = 0;
		t.fillAlpha = 0.3;
		t.fillColor = 0x617ebd;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.anchorOffsetY = 0;
		t.height = 374;
		t.horizontalCenter = 0.5;
		t.scale9Grid = new egret.Rectangle(88,76,533,461);
		t.source = "mainv_img5_png";
		t.y = 529;
		return t;
	};
	_proto.contents_i = function () {
		var t = new eui.Label();
		this.contents = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.horizontalCenter = 0;
		t.lineSpacing = 5;
		t.size = 36;
		t.text = "Open Cyber Space?";
		t.textAlign = "center";
		t.textColor = 0x617ebd;
		t.verticalAlign = "top";
		t.width = 600;
		t.y = 720.28;
		return t;
	};
	_proto.account_warn_i = function () {
		var t = new eui.Image();
		this.account_warn = t;
		t.scaleX = 0.3;
		t.scaleY = 0.3;
		t.source = "reg2_txt_title_png";
		t.x = 51;
		t.y = 549;
		return t;
	};
	_proto.account_warn0_i = function () {
		var t = new eui.Image();
		this.account_warn0 = t;
		t.horizontalCenter = 0;
		t.source = "empower_img2_png";
		t.y = 578;
		return t;
	};
	_proto.close_btn_i = function () {
		var t = new eui.Group();
		this.close_btn = t;
		t.x = 636;
		t.y = 533.73;
		t.elementsContent = [this._Rect1_i(),this._Image2_i()];
		return t;
	};
	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.ellipseHeight = 100;
		t.ellipseWidth = 100;
		t.fillColor = 0xFFFFFF;
		t.height = 80;
		t.width = 80;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.source = "icon_close_png";
		t.x = 25;
		t.y = 25;
		return t;
	};
	_proto.cancelBtn_i = function () {
		var t = new eui.Button();
		this.cancelBtn = t;
		t.label = "";
		t.x = 206;
		t.y = 800;
		t.skinName = DownSBAlert$Skin3;
		return t;
	};
	_proto.openBtn_i = function () {
		var t = new eui.Button();
		this.openBtn = t;
		t.label = "";
		t.right = 206;
		t.y = 800;
		t.skinName = DownSBAlert$Skin4;
		return t;
	};
	_proto.installBtn_i = function () {
		var t = new eui.Button();
		this.installBtn = t;
		t.horizontalCenter = 0;
		t.label = "";
		t.y = 800;
		t.skinName = DownSBAlert$Skin5;
		return t;
	};
	return DownSBAlert;
})(eui.Skin);generateEUI.paths['resource/eui/EmpowerPage.exml'] = window.EmpowerPage = (function (_super) {
	__extends(EmpowerPage, _super);
	var EmpowerPage$Skin6 = 	(function (_super) {
		__extends(EmpowerPage$Skin6, _super);
		function EmpowerPage$Skin6() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","confirm_btn_off_png"),
						new eui.SetProperty("labelDisplay","textColor",0xf8b43d)
					])
				,
				new eui.State ("disabled",
					[
						new eui.SetProperty("_Image1","source","confirm_btn_off_png")
					])
			];
		}
		var _proto = EmpowerPage$Skin6.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.percentHeight = 100;
			t.source = "confirm_btn_on_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.bold = true;
			t.fontFamily = "norfolk";
			t.horizontalCenter = 0;
			t.size = 36;
			t.textColor = 0xFFFFFF;
			t.verticalCenter = -8;
			return t;
		};
		return EmpowerPage$Skin6;
	})(eui.Skin);

	function EmpowerPage() {
		_super.call(this);
		this.skinParts = ["bg","backBtn","title","txt1","acc","txt2","t1","t2","t3","t4","txt3","txt4","t5","agreeBtn","tool_loading","loadPane"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this.bg_i(),this.backBtn_i(),this.title_i(),this.txt1_i(),this.acc_i(),this.txt2_i(),this.t1_i(),this.t2_i(),this.t3_i(),this.t4_i(),this.txt3_i(),this.txt4_i(),this._Image1_i(),this._Image2_i(),this._Image3_i(),this.t5_i(),this.agreeBtn_i(),this.loadPane_i()];
	}
	var _proto = EmpowerPage.prototype;

	_proto.bg_i = function () {
		var t = new eui.Rect();
		this.bg = t;
		t.bottom = 0;
		t.fillColor = 0xffffff;
		t.left = 0;
		t.right = 0;
		t.strokeColor = 0xffffff;
		t.top = 0;
		return t;
	};
	_proto.backBtn_i = function () {
		var t = new eui.Component();
		this.backBtn = t;
		t.height = 80;
		t.skinName = "BackBtn";
		t.width = 80;
		t.x = 12.84;
		t.y = 25.14;
		return t;
	};
	_proto.title_i = function () {
		var t = new eui.Label();
		this.title = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolkBold";
		t.horizontalCenter = 0;
		t.size = 48;
		t.text = "Authorization";
		t.textColor = 0x375591;
		t.y = 45;
		return t;
	};
	_proto.txt1_i = function () {
		var t = new eui.Label();
		this.txt1 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.size = 30;
		t.text = "GL Planet ID:  ";
		t.textAlign = "right";
		t.textColor = 0x375591;
		t.width = 285;
		t.x = 67;
		t.y = 426;
		return t;
	};
	_proto.acc_i = function () {
		var t = new eui.Label();
		this.acc = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.size = 30;
		t.text = " 460****76@qq.com  ";
		t.textColor = 0x72b1d2;
		t.x = 361;
		t.y = 426;
		return t;
	};
	_proto.txt2_i = function () {
		var t = new eui.Label();
		this.txt2 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.size = 30;
		t.text = "Agree to authorize ";
		t.textAlign = "left";
		t.textColor = 0x375591;
		t.verticalAlign = "bottom";
		t.x = 50;
		t.y = 506;
		return t;
	};
	_proto.t1_i = function () {
		var t = new eui.Label();
		this.t1 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.size = 30;
		t.text = "the";
		t.textColor = 0x375591;
		t.visible = false;
		t.x = 50;
		t.y = 557;
		return t;
	};
	_proto.t2_i = function () {
		var t = new eui.Label();
		this.t2 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.height = 40;
		t.size = 36;
		t.text = " GL Planet";
		t.textColor = 0x72B1D2;
		t.verticalAlign = "bottom";
		t.visible = false;
		t.x = 102.55;
		t.y = 547;
		return t;
	};
	_proto.t3_i = function () {
		var t = new eui.Label();
		this.t3 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.height = 40;
		t.size = 30;
		t.text = " ID info to";
		t.textColor = 0x375591;
		t.verticalAlign = "bottom";
		t.visible = false;
		t.x = 276.94;
		t.y = 547;
		return t;
	};
	_proto.t4_i = function () {
		var t = new eui.Label();
		this.t4 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.height = 40;
		t.size = 36;
		t.text = " Cyber Space";
		t.textColor = 0x72B1D2;
		t.verticalAlign = "bottom";
		t.visible = false;
		t.x = 411.87;
		t.y = 547;
		return t;
	};
	_proto.txt3_i = function () {
		var t = new eui.Label();
		this.txt3 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.size = 30;
		t.text = "• Get your login status";
		t.textAlign = "left";
		t.textColor = 0xbdbdbd;
		t.x = 50;
		t.y = 668;
		return t;
	};
	_proto.txt4_i = function () {
		var t = new eui.Label();
		this.txt4 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.size = 30;
		t.text = "• Get your public info & ID info";
		t.textAlign = "left";
		t.textColor = 0xBDBDBD;
		t.x = 50;
		t.y = 719;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.source = "empower_img1_png";
		t.x = 160;
		t.y = 238;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.right = 160;
		t.source = "empower_img2_png";
		t.y = 238;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0.5;
		t.source = "empower_img3_png";
		t.y = 283;
		return t;
	};
	_proto.t5_i = function () {
		var t = new eui.Label();
		this.t5 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.bottom = 349;
		t.fontFamily = "norfolk";
		t.horizontalCenter = 0;
		t.size = 30;
		t.text = "";
		t.textAlign = "center";
		t.textColor = 0xBDBDBD;
		t.width = 750;
		return t;
	};
	_proto.agreeBtn_i = function () {
		var t = new eui.Button();
		this.agreeBtn = t;
		t.bottom = 199;
		t.horizontalCenter = 0;
		t.label = "Comfirm";
		t.skinName = EmpowerPage$Skin6;
		return t;
	};
	_proto.loadPane_i = function () {
		var t = new eui.Group();
		this.loadPane = t;
		t.bottom = 218;
		t.horizontalCenter = 0;
		t.visible = false;
		t.elementsContent = [this._Rect1_i(),this.tool_loading_i()];
		return t;
	};
	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.ellipseHeight = 90;
		t.ellipseWidth = 90;
		t.fillColor = 0xbfbfbf;
		t.height = 80;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.strokeColor = 0xffffff;
		t.width = 299.5;
		t.y = 0;
		return t;
	};
	_proto.tool_loading_i = function () {
		var t = new eui.Image();
		this.tool_loading = t;
		t.anchorOffsetX = 25;
		t.anchorOffsetY = 26;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "tool_loading_png";
		t.verticalCenter = 0;
		return t;
	};
	return EmpowerPage;
})(eui.Skin);generateEUI.paths['resource/eui/FriendItem.exml'] = window.FriendItem = (function (_super) {
	__extends(FriendItem, _super);
	function FriendItem() {
		_super.call(this);
		this.skinParts = ["icon","total","totalf","nickname"];
		
		this.height = 102;
		this.width = 715;
		this.elementsContent = [this._Rect1_i(),this.icon_i(),this._Image1_i(),this.total_i(),this.totalf_i(),this.nickname_i()];
	}
	var _proto = FriendItem.prototype;

	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.bottom = 0;
		t.fillColor = 0xffffff;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto.icon_i = function () {
		var t = new eui.Image();
		this.icon = t;
		t.source = "icon_heard_img1_png";
		t.verticalCenter = 0;
		t.x = 52;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.right = 52;
		t.source = "friend_item_add_png";
		t.verticalCenter = 0;
		return t;
	};
	_proto.total_i = function () {
		var t = new eui.Label();
		this.total = t;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.size = 22;
		t.text = "100.000t/h";
		t.textColor = 0x9a9a9a;
		t.x = 180;
		t.y = 29;
		return t;
	};
	_proto.totalf_i = function () {
		var t = new eui.Label();
		this.totalf = t;
		t.anchorOffsetX = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.size = 18;
		t.text = "100.000t/h+100.000t/h";
		t.textColor = 0xcbcbcb;
		t.width = 272;
		t.x = 180;
		t.y = 61;
		return t;
	};
	_proto.nickname_i = function () {
		var t = new eui.Label();
		this.nickname = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.height = 35;
		t.size = 28;
		t.text = "dear";
		t.textAlign = "left";
		t.textColor = 0x000000;
		t.verticalAlign = "middle";
		t.verticalCenter = 0.5;
		t.width = 203;
		t.x = 409;
		return t;
	};
	return FriendItem;
})(eui.Skin);generateEUI.paths['resource/eui/FriendsUI.exml'] = window.FriendsUI = (function (_super) {
	__extends(FriendsUI, _super);
	function FriendsUI() {
		_super.call(this);
		this.skinParts = ["back","t1","upimg","updata","slide_bar","slide","group1","pane","t2","t3","t4"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this._Rect1_i(),this.back_i(),this.t1_i(),this.updata_i(),this.slide_i(),this.pane_i(),this.t2_i(),this.t3_i(),this.t4_i()];
	}
	var _proto = FriendsUI.prototype;

	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.bottom = 0;
		t.fillColor = 0xffffff;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto.back_i = function () {
		var t = new eui.Component();
		this.back = t;
		t.skinName = "BackBtn";
		t.x = 11.69;
		t.y = 25;
		return t;
	};
	_proto.t1_i = function () {
		var t = new eui.Label();
		this.t1 = t;
		t.anchorOffsetX = 0;
		t.bold = true;
		t.fontFamily = "norfolkBold";
		t.horizontalCenter = 0;
		t.size = 36;
		t.text = "TEAM MEMBER";
		t.textAlign = "center";
		t.textColor = 0x000000;
		t.width = 360;
		t.y = 49;
		return t;
	};
	_proto.updata_i = function () {
		var t = new eui.Group();
		this.updata = t;
		t.x = 647;
		t.y = 42;
		t.elementsContent = [this._Rect2_i(),this.upimg_i()];
		return t;
	};
	_proto._Rect2_i = function () {
		var t = new eui.Rect();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillColor = 0xffffff;
		t.height = 62;
		t.width = 62;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.upimg_i = function () {
		var t = new eui.Image();
		this.upimg = t;
		t.anchorOffsetX = 17;
		t.anchorOffsetY = 18;
		t.horizontalCenter = 0;
		t.source = "icon_updata_png";
		t.verticalCenter = 0;
		return t;
	};
	_proto.slide_i = function () {
		var t = new eui.Group();
		this.slide = t;
		t.bottom = 197;
		t.right = 33;
		t.top = 175;
		t.visible = false;
		t.elementsContent = [this._Image1_i(),this.slide_bar_i()];
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.bottom = 0;
		t.source = "tool_slide_bg_png";
		t.top = 0;
		t.x = 0;
		return t;
	};
	_proto.slide_bar_i = function () {
		var t = new eui.Image();
		this.slide_bar = t;
		t.source = "tool_slide_bar_png";
		t.x = 0;
		t.y = 365.24;
		return t;
	};
	_proto.pane_i = function () {
		var t = new eui.Scroller();
		this.pane = t;
		t.anchorOffsetY = 0;
		t.bottom = 180;
		t.left = 0;
		t.right = 0;
		t.top = 124;
		t.viewport = this.group1_i();
		return t;
	};
	_proto.group1_i = function () {
		var t = new eui.Group();
		this.group1 = t;
		t.width = 750;
		return t;
	};
	_proto.t2_i = function () {
		var t = new eui.Label();
		this.t2 = t;
		t.anchorOffsetX = 0;
		t.bottom = 120;
		t.fontFamily = "norfolk";
		t.right = 0;
		t.size = 24;
		t.text = " too many registrations,";
		t.textAlign = "center";
		t.textColor = 0xb9b9b9;
		t.width = 750;
		return t;
	};
	_proto.t3_i = function () {
		var t = new eui.Label();
		this.t3 = t;
		t.anchorOffsetX = 0;
		t.bottom = 83;
		t.fontFamily = "norfolk";
		t.height = 30;
		t.horizontalCenter = 0;
		t.size = 26;
		t.text = " 5 levels users ";
		t.textAlign = "left";
		t.textColor = 0xfbc861;
		t.verticalAlign = "bottom";
		return t;
	};
	_proto.t4_i = function () {
		var t = new eui.Label();
		this.t4 = t;
		t.anchorOffsetX = 0;
		t.bottom = 53;
		t.fontFamily = "norfolk";
		t.size = 18;
		t.text = "THE MORE FRIENDS YOU INVITED, HIGHER SPEED YOU CAN GET";
		t.textAlign = "center";
		t.textColor = 0xB9B9B9;
		t.width = 750;
		t.x = 0;
		return t;
	};
	return FriendsUI;
})(eui.Skin);generateEUI.paths['resource/eui/GIPItem.exml'] = window.GIPItem = (function (_super) {
	__extends(GIPItem, _super);
	var GIPItem$Skin7 = 	(function (_super) {
		__extends(GIPItem$Skin7, _super);
		function GIPItem$Skin7() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","gip_p3_btn_bg2_png"),
						new eui.SetProperty("_Image1","alpha",0.7)
					])
				,
				new eui.State ("disabled",
					[
						new eui.SetProperty("_Image1","source","gip_p3_btn_bg2_png")
					])
			];
		}
		var _proto = GIPItem$Skin7.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.percentHeight = 100;
			t.source = "gip_p3_btn_bg2_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.size = 20;
			t.textColor = 0xef3e34;
			t.verticalCenter = 0;
			return t;
		};
		return GIPItem$Skin7;
	})(eui.Skin);

	var GIPItem$Skin8 = 	(function (_super) {
		__extends(GIPItem$Skin8, _super);
		function GIPItem$Skin8() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","gip_p3_btn_bg3_png"),
						new eui.SetProperty("_Image1","alpha",0.7)
					])
				,
				new eui.State ("disabled",
					[
						new eui.SetProperty("_Image1","source","gip_p3_btn_bg3_png")
					])
			];
		}
		var _proto = GIPItem$Skin8.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.percentHeight = 100;
			t.source = "gip_p3_btn_bg3_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.size = 20;
			t.textColor = 0x2db9b9;
			t.verticalCenter = 0;
			return t;
		};
		return GIPItem$Skin8;
	})(eui.Skin);

	function GIPItem() {
		_super.call(this);
		this.skinParts = ["title","account","amount_t","amount","fee_t","fee","earned_t","earned","btn2","btn1"];
		
		this.height = 246;
		this.width = 669;
		this.elementsContent = [this._Image1_i(),this._Group1_i(),this.account_i(),this.amount_t_i(),this.amount_i(),this.fee_t_i(),this.fee_i(),this.earned_t_i(),this.earned_i(),this.btn2_i(),this.btn1_i()];
	}
	var _proto = GIPItem.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.source = "gip_p3_list_item_bg_png";
		t.x = 0;
		t.y = 26;
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.x = 77;
		t.y = 1.5;
		t.elementsContent = [this._Image2_i(),this.title_i()];
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.bottom = 0;
		t.left = -30;
		t.right = -30;
		t.scale9Grid = new egret.Rectangle(40,8,245,50);
		t.source = "gip_p3_list_title_bg_png";
		t.top = 0;
		return t;
	};
	_proto.title_i = function () {
		var t = new eui.Label();
		this.title = t;
		t.anchorOffsetY = 0;
		t.height = 50;
		t.horizontalCenter = 0;
		t.size = 24;
		t.text = "Reject countd";
		t.textAlign = "center";
		t.verticalAlign = "middle";
		t.y = 5;
		return t;
	};
	_proto.account_i = function () {
		var t = new eui.Label();
		this.account = t;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolkBold";
		t.size = 24;
		t.text = "4608871*******";
		t.textColor = 0x759de2;
		t.verticalAlign = "middle";
		t.x = 49;
		t.y = 79;
		return t;
	};
	_proto.amount_t_i = function () {
		var t = new eui.Label();
		this.amount_t = t;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolkBold";
		t.size = 24;
		t.text = "Withdrawal amount : ";
		t.textColor = 0xbcbcbc;
		t.verticalAlign = "middle";
		t.x = 49;
		t.y = 117;
		return t;
	};
	_proto.amount_i = function () {
		var t = new eui.Label();
		this.amount = t;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolkBold";
		t.size = 24;
		t.text = "10000 GL";
		t.textColor = 0x2db9b9;
		t.verticalAlign = "middle";
		t.x = 259;
		t.y = 117;
		return t;
	};
	_proto.fee_t_i = function () {
		var t = new eui.Label();
		this.fee_t = t;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolkBold";
		t.size = 24;
		t.text = "Custom fee : ";
		t.textColor = 0xbcbcbc;
		t.verticalAlign = "middle";
		t.x = 49;
		t.y = 153;
		return t;
	};
	_proto.fee_i = function () {
		var t = new eui.Label();
		this.fee = t;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolkBold";
		t.size = 24;
		t.text = "20%";
		t.textColor = 0x759de2;
		t.verticalAlign = "middle";
		t.x = 189;
		t.y = 153;
		return t;
	};
	_proto.earned_t_i = function () {
		var t = new eui.Label();
		this.earned_t = t;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolkBold";
		t.size = 24;
		t.text = "Earned GL : ";
		t.textColor = 0xbcbcbc;
		t.verticalAlign = "middle";
		t.x = 49;
		t.y = 188.5;
		return t;
	};
	_proto.earned_i = function () {
		var t = new eui.Label();
		this.earned = t;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolkBold";
		t.size = 24;
		t.text = "900";
		t.textColor = 0x759de2;
		t.verticalAlign = "middle";
		t.x = 193;
		t.y = 188.5;
		return t;
	};
	_proto.btn2_i = function () {
		var t = new eui.Button();
		this.btn2 = t;
		t.label = "Reject";
		t.name = "node_btn2";
		t.x = 464;
		t.y = 147;
		t.skinName = GIPItem$Skin7;
		return t;
	};
	_proto.btn1_i = function () {
		var t = new eui.Button();
		this.btn1 = t;
		t.label = "Reject";
		t.name = "node_btn1";
		t.x = 464;
		t.y = 69;
		t.skinName = GIPItem$Skin8;
		return t;
	};
	return GIPItem;
})(eui.Skin);generateEUI.paths['resource/eui/GIPP1.exml'] = window.GIPP1 = (function (_super) {
	__extends(GIPP1, _super);
	var GIPP1$Skin9 = 	(function (_super) {
		__extends(GIPP1$Skin9, _super);
		function GIPP1$Skin9() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","gip_p1_btn1_png"),
						new eui.SetProperty("_Image1","alpha",0.7),
						new eui.SetProperty("_Image1","percentHeight",100)
					])
				,
				new eui.State ("disabled",
					[
						new eui.SetProperty("_Image1","source","gip_p1_btn1_png")
					])
			];
		}
		var _proto = GIPP1$Skin9.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.percentHeight = 100;
			t.left = -20;
			t.right = -20;
			t.scale9Grid = new egret.Rectangle(33,8,139,43);
			t.source = "gip_p1_btn1_png";
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.text = "fasdfas";
			t.verticalCenter = -5;
			return t;
		};
		return GIPP1$Skin9;
	})(eui.Skin);

	var GIPP1$Skin10 = 	(function (_super) {
		__extends(GIPP1$Skin10, _super);
		function GIPP1$Skin10() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","gip_p1_btn2_png"),
						new eui.SetProperty("_Image1","alpha",0.7)
					])
				,
				new eui.State ("disabled",
					[
						new eui.SetProperty("_Image1","source","gip_p1_btn2_png")
					])
			];
		}
		var _proto = GIPP1$Skin10.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.percentHeight = 100;
			t.source = "gip_p1_btn2_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.fontFamily = "norfolk";
			t.horizontalCenter = 0;
			t.size = 20;
			t.text = "";
			t.textColor = 0xfdc54a;
			t.verticalAlign = "middle";
			t.verticalCenter = -4;
			return t;
		};
		return GIPP1$Skin10;
	})(eui.Skin);

	var GIPP1$Skin11 = 	(function (_super) {
		__extends(GIPP1$Skin11, _super);
		function GIPP1$Skin11() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","gip_p1_btn3_png"),
						new eui.SetProperty("_Image1","alpha",0.7)
					])
				,
				new eui.State ("disabled",
					[
						new eui.SetProperty("_Image1","source","gip_p1_btn3_png")
					])
			];
		}
		var _proto = GIPP1$Skin11.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.percentHeight = 100;
			t.source = "gip_p1_btn3_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.fontFamily = "norfolkBold";
			t.horizontalCenter = 0;
			t.verticalCenter = 18.5;
			return t;
		};
		return GIPP1$Skin11;
	})(eui.Skin);

	var GIPP1$Skin12 = 	(function (_super) {
		__extends(GIPP1$Skin12, _super);
		function GIPP1$Skin12() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","gip_p1_btn4_png"),
						new eui.SetProperty("_Image1","alpha",0.7)
					])
				,
				new eui.State ("disabled",
					[
						new eui.SetProperty("_Image1","source","gip_p1_btn4_png")
					])
			];
		}
		var _proto = GIPP1$Skin12.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.percentHeight = 100;
			t.source = "gip_p1_btn4_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.fontFamily = "norfolkBold";
			t.horizontalCenter = 0;
			t.verticalCenter = 18.5;
			return t;
		};
		return GIPP1$Skin12;
	})(eui.Skin);

	function GIPP1() {
		_super.call(this);
		this.skinParts = ["bg","key12","gq_pane","key1","key17","activate","group1","key15","key9","btn2","btn3","btn4","group2","back","key3","key10","key11","key4","key5","key14"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this.bg_i(),this.group1_i(),this.group2_i(),this.back_i(),this._Image5_i(),this._Group1_i()];
	}
	var _proto = GIPP1.prototype;

	_proto.bg_i = function () {
		var t = new eui.Rect();
		this.bg = t;
		t.bottom = 0;
		t.fillColor = 0xffffff;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto.group1_i = function () {
		var t = new eui.Group();
		this.group1 = t;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this._Image1_i(),this.gq_pane_i(),this.key1_i(),this._Rect1_i(),this.key17_i(),this.activate_i()];
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.source = "gip_p1_title_img_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.gq_pane_i = function () {
		var t = new eui.Group();
		this.gq_pane = t;
		t.x = 505.22;
		t.y = 158.96;
		t.elementsContent = [this._Image2_i(),this.key12_i()];
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.source = "gip_p1_img3_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.key12_i = function () {
		var t = new eui.Label();
		this.key12 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolkBold";
		t.height = 47;
		t.size = 24;
		t.text = "Expired";
		t.textAlign = "center";
		t.textColor = 0xbcbcbc;
		t.verticalAlign = "middle";
		t.width = 120;
		t.x = 8;
		t.y = 8;
		return t;
	};
	_proto.key1_i = function () {
		var t = new eui.Label();
		this.key1 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolkBold";
		t.height = 67;
		t.size = 24;
		t.text = "Activate GIP\n  and Enjoy GIP exclusive rights ";
		t.textAlign = "center";
		t.textColor = 0x42C0C0;
		t.verticalAlign = "middle";
		t.width = 438;
		t.x = 155.5;
		t.y = 395;
		return t;
	};
	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.ellipseHeight = 105;
		t.ellipseWidth = 105;
		t.fillColor = 0xFFFFFF;
		t.height = 105;
		t.strokeAlpha = 0.3;
		t.strokeColor = 0x83A7E5;
		t.strokeWeight = 2;
		t.width = 683;
		t.x = 34;
		t.y = 526;
		return t;
	};
	_proto.key17_i = function () {
		var t = new eui.Label();
		this.key17 = t;
		t.anchorOffsetX = 0;
		t.fontFamily = "norfolkBold";
		t.height = 45;
		t.size = 24;
		t.text = "Activate gip: 0.05 eth/30 days";
		t.textAlign = "center";
		t.textColor = 0x759de2;
		t.verticalAlign = "middle";
		t.width = 440;
		t.x = 34;
		t.y = 557;
		return t;
	};
	_proto.activate_i = function () {
		var t = new eui.Button();
		this.activate = t;
		t.label = "Activate";
		t.x = 473;
		t.y = 549;
		t.skinName = GIPP1$Skin9;
		return t;
	};
	_proto.group2_i = function () {
		var t = new eui.Group();
		this.group2 = t;
		t.x = 30;
		t.y = 0;
		t.elementsContent = [this._Image3_i(),this._Image4_i(),this.key15_i(),this.key9_i(),this.btn2_i(),this.btn3_i(),this.btn4_i()];
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.source = "gip_p1_img4_png";
		t.x = 589;
		t.y = 0;
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.source = "gip_p1_img5_png";
		t.x = 0;
		t.y = 125.5;
		return t;
	};
	_proto.key15_i = function () {
		var t = new eui.Label();
		this.key15 = t;
		t.fontFamily = "norfolkBold";
		t.height = 30;
		t.right = 299;
		t.size = 24;
		t.text = "gip到期时间：2020.04.20 ";
		t.textColor = 0xfdc54a;
		t.verticalAlign = "middle";
		t.y = 521;
		return t;
	};
	_proto.key9_i = function () {
		var t = new eui.Label();
		this.key9 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolkBold";
		t.height = 63;
		t.size = 24;
		t.text = "您已成為GIP，可享受GIP專屬權限";
		t.textAlign = "center";
		t.textColor = 0x2db9b9;
		t.verticalAlign = "middle";
		t.width = 379;
		t.x = 152;
		t.y = 383;
		return t;
	};
	_proto.btn2_i = function () {
		var t = new eui.Button();
		this.btn2 = t;
		t.label = "續費";
		t.x = 434;
		t.y = 506;
		t.skinName = GIPP1$Skin10;
		return t;
	};
	_proto.btn3_i = function () {
		var t = new eui.Button();
		this.btn3 = t;
		t.label = "提幣";
		t.x = 4;
		t.y = 550;
		t.skinName = GIPP1$Skin11;
		return t;
	};
	_proto.btn4_i = function () {
		var t = new eui.Button();
		this.btn4 = t;
		t.label = "轉賬";
		t.x = 380;
		t.y = 550;
		t.skinName = GIPP1$Skin12;
		return t;
	};
	_proto.back_i = function () {
		var t = new eui.Component();
		this.back = t;
		t.height = 80;
		t.skinName = "BackBtn";
		t.touchChildren = false;
		t.width = 80;
		t.x = 0;
		t.y = 27;
		return t;
	};
	_proto._Image5_i = function () {
		var t = new eui.Image();
		t.bottom = 0;
		t.right = 0;
		t.source = "gip_p1_img2_png";
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.x = 34;
		t.y = 684;
		t.elementsContent = [this._Image6_i(),this.key3_i(),this._Image7_i(),this.key10_i(),this._Image8_i(),this.key11_i(),this._Image9_i(),this.key4_i(),this._Image10_i(),this.key5_i(),this._Image11_i(),this.key14_i()];
		return t;
	};
	_proto._Image6_i = function () {
		var t = new eui.Image();
		t.source = "gip_p1_img1_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.key3_i = function () {
		var t = new eui.Label();
		this.key3 = t;
		t.anchorOffsetX = 0;
		t.fontFamily = "norfolkBold";
		t.height = 45;
		t.size = 30;
		t.text = "exclusive rights";
		t.textAlign = "center";
		t.textColor = 0xffffff;
		t.verticalAlign = "middle";
		t.width = 272;
		t.x = 4;
		t.y = 9;
		return t;
	};
	_proto._Image7_i = function () {
		var t = new eui.Image();
		t.source = "gip_p1_item_img1_png";
		t.x = 0;
		t.y = 95;
		return t;
	};
	_proto.key10_i = function () {
		var t = new eui.Label();
		this.key10 = t;
		t.fontFamily = "norfolkBold";
		t.height = 45;
		t.size = 24;
		t.text = "Withdrawal";
		t.textAlign = "left";
		t.textColor = 0x42c0c0;
		t.verticalAlign = "middle";
		t.x = 110;
		t.y = 107;
		return t;
	};
	_proto._Image8_i = function () {
		var t = new eui.Image();
		t.source = "gip_p1_item_img2_png";
		t.x = 0;
		t.y = 175;
		return t;
	};
	_proto.key11_i = function () {
		var t = new eui.Label();
		this.key11 = t;
		t.fontFamily = "norfolkBold";
		t.height = 45;
		t.size = 24;
		t.text = "Transfer";
		t.textAlign = "left";
		t.textColor = 0x42C0C0;
		t.verticalAlign = "middle";
		t.x = 110;
		t.y = 187;
		return t;
	};
	_proto._Image9_i = function () {
		var t = new eui.Image();
		t.source = "gip_p1_item_img3_png";
		t.x = 0;
		t.y = 255;
		return t;
	};
	_proto.key4_i = function () {
		var t = new eui.Label();
		this.key4 = t;
		t.fontFamily = "norfolkBold";
		t.height = 45;
		t.size = 24;
		t.text = "Airdrop benefits";
		t.textAlign = "left";
		t.textColor = 0x42C0C0;
		t.verticalAlign = "middle";
		t.x = 110;
		t.y = 267;
		return t;
	};
	_proto._Image10_i = function () {
		var t = new eui.Image();
		t.source = "gip_p1_item_img4_png";
		t.x = 0;
		t.y = 335;
		return t;
	};
	_proto.key5_i = function () {
		var t = new eui.Label();
		this.key5 = t;
		t.fontFamily = "norfolkBold";
		t.height = 45;
		t.size = 24;
		t.text = "Overall mining speed up by 10% ";
		t.textAlign = "left";
		t.textColor = 0x42C0C0;
		t.verticalAlign = "middle";
		t.x = 110;
		t.y = 347;
		return t;
	};
	_proto._Image11_i = function () {
		var t = new eui.Image();
		t.source = "gip_p1_item_img5_png";
		t.x = 0;
		t.y = 415;
		return t;
	};
	_proto.key14_i = function () {
		var t = new eui.Label();
		this.key14 = t;
		t.fontFamily = "norfolkBold";
		t.height = 45;
		t.size = 24;
		t.text = "GL Google Ads Share";
		t.textAlign = "left";
		t.textColor = 0x42C0C0;
		t.verticalAlign = "middle";
		t.x = 110;
		t.y = 427;
		return t;
	};
	return GIPP1;
})(eui.Skin);generateEUI.paths['resource/eui/GIPP2records.exml'] = window.GIPP2records = (function (_super) {
	__extends(GIPP2records, _super);
	function GIPP2records() {
		_super.call(this);
		this.skinParts = ["group","list","back","title","loadingImg"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this._Rect1_i(),this.list_i(),this.back_i(),this.title_i(),this.loadingImg_i()];
	}
	var _proto = GIPP2records.prototype;

	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.bottom = 0;
		t.fillColor = 0xFFFFFF;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto.list_i = function () {
		var t = new eui.Scroller();
		this.list = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bottom = 117;
		t.horizontalCenter = 0;
		t.top = 128;
		t.width = 689;
		t.viewport = this.group_i();
		return t;
	};
	_proto.group_i = function () {
		var t = new eui.Group();
		this.group = t;
		return t;
	};
	_proto.back_i = function () {
		var t = new eui.Component();
		this.back = t;
		t.skinName = "BackBtn";
		t.x = 0;
		t.y = 33.68;
		return t;
	};
	_proto.title_i = function () {
		var t = new eui.Label();
		this.title = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolkBold";
		t.horizontalCenter = -0.5;
		t.lineSpacing = 6;
		t.size = 48;
		t.text = "records";
		t.textAlign = "center";
		t.textColor = 0x375591;
		t.verticalAlign = "middle";
		t.width = 591.34;
		t.y = 31.68;
		return t;
	};
	_proto.loadingImg_i = function () {
		var t = new eui.Image();
		this.loadingImg = t;
		t.anchorOffsetX = 25;
		t.anchorOffsetY = 26;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "tool_loading_h_png";
		t.y = 209;
		return t;
	};
	return GIPP2records;
})(eui.Skin);generateEUI.paths['resource/eui/GIPP3.exml'] = window.GIPP3 = (function (_super) {
	__extends(GIPP3, _super);
	var GIPP3$Skin13 = 	(function (_super) {
		__extends(GIPP3$Skin13, _super);
		function GIPP3$Skin13() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
						new eui.SetProperty("_Image1","alpha",0),
						new eui.SetProperty("labelDisplay","textColor",0x759de2)
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","gip_p3_btn_bg1_png")
					])
				,
				new eui.State ("disabled",
					[
						new eui.SetProperty("_Image1","source","gip_p3_btn_bg1_png")
					])
			];
		}
		var _proto = GIPP3$Skin13.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.percentHeight = 100;
			t.source = "gip_p3_btn_bg1_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.size = 24;
			t.verticalCenter = 0;
			return t;
		};
		return GIPP3$Skin13;
	})(eui.Skin);

	var GIPP3$Skin14 = 	(function (_super) {
		__extends(GIPP3$Skin14, _super);
		function GIPP3$Skin14() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
						new eui.SetProperty("_Image1","alpha",0),
						new eui.SetProperty("labelDisplay","textColor",0x759de2)
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","gip_p3_btn_bg1_png")
					])
				,
				new eui.State ("disabled",
					[
						new eui.SetProperty("_Image1","source","gip_p3_btn_bg1_png")
					])
			];
		}
		var _proto = GIPP3$Skin14.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.percentHeight = 100;
			t.source = "gip_p3_btn_bg1_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.size = 24;
			t.verticalCenter = 0;
			return t;
		};
		return GIPP3$Skin14;
	})(eui.Skin);

	function GIPP3() {
		_super.call(this);
		this.skinParts = ["back","title","btn3","pro_bar","pro_bar_mask","btn1","btn2","key2","amount_txt","pro_bar_txt","pro_bar_pane","loadingImg","group","list"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this._Rect1_i(),this.back_i(),this.title_i(),this.btn3_i(),this._Image1_i(),this._Image2_i(),this.pro_bar_i(),this._Image3_i(),this.pro_bar_mask_i(),this.btn1_i(),this.btn2_i(),this.key2_i(),this.amount_txt_i(),this.pro_bar_pane_i(),this.loadingImg_i(),this.list_i()];
	}
	var _proto = GIPP3.prototype;

	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.bottom = 0;
		t.fillColor = 0xFFFFFF;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto.back_i = function () {
		var t = new eui.Component();
		this.back = t;
		t.skinName = "BackBtn";
		t.x = 0;
		t.y = 16.12;
		return t;
	};
	_proto.title_i = function () {
		var t = new eui.Label();
		this.title = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolkBold";
		t.horizontalCenter = -0.5;
		t.lineSpacing = 6;
		t.size = 48;
		t.text = "Records";
		t.textAlign = "center";
		t.textColor = 0x375591;
		t.verticalAlign = "middle";
		t.width = 591.34;
		t.y = 31.68;
		return t;
	};
	_proto.btn3_i = function () {
		var t = new eui.Image();
		this.btn3 = t;
		t.source = "gip_icon_jl_png";
		t.x = 669;
		t.y = 36.88;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "gip_p3_title_bg_png";
		t.y = 96.32;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.source = "gip_p3_title_bar1_png";
		t.x = 109;
		t.y = 365.47;
		return t;
	};
	_proto.pro_bar_i = function () {
		var t = new eui.Image();
		this.pro_bar = t;
		t.source = "gip_p3_title_bar2_png";
		t.x = 124;
		t.y = 372.72;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.anchorOffsetY = 0;
		t.bottom = 63;
		t.scale9Grid = new egret.Rectangle(87,90,526,544);
		t.source = "gip_p3_list_bg_png";
		t.top = 505;
		t.x = 25;
		return t;
	};
	_proto.pro_bar_mask_i = function () {
		var t = new eui.Rect();
		this.pro_bar_mask = t;
		t.anchorOffsetX = 0;
		t.ellipseHeight = 40;
		t.ellipseWidth = 40;
		t.fillColor = 0x842525;
		t.height = 30;
		t.mask = this.pro_bar_mask;
		t.width = 197.2;
		t.x = 124;
		t.y = 372.72;
		if(this.pro_bar_mask)
		{
			this.pro_bar_mask.mask = this.pro_bar_mask;
		}
		return t;
	};
	_proto.btn1_i = function () {
		var t = new eui.Button();
		this.btn1 = t;
		t.currentState = "down";
		t.label = "Withdrawal amount";
		t.x = 22.61;
		t.y = 503;
		t.skinName = GIPP3$Skin13;
		return t;
	};
	_proto.btn2_i = function () {
		var t = new eui.Button();
		this.btn2 = t;
		t.currentState = "up";
		t.label = "Withdrawal fee";
		t.x = 283.79;
		t.y = 503;
		t.skinName = GIPP3$Skin14;
		return t;
	};
	_proto.key2_i = function () {
		var t = new eui.Label();
		this.key2 = t;
		t.fontFamily = "norfolkBold";
		t.size = 24;
		t.text = "Today's remaining balance :";
		t.x = 70;
		t.y = 135.67;
		return t;
	};
	_proto.amount_txt_i = function () {
		var t = new eui.Label();
		this.amount_txt = t;
		t.bold = true;
		t.fontFamily = "norfolkBold";
		t.horizontalCenter = 0;
		t.size = 100;
		t.stroke = 2;
		t.strokeColor = 0x51cbd6;
		t.text = "0 gl";
		t.verticalAlign = "middle";
		t.y = 216.39;
		return t;
	};
	_proto.pro_bar_pane_i = function () {
		var t = new eui.Group();
		this.pro_bar_pane = t;
		t.x = 440.69;
		t.y = 398.35;
		t.elementsContent = [this._Image4_i(),this.pro_bar_txt_i()];
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.source = "gip_p3_title_msg_bg_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.pro_bar_txt_i = function () {
		var t = new eui.Label();
		this.pro_bar_txt = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.height = 28;
		t.size = 16;
		t.text = "Remaining : 80%";
		t.textAlign = "center";
		t.textColor = 0x2db9b9;
		t.verticalAlign = "middle";
		t.width = 130;
		t.x = 8.98;
		t.y = 27;
		return t;
	};
	_proto.loadingImg_i = function () {
		var t = new eui.Image();
		this.loadingImg = t;
		t.anchorOffsetX = 25;
		t.anchorOffsetY = 26;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "tool_loading_h_png";
		t.y = 199;
		return t;
	};
	_proto.list_i = function () {
		var t = new eui.Scroller();
		this.list = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bottom = 97;
		t.horizontalCenter = 0;
		t.top = 611;
		t.width = 669;
		t.viewport = this.group_i();
		return t;
	};
	_proto.group_i = function () {
		var t = new eui.Group();
		this.group = t;
		return t;
	};
	return GIPP3;
})(eui.Skin);generateEUI.paths['resource/eui/GIPP3records.exml'] = window.GIPP3records = (function (_super) {
	__extends(GIPP3records, _super);
	var GIPP3records$Skin15 = 	(function (_super) {
		__extends(GIPP3records$Skin15, _super);
		function GIPP3records$Skin15() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
						new eui.SetProperty("_Image1","alpha",0),
						new eui.SetProperty("labelDisplay","textColor",0x759de2)
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","gip_p3_btn_bg1_png")
					])
				,
				new eui.State ("disabled",
					[
						new eui.SetProperty("_Image1","source","gip_p3_btn_bg1_png")
					])
			];
		}
		var _proto = GIPP3records$Skin15.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.percentHeight = 100;
			t.source = "gip_p3_btn_bg1_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.size = 24;
			t.verticalCenter = 0;
			return t;
		};
		return GIPP3records$Skin15;
	})(eui.Skin);

	var GIPP3records$Skin16 = 	(function (_super) {
		__extends(GIPP3records$Skin16, _super);
		function GIPP3records$Skin16() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
						new eui.SetProperty("_Image1","alpha",0),
						new eui.SetProperty("labelDisplay","textColor",0x759de2)
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","gip_p3_btn_bg1_png")
					])
				,
				new eui.State ("disabled",
					[
						new eui.SetProperty("_Image1","source","gip_p3_btn_bg1_png")
					])
			];
		}
		var _proto = GIPP3records$Skin16.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.percentHeight = 100;
			t.source = "gip_p3_btn_bg1_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.size = 24;
			t.verticalCenter = 0;
			return t;
		};
		return GIPP3records$Skin16;
	})(eui.Skin);

	function GIPP3records() {
		_super.call(this);
		this.skinParts = ["group","list","btn1","btn2","back","title","loadingImg","upimg","updata"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this._Rect1_i(),this._Image1_i(),this.list_i(),this.btn1_i(),this.btn2_i(),this.back_i(),this.title_i(),this.loadingImg_i(),this.updata_i()];
	}
	var _proto = GIPP3records.prototype;

	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.bottom = 0;
		t.fillColor = 0xFFFFFF;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.anchorOffsetY = 0;
		t.height = 1136;
		t.horizontalCenter = 0;
		t.scale9Grid = new egret.Rectangle(87,90,526,570);
		t.source = "gip_p3_list_bg_png";
		t.y = 125.48;
		return t;
	};
	_proto.list_i = function () {
		var t = new eui.Scroller();
		this.list = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bottom = 117;
		t.horizontalCenter = 0;
		t.top = 229;
		t.width = 664;
		t.viewport = this.group_i();
		return t;
	};
	_proto.group_i = function () {
		var t = new eui.Group();
		this.group = t;
		return t;
	};
	_proto.btn1_i = function () {
		var t = new eui.Button();
		this.btn1 = t;
		t.currentState = "down";
		t.label = "Release";
		t.x = 22.61;
		t.y = 123;
		t.skinName = GIPP3records$Skin15;
		return t;
	};
	_proto.btn2_i = function () {
		var t = new eui.Button();
		this.btn2 = t;
		t.currentState = "up";
		t.label = "Reject";
		t.x = 283.79;
		t.y = 123;
		t.skinName = GIPP3records$Skin16;
		return t;
	};
	_proto.back_i = function () {
		var t = new eui.Component();
		this.back = t;
		t.skinName = "BackBtn";
		t.x = 0;
		t.y = 16.12;
		return t;
	};
	_proto.title_i = function () {
		var t = new eui.Label();
		this.title = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolkBold";
		t.horizontalCenter = -0.5;
		t.lineSpacing = 6;
		t.size = 48;
		t.text = "records";
		t.textAlign = "center";
		t.textColor = 0x375591;
		t.verticalAlign = "middle";
		t.width = 591.34;
		t.y = 31.68;
		return t;
	};
	_proto.loadingImg_i = function () {
		var t = new eui.Image();
		this.loadingImg = t;
		t.anchorOffsetX = 25;
		t.anchorOffsetY = 26;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "tool_loading_h_png";
		t.y = 303;
		return t;
	};
	_proto.updata_i = function () {
		var t = new eui.Group();
		this.updata = t;
		t.touchChildren = false;
		t.x = 667;
		t.y = 26;
		t.elementsContent = [this._Rect2_i(),this.upimg_i()];
		return t;
	};
	_proto._Rect2_i = function () {
		var t = new eui.Rect();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillColor = 0xFFFFFF;
		t.height = 62;
		t.width = 62;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.upimg_i = function () {
		var t = new eui.Image();
		this.upimg = t;
		t.anchorOffsetX = 17;
		t.anchorOffsetY = 18;
		t.horizontalCenter = 0;
		t.source = "icon_updata_png";
		t.verticalCenter = 0;
		return t;
	};
	return GIPP3records;
})(eui.Skin);generateEUI.paths['resource/eui/GIPVItem.exml'] = window.GIPVItem = (function (_super) {
	__extends(GIPVItem, _super);
	function GIPVItem() {
		_super.call(this);
		this.skinParts = ["fee","fee_t","earned","earned_t","amount_t","amount","account","title"];
		
		this.height = 177;
		this.width = 664;
		this.elementsContent = [this._Image1_i(),this.fee_i(),this.fee_t_i(),this.earned_i(),this.earned_t_i(),this.amount_t_i(),this.amount_i(),this.account_i(),this.title_i()];
	}
	var _proto = GIPVItem.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.left = 0;
		t.source = "gip_p3_list_item_bg1_png";
		t.top = 0;
		return t;
	};
	_proto.fee_i = function () {
		var t = new eui.Label();
		this.fee = t;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.size = 24;
		t.text = "222";
		t.textColor = 0x2db9b9;
		t.verticalAlign = "middle";
		t.x = 512;
		t.y = 79;
		return t;
	};
	_proto.fee_t_i = function () {
		var t = new eui.Label();
		this.fee_t = t;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.size = 24;
		t.text = "Custom fee : ";
		t.textColor = 0xbcbcbc;
		t.verticalAlign = "middle";
		t.x = 375;
		t.y = 79;
		return t;
	};
	_proto.earned_i = function () {
		var t = new eui.Label();
		this.earned = t;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.size = 24;
		t.text = "100";
		t.textColor = 0x2db9b9;
		t.verticalAlign = "middle";
		t.x = 516;
		t.y = 119.5;
		return t;
	};
	_proto.earned_t_i = function () {
		var t = new eui.Label();
		this.earned_t = t;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.size = 24;
		t.text = "Earned GL : ";
		t.textColor = 0xbcbcbc;
		t.verticalAlign = "middle";
		t.x = 375;
		t.y = 120.5;
		return t;
	};
	_proto.amount_t_i = function () {
		var t = new eui.Label();
		this.amount_t = t;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.size = 24;
		t.text = "Withdrawal amount : ";
		t.textColor = 0xBCBCBC;
		t.verticalAlign = "middle";
		t.x = 49;
		t.y = 120;
		return t;
	};
	_proto.amount_i = function () {
		var t = new eui.Label();
		this.amount = t;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.size = 24;
		t.text = "10000 GL";
		t.textColor = 0x2db9b9;
		t.verticalAlign = "middle";
		t.x = 259;
		t.y = 120;
		return t;
	};
	_proto.account_i = function () {
		var t = new eui.Label();
		this.account = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.size = 24;
		t.text = "4608871*******";
		t.textColor = 0x2db9b9;
		t.verticalAlign = "middle";
		t.width = 299;
		t.x = 49;
		t.y = 79;
		return t;
	};
	_proto.title_i = function () {
		var t = new eui.Label();
		this.title = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolkBold";
		t.height = 50;
		t.size = 24;
		t.text = "Reject countd";
		t.textAlign = "center";
		t.verticalAlign = "middle";
		t.width = 291;
		t.x = 48;
		t.y = 0;
		return t;
	};
	return GIPVItem;
})(eui.Skin);generateEUI.paths['resource/eui/GIPVItem2.exml'] = window.GIPVItem2 = (function (_super) {
	__extends(GIPVItem2, _super);
	function GIPVItem2() {
		_super.call(this);
		this.skinParts = ["fee","fee_t","amount_t","amount","account","title"];
		
		this.height = 177;
		this.width = 664;
		this.elementsContent = [this._Image1_i(),this.fee_i(),this.fee_t_i(),this.amount_t_i(),this.amount_i(),this.account_i(),this.title_i()];
	}
	var _proto = GIPVItem2.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.left = 0;
		t.source = "gip_p3_list_item_bg2_png";
		t.top = 0;
		return t;
	};
	_proto.fee_i = function () {
		var t = new eui.Label();
		this.fee = t;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.size = 24;
		t.text = "222";
		t.textColor = 0xef3e34;
		t.verticalAlign = "middle";
		t.x = 512;
		t.y = 79;
		return t;
	};
	_proto.fee_t_i = function () {
		var t = new eui.Label();
		this.fee_t = t;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.size = 24;
		t.text = "Custom fee : ";
		t.textColor = 0xBCBCBC;
		t.verticalAlign = "middle";
		t.x = 375;
		t.y = 79;
		return t;
	};
	_proto.amount_t_i = function () {
		var t = new eui.Label();
		this.amount_t = t;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.size = 24;
		t.text = "Withdrawal amount : ";
		t.textColor = 0xBCBCBC;
		t.verticalAlign = "middle";
		t.x = 49;
		t.y = 120;
		return t;
	};
	_proto.amount_i = function () {
		var t = new eui.Label();
		this.amount = t;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.size = 24;
		t.text = "10000 GL";
		t.textColor = 0xef3e34;
		t.verticalAlign = "middle";
		t.x = 259;
		t.y = 120;
		return t;
	};
	_proto.account_i = function () {
		var t = new eui.Label();
		this.account = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.size = 24;
		t.text = "4608871*******";
		t.textColor = 0xef3e34;
		t.verticalAlign = "middle";
		t.width = 299;
		t.x = 49;
		t.y = 79;
		return t;
	};
	_proto.title_i = function () {
		var t = new eui.Label();
		this.title = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolkBold";
		t.height = 50;
		t.size = 24;
		t.text = "Reject countd";
		t.textAlign = "center";
		t.verticalAlign = "middle";
		t.width = 287;
		t.x = 51;
		t.y = 0;
		return t;
	};
	return GIPVItem2;
})(eui.Skin);generateEUI.paths['resource/eui/GIPWDItem.exml'] = window.GIPWDItem = (function (_super) {
	__extends(GIPWDItem, _super);
	var GIPWDItem$Skin17 = 	(function (_super) {
		__extends(GIPWDItem$Skin17, _super);
		function GIPWDItem$Skin17() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
						new eui.SetProperty("labelDisplay","textColor",0x759de2)
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","gip_p2_wd_item_btn2_png"),
						new eui.SetProperty("labelDisplay","textColor",0x2db9b9)
					])
				,
				new eui.State ("disabled",
					[
						new eui.SetProperty("_Image1","source","gip_p2_wd_item_btn3_png"),
						new eui.SetProperty("labelDisplay","textColor",0xef3e35)
					])
			];
		}
		var _proto = GIPWDItem$Skin17.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.percentHeight = 100;
			t.source = "gip_p2_wd_item_btn1_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.fontFamily = "norfolkBold";
			t.horizontalCenter = 0;
			t.size = 24;
			t.verticalCenter = 0;
			return t;
		};
		return GIPWDItem$Skin17;
	})(eui.Skin);

	function GIPWDItem() {
		_super.call(this);
		this.skinParts = ["t1","t2","t3","t4","t5","txt4","txt1","txt2","txt3","btn"];
		
		this.height = 392;
		this.width = 689;
		this.elementsContent = [this._Image1_i(),this.t1_i(),this.t2_i(),this.t3_i(),this.t4_i(),this.t5_i(),this.txt4_i(),this.txt1_i(),this.txt2_i(),this.txt3_i(),this.btn_i()];
	}
	var _proto = GIPWDItem.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.left = 0;
		t.source = "gip_p2_wd_item_bg_png";
		t.top = 0;
		return t;
	};
	_proto.t1_i = function () {
		var t = new eui.Label();
		this.t1 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolkBold";
		t.height = 65.03;
		t.size = 30;
		t.text = " ";
		t.textAlign = "left";
		t.verticalAlign = "middle";
		t.x = 37.5;
		t.y = 10;
		return t;
	};
	_proto.t2_i = function () {
		var t = new eui.Label();
		this.t2 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.size = 24;
		t.text = " ";
		t.textAlign = "left";
		t.textColor = 0x759DE2;
		t.verticalAlign = "top";
		t.x = 38;
		t.y = 108;
		return t;
	};
	_proto.t3_i = function () {
		var t = new eui.Label();
		this.t3 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.size = 24;
		t.text = " ";
		t.textAlign = "left";
		t.textColor = 0x759DE2;
		t.verticalAlign = "top";
		t.x = 38;
		t.y = 148;
		return t;
	};
	_proto.t4_i = function () {
		var t = new eui.Label();
		this.t4 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.size = 24;
		t.text = " ";
		t.textAlign = "left";
		t.textColor = 0x759DE2;
		t.verticalAlign = "top";
		t.x = 38;
		t.y = 188;
		return t;
	};
	_proto.t5_i = function () {
		var t = new eui.Label();
		this.t5 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.size = 24;
		t.text = " ";
		t.textAlign = "left";
		t.textColor = 0x759DE2;
		t.verticalAlign = "top";
		t.x = 38;
		t.y = 227;
		return t;
	};
	_proto.txt4_i = function () {
		var t = new eui.Label();
		this.txt4 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.lineSpacing = 8;
		t.size = 24;
		t.text = " ";
		t.textAlign = "left";
		t.textColor = 0x2DB9B9;
		t.verticalAlign = "top";
		t.width = 458;
		t.x = 38;
		t.y = 267;
		return t;
	};
	_proto.txt1_i = function () {
		var t = new eui.Label();
		this.txt1 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.size = 24;
		t.text = " ";
		t.textAlign = "left";
		t.textColor = 0x2DB9B9;
		t.verticalAlign = "top";
		t.x = 228;
		t.y = 108;
		return t;
	};
	_proto.txt2_i = function () {
		var t = new eui.Label();
		this.txt2 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.size = 24;
		t.text = " ";
		t.textAlign = "left";
		t.textColor = 0x2DB9B9;
		t.verticalAlign = "top";
		t.x = 228;
		t.y = 148;
		return t;
	};
	_proto.txt3_i = function () {
		var t = new eui.Label();
		this.txt3 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.size = 24;
		t.text = " ";
		t.textAlign = "left";
		t.textColor = 0x2DB9B9;
		t.verticalAlign = "top";
		t.x = 228;
		t.y = 188;
		return t;
	};
	_proto.btn_i = function () {
		var t = new eui.Button();
		this.btn = t;
		t.currentState = "down";
		t.label = "";
		t.touchChildren = false;
		t.touchEnabled = false;
		t.x = 495;
		t.y = 115;
		t.skinName = GIPWDItem$Skin17;
		return t;
	};
	return GIPWDItem;
})(eui.Skin);generateEUI.paths['resource/eui/GipWithdrawalRecords.exml'] = window.GipWithdrawalRecords = (function (_super) {
	__extends(GipWithdrawalRecords, _super);
	function GipWithdrawalRecords() {
		_super.call(this);
		this.skinParts = ["back","title","group0","list","loadingImg"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this._Rect1_i(),this.back_i(),this.title_i(),this.list_i(),this.loadingImg_i()];
	}
	var _proto = GipWithdrawalRecords.prototype;

	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.bottom = 0;
		t.fillColor = 0xFFFFFF;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto.back_i = function () {
		var t = new eui.Component();
		this.back = t;
		t.skinName = "BackBtn";
		t.x = 0;
		t.y = 22.36;
		return t;
	};
	_proto.title_i = function () {
		var t = new eui.Label();
		this.title = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolkBold";
		t.horizontalCenter = -0.5;
		t.lineSpacing = 6;
		t.size = 36;
		t.text = "Withdrawal records";
		t.textAlign = "center";
		t.textColor = 0x759de2;
		t.verticalAlign = "middle";
		t.width = 591.34;
		t.y = 39.8;
		return t;
	};
	_proto.list_i = function () {
		var t = new eui.Scroller();
		this.list = t;
		t.anchorOffsetY = 0;
		t.bottom = 42;
		t.left = 0;
		t.right = 0;
		t.top = 114;
		t.viewport = this.group0_i();
		return t;
	};
	_proto.group0_i = function () {
		var t = new eui.Group();
		this.group0 = t;
		return t;
	};
	_proto.loadingImg_i = function () {
		var t = new eui.Image();
		this.loadingImg = t;
		t.anchorOffsetX = 25;
		t.anchorOffsetY = 26;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "tool_loading_h_png";
		t.y = 229;
		return t;
	};
	return GipWithdrawalRecords;
})(eui.Skin);generateEUI.paths['resource/eui/GLTransferAutPage.exml'] = window.GLTransferAutPage = (function (_super) {
	__extends(GLTransferAutPage, _super);
	var GLTransferAutPage$Skin18 = 	(function (_super) {
		__extends(GLTransferAutPage$Skin18, _super);
		function GLTransferAutPage$Skin18() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","confirm_btn_off_png"),
						new eui.SetProperty("labelDisplay","textColor",0xf8b43d)
					])
				,
				new eui.State ("disabled",
					[
						new eui.SetProperty("_Image1","source","confirm_btn_off_png")
					])
			];
		}
		var _proto = GLTransferAutPage$Skin18.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.percentHeight = 100;
			t.source = "confirm_btn_on_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.bold = true;
			t.fontFamily = "norfolk";
			t.horizontalCenter = 0;
			t.size = 36;
			t.textColor = 0xFFFFFF;
			t.verticalCenter = -8;
			return t;
		};
		return GLTransferAutPage$Skin18;
	})(eui.Skin);

	var GLTransferAutPage$Skin19 = 	(function (_super) {
		__extends(GLTransferAutPage$Skin19, _super);
		function GLTransferAutPage$Skin19() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","switch_btn_off_png")
					])
				,
				new eui.State ("disabled",
					[
						new eui.SetProperty("_Image1","source","switch_btn_off_png")
					])
			];
		}
		var _proto = GLTransferAutPage$Skin19.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.percentHeight = 100;
			t.source = "switch_btn_on_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return GLTransferAutPage$Skin19;
	})(eui.Skin);

	function GLTransferAutPage() {
		_super.call(this);
		this.skinParts = ["bg","backBtn","title","txt1","acc","txt2","t1","t2","t3","t4","t6","t7","t8","t9","txt4","t5","agreeBtn","wait","tool_loading","loadPane","bg0","backBtn0","content","switch_btn","disPane"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this.bg_i(),this.backBtn_i(),this.title_i(),this.txt1_i(),this.acc_i(),this.txt2_i(),this.t1_i(),this.t2_i(),this.t3_i(),this.t4_i(),this.t6_i(),this.t7_i(),this.t8_i(),this.t9_i(),this.txt4_i(),this._Image1_i(),this._Image2_i(),this._Image3_i(),this.t5_i(),this.agreeBtn_i(),this.wait_i(),this.loadPane_i(),this.disPane_i()];
	}
	var _proto = GLTransferAutPage.prototype;

	_proto.bg_i = function () {
		var t = new eui.Rect();
		this.bg = t;
		t.bottom = 0;
		t.fillColor = 0xFFFFFF;
		t.left = 0;
		t.right = 0;
		t.strokeColor = 0xFFFFFF;
		t.top = 0;
		return t;
	};
	_proto.backBtn_i = function () {
		var t = new eui.Component();
		this.backBtn = t;
		t.height = 80;
		t.skinName = "BackBtn";
		t.width = 80;
		t.x = 1;
		t.y = 25;
		return t;
	};
	_proto.title_i = function () {
		var t = new eui.Label();
		this.title = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolkBold";
		t.horizontalCenter = 0.5;
		t.size = 48;
		t.text = "Gl Authorization";
		t.textColor = 0x375591;
		t.y = 47;
		return t;
	};
	_proto.txt1_i = function () {
		var t = new eui.Label();
		this.txt1 = t;
		t.anchorOffsetX = 242;
		t.anchorOffsetY = 1;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.size = 30;
		t.text = "GL Planet ID:";
		t.textAlign = "right";
		t.textColor = 0x375591;
		t.width = 242;
		t.x = 355;
		t.y = 427;
		return t;
	};
	_proto.acc_i = function () {
		var t = new eui.Label();
		this.acc = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.size = 30;
		t.text = "460****76@qq.com";
		t.textAlign = "left";
		t.textColor = 0x72B1D2;
		t.width = 334;
		t.x = 383;
		t.y = 426;
		return t;
	};
	_proto.txt2_i = function () {
		var t = new eui.Label();
		this.txt2 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.height = 294;
		t.size = 36;
		t.text = "Agree to authorize ";
		t.textAlign = "left";
		t.textColor = 0x7bb5d4;
		t.verticalAlign = "top";
		t.width = 578;
		t.x = 50;
		t.y = 514;
		return t;
	};
	_proto.t1_i = function () {
		var t = new eui.Label();
		this.t1 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.size = 36;
		t.text = "Cyber Space";
		t.textColor = 0x7bb5d4;
		t.visible = false;
		t.x = 50;
		t.y = 573;
		return t;
	};
	_proto.t2_i = function () {
		var t = new eui.Label();
		this.t2 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.height = 40;
		t.size = 30;
		t.text = "to enhanice";
		t.textColor = 0xbdbdbd;
		t.verticalAlign = "bottom";
		t.visible = false;
		t.x = 269.2;
		t.y = 569;
		return t;
	};
	_proto.t3_i = function () {
		var t = new eui.Label();
		this.t3 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.size = 36;
		t.text = "GL";
		t.textColor = 0x7BB5D4;
		t.visible = false;
		t.x = 436.79;
		t.y = 573;
		return t;
	};
	_proto.t4_i = function () {
		var t = new eui.Label();
		this.t4 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.height = 40;
		t.size = 30;
		t.text = "in your";
		t.textColor = 0xBDBDBD;
		t.verticalAlign = "bottom";
		t.visible = false;
		t.x = 482.18;
		t.y = 569;
		return t;
	};
	_proto.t6_i = function () {
		var t = new eui.Label();
		this.t6 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.size = 36;
		t.text = "GL Planet";
		t.textColor = 0x7BB5D4;
		t.visible = false;
		t.x = 50;
		t.y = 638;
		return t;
	};
	_proto.t7_i = function () {
		var t = new eui.Label();
		this.t7 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.height = 40;
		t.size = 30;
		t.text = "account,";
		t.textColor = 0xBDBDBD;
		t.verticalAlign = "bottom";
		t.visible = false;
		t.x = 241.3;
		t.y = 634;
		return t;
	};
	_proto.t8_i = function () {
		var t = new eui.Label();
		this.t8 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.size = 36;
		t.text = "0.0 GL";
		t.textColor = 0x7BB5D4;
		t.visible = false;
		t.x = 369.99;
		t.y = 638;
		return t;
	};
	_proto.t9_i = function () {
		var t = new eui.Label();
		this.t9 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.height = 40;
		t.size = 30;
		t.text = "will be";
		t.textColor = 0xBDBDBD;
		t.verticalAlign = "bottom";
		t.visible = false;
		t.x = 495.22;
		t.y = 634;
		return t;
	};
	_proto.txt4_i = function () {
		var t = new eui.Label();
		this.txt4 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.size = 30;
		t.text = "deducted after authorization. ";
		t.textAlign = "left";
		t.textColor = 0xBDBDBD;
		t.visible = false;
		t.x = 50;
		t.y = 705;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.source = "empower_img1_png";
		t.x = 160;
		t.y = 238;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.right = 160;
		t.source = "empower_img2_png";
		t.y = 238;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0.5;
		t.source = "empower_img3_png";
		t.y = 283;
		return t;
	};
	_proto.t5_i = function () {
		var t = new eui.Label();
		this.t5 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.bottom = 349;
		t.fontFamily = "norfolk";
		t.horizontalCenter = 0;
		t.size = 30;
		t.text = "";
		t.textAlign = "center";
		t.textColor = 0xBDBDBD;
		t.width = 750;
		return t;
	};
	_proto.agreeBtn_i = function () {
		var t = new eui.Button();
		this.agreeBtn = t;
		t.bottom = 199;
		t.horizontalCenter = 0;
		t.label = "Comfirm";
		t.skinName = GLTransferAutPage$Skin18;
		return t;
	};
	_proto.wait_i = function () {
		var t = new eui.Label();
		this.wait = t;
		t.bold = true;
		t.bottom = 146;
		t.fontFamily = "norfolk";
		t.height = 40;
		t.text = "Wait!";
		t.textAlign = "center";
		t.textColor = 0xF5C565;
		t.width = 120;
		t.x = 377;
		return t;
	};
	_proto.loadPane_i = function () {
		var t = new eui.Group();
		this.loadPane = t;
		t.bottom = 218;
		t.horizontalCenter = 0;
		t.visible = false;
		t.x = 104;
		t.elementsContent = [this._Rect1_i(),this.tool_loading_i()];
		return t;
	};
	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.ellipseHeight = 90;
		t.ellipseWidth = 90;
		t.fillColor = 0xBFBFBF;
		t.height = 80;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.strokeColor = 0xFFFFFF;
		t.width = 299.5;
		t.y = 0;
		return t;
	};
	_proto.tool_loading_i = function () {
		var t = new eui.Image();
		this.tool_loading = t;
		t.anchorOffsetX = 25;
		t.anchorOffsetY = 26;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "tool_loading_png";
		t.verticalCenter = 0;
		return t;
	};
	_proto.disPane_i = function () {
		var t = new eui.Group();
		this.disPane = t;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.visible = false;
		t.elementsContent = [this.bg0_i(),this._Image4_i(),this._Image5_i(),this.backBtn0_i(),this._Image6_i(),this.content_i(),this.switch_btn_i()];
		return t;
	};
	_proto.bg0_i = function () {
		var t = new eui.Rect();
		this.bg0 = t;
		t.bottom = 0;
		t.fillColor = 0xFFFFFF;
		t.left = 0;
		t.right = 0;
		t.strokeColor = 0xFFFFFF;
		t.top = 0;
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = -5.5;
		t.source = "transfer_img2_png";
		t.top = -94;
		t.x = 65;
		t.y = 1113;
		return t;
	};
	_proto._Image5_i = function () {
		var t = new eui.Image();
		t.bottom = -107;
		t.left = -39;
		t.source = "transfer_img1_png";
		return t;
	};
	_proto.backBtn0_i = function () {
		var t = new eui.Component();
		this.backBtn0 = t;
		t.height = 80;
		t.skinName = "BackBtn";
		t.width = 80;
		t.x = 25;
		t.y = 43;
		return t;
	};
	_proto._Image6_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "empower_img_heard_png";
		t.y = 402;
		return t;
	};
	_proto.content_i = function () {
		var t = new eui.Label();
		this.content = t;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.horizontalCenter = 0;
		t.text = " inconsistent account, unable to authorize \nplease switch account ";
		t.textAlign = "center";
		t.textColor = 0x2db9b9;
		t.y = 587;
		return t;
	};
	_proto.switch_btn_i = function () {
		var t = new eui.Button();
		this.switch_btn = t;
		t.horizontalCenter = 0;
		t.label = "";
		t.y = 781;
		t.skinName = GLTransferAutPage$Skin19;
		return t;
	};
	return GLTransferAutPage;
})(eui.Skin);generateEUI.paths['resource/eui/GoogleAuthenticatorPage.exml'] = window.GoogleAuthenticatorPage = (function (_super) {
	__extends(GoogleAuthenticatorPage, _super);
	var GoogleAuthenticatorPage$Skin20 = 	(function (_super) {
		__extends(GoogleAuthenticatorPage$Skin20, _super);
		function GoogleAuthenticatorPage$Skin20() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","ga_btn_off_png"),
						new eui.SetProperty("labelDisplay","textColor",0xf8b43d)
					])
				,
				new eui.State ("disabled",
					[
						new eui.SetProperty("_Image1","source","ga_btn_off_png")
					])
			];
		}
		var _proto = GoogleAuthenticatorPage$Skin20.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.percentHeight = 100;
			t.source = "ga_btn_on_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.bold = true;
			t.fontFamily = "norfolk";
			t.horizontalCenter = 0;
			t.textColor = 0xFFFFFF;
			t.verticalCenter = -9;
			return t;
		};
		return GoogleAuthenticatorPage$Skin20;
	})(eui.Skin);

	function GoogleAuthenticatorPage() {
		_super.call(this);
		this.skinParts = ["bg","title","backBtn","openBtn","t1"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this.bg_i(),this.title_i(),this.backBtn_i(),this._Image1_i(),this._Image2_i(),this.openBtn_i(),this.t1_i()];
	}
	var _proto = GoogleAuthenticatorPage.prototype;

	_proto.bg_i = function () {
		var t = new eui.Rect();
		this.bg = t;
		t.bottom = 0;
		t.fillColor = 0xFFFFFF;
		t.left = 0;
		t.right = 0;
		t.strokeColor = 0xFFFFFF;
		t.top = 0;
		return t;
	};
	_proto.title_i = function () {
		var t = new eui.Label();
		this.title = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolkBold";
		t.horizontalCenter = 0;
		t.size = 48;
		t.text = "Google Authenticator";
		t.textColor = 0x5a66b4;
		t.y = 39.92;
		return t;
	};
	_proto.backBtn_i = function () {
		var t = new eui.Component();
		this.backBtn = t;
		t.height = 80;
		t.skinName = "BackBtn";
		t.width = 80;
		t.x = 2.84;
		t.y = 26.14;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "ga_img1_png";
		t.verticalCenter = -317;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "ga_txt1_png";
		t.verticalCenter = 41.5;
		t.visible = false;
		return t;
	};
	_proto.openBtn_i = function () {
		var t = new eui.Button();
		this.openBtn = t;
		t.bottom = 123;
		t.horizontalCenter = 0;
		t.label = "open";
		t.skinName = GoogleAuthenticatorPage$Skin20;
		return t;
	};
	_proto.t1_i = function () {
		var t = new eui.Label();
		this.t1 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.height = 370;
		t.horizontalCenter = 0;
		t.lineSpacing = 6;
		t.text = "";
		t.textAlign = "center";
		t.textColor = 0x6e6b6c;
		t.verticalCenter = 106;
		t.width = 490;
		return t;
	};
	return GoogleAuthenticatorPage;
})(eui.Skin);generateEUI.paths['resource/eui/HomeView.exml'] = window.HomeView = (function (_super) {
	__extends(HomeView, _super);
	var HomeView$Skin21 = 	(function (_super) {
		__extends(HomeView$Skin21, _super);
		function HomeView$Skin21() {
			_super.call(this);
			this.skinParts = [];
			
			this.height = 60;
			this.elementsContent = [this._Rect1_i(),this._Image1_i(),this._Label1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Rect1","fillColor",0xaaaaaa),
						new eui.SetProperty("_Label1","textColor",0x090909)
					])
				,
				new eui.State ("disabled",
					[
					])
			];
			
			eui.Binding.$bindProperties(this, ["hostComponent.data.icon"],[0],this._Image1,"source");
			eui.Binding.$bindProperties(this, ["hostComponent.data.label"],[0],this._Label1,"text");
		}
		var _proto = HomeView$Skin21.prototype;

		_proto._Rect1_i = function () {
			var t = new eui.Rect();
			this._Rect1 = t;
			t.anchorOffsetX = 0;
			t.anchorOffsetY = 0;
			t.ellipseHeight = 5;
			t.ellipseWidth = 5;
			t.fillColor = 0xeeeeee;
			t.height = 60;
			t.width = 220;
			t.x = 0;
			t.y = 0;
			return t;
		};
		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.height = 38;
			t.verticalCenter = 0;
			t.width = 38;
			t.x = 15;
			return t;
		};
		_proto._Label1_i = function () {
			var t = new eui.Label();
			this._Label1 = t;
			t.bold = true;
			t.horizontalCenter = 8;
			t.size = 24;
			t.textColor = 0x141414;
			t.verticalCenter = 0;
			return t;
		};
		return HomeView$Skin21;
	})(eui.Skin);

	function HomeView() {
		_super.call(this);
		this.skinParts = ["cirde0","cirde1","cirde2","cirde3","cirde4","cirde5","txt1","txt","signup_btn_label","signup_btn","login_btn_label","login_btn","languageIcon","languageLabel","languageSelectHeard","languageList"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this._Rect1_i(),this.cirde0_i(),this.cirde1_i(),this.cirde2_i(),this.cirde3_i(),this.cirde4_i(),this.cirde5_i(),this.txt_i(),this.signup_btn_i(),this.login_btn_i(),this.languageSelectHeard_i(),this.languageList_i()];
	}
	var _proto = HomeView.prototype;

	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bottom = 0;
		t.fillColor = 0xffffff;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto.cirde0_i = function () {
		var t = new eui.Image();
		this.cirde0 = t;
		t.anchorOffsetX = 13;
		t.anchorOffsetY = 13;
		t.source = "home_circle1_png";
		t.x = 107;
		t.y = 782;
		return t;
	};
	_proto.cirde1_i = function () {
		var t = new eui.Image();
		this.cirde1 = t;
		t.anchorOffsetX = 18;
		t.anchorOffsetY = 18;
		t.source = "home_circle2_png";
		t.x = 199;
		t.y = 768;
		return t;
	};
	_proto.cirde2_i = function () {
		var t = new eui.Image();
		this.cirde2 = t;
		t.anchorOffsetX = 42;
		t.anchorOffsetY = 42;
		t.source = "home_circle3_png";
		t.x = 284;
		t.y = 768;
		return t;
	};
	_proto.cirde3_i = function () {
		var t = new eui.Image();
		this.cirde3 = t;
		t.anchorOffsetX = 17;
		t.anchorOffsetY = 17;
		t.source = "home_circle4_png";
		t.x = 419;
		t.y = 768;
		return t;
	};
	_proto.cirde4_i = function () {
		var t = new eui.Image();
		this.cirde4 = t;
		t.anchorOffsetX = 22;
		t.anchorOffsetY = 22;
		t.source = "home_circle5_png";
		t.x = 524;
		t.y = 768;
		return t;
	};
	_proto.cirde5_i = function () {
		var t = new eui.Image();
		this.cirde5 = t;
		t.anchorOffsetX = 35;
		t.anchorOffsetY = 35;
		t.source = "home_circle6_png";
		t.x = 620.64;
		t.y = 768;
		return t;
	};
	_proto.txt_i = function () {
		var t = new eui.Group();
		this.txt = t;
		t.anchorOffsetX = 206;
		t.anchorOffsetY = 55;
		t.horizontalCenter = 0;
		t.verticalCenter = -94.5;
		t.elementsContent = [this._Image1_i(),this._Image2_i(),this.txt1_i()];
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "home_txt1_png";
		t.y = 0;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.source = "home_txt2_png";
		t.visible = false;
		t.x = 40;
		t.y = 90;
		return t;
	};
	_proto.txt1_i = function () {
		var t = new eui.Label();
		this.txt1 = t;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.horizontalCenter = 0;
		t.text = "PILLAR OF THE NEW WORLD";
		t.textAlign = "center";
		t.textColor = 0xb8b6b9;
		t.y = 86.8;
		return t;
	};
	_proto.signup_btn_i = function () {
		var t = new eui.Group();
		this.signup_btn = t;
		t.bottom = 95;
		t.x = 112;
		t.elementsContent = [this._Rect2_i(),this.signup_btn_label_i()];
		return t;
	};
	_proto._Rect2_i = function () {
		var t = new eui.Rect();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillColor = 0xFFFFFF;
		t.height = 90;
		t.width = 180;
		t.x = -6;
		t.y = -6;
		return t;
	};
	_proto.signup_btn_label_i = function () {
		var t = new eui.Label();
		this.signup_btn_label = t;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.horizontalCenter = 0;
		t.size = 26;
		t.text = "SIGNUP";
		t.textColor = 0x161414;
		t.y = 32;
		return t;
	};
	_proto.login_btn_i = function () {
		var t = new eui.Group();
		this.login_btn = t;
		t.bottom = 95;
		t.height = 84;
		t.x = 472;
		t.elementsContent = [this._Rect3_i(),this.login_btn_label_i()];
		return t;
	};
	_proto._Rect3_i = function () {
		var t = new eui.Rect();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillColor = 0xffffff;
		t.height = 90;
		t.width = 180;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.login_btn_label_i = function () {
		var t = new eui.Label();
		this.login_btn_label = t;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.horizontalCenter = 0;
		t.size = 26;
		t.text = "LOGIN";
		t.textColor = 0x161414;
		t.y = 32;
		return t;
	};
	_proto.languageSelectHeard_i = function () {
		var t = new eui.Group();
		this.languageSelectHeard = t;
		t.height = 60;
		t.right = 50;
		t.width = 220;
		t.y = 90;
		t.elementsContent = [this._Rect4_i(),this.languageIcon_i(),this.languageLabel_i(),this._Image3_i()];
		return t;
	};
	_proto._Rect4_i = function () {
		var t = new eui.Rect();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.ellipseHeight = 5;
		t.ellipseWidth = 5;
		t.fillColor = 0xf0f0f0;
		t.height = 60;
		t.width = 220;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.languageIcon_i = function () {
		var t = new eui.Image();
		this.languageIcon = t;
		t.height = 38;
		t.source = "language_1_png";
		t.verticalCenter = 0;
		t.width = 38;
		t.x = 15;
		return t;
	};
	_proto.languageLabel_i = function () {
		var t = new eui.Label();
		this.languageLabel = t;
		t.bold = true;
		t.horizontalCenter = 8;
		t.size = 24;
		t.text = "English";
		t.textColor = 0x141414;
		t.verticalCenter = 0;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.source = "language_arrow_png";
		t.x = 186.99;
		t.y = 25.36;
		return t;
	};
	_proto.languageList_i = function () {
		var t = new eui.List();
		this.languageList = t;
		t.height = 240;
		t.right = 50;
		t.selectedIndex = 0;
		t.visible = false;
		t.width = 220;
		t.y = 150;
		t.itemRendererSkinName = HomeView$Skin21;
		t.dataProvider = this._ArrayCollection1_i();
		return t;
	};
	_proto._ArrayCollection1_i = function () {
		var t = new eui.ArrayCollection();
		t.source = [this._Object1_i(),this._Object2_i(),this._Object3_i(),this._Object4_i()];
		return t;
	};
	_proto._Object1_i = function () {
		var t = {};
		t.icon = "language_1_png";
		t.label = "English";
		return t;
	};
	_proto._Object2_i = function () {
		var t = {};
		t.icon = "language_2_png";
		t.label = "中文繁";
		return t;
	};
	_proto._Object3_i = function () {
		var t = {};
		t.icon = "language_3_png";
		t.label = "한글";
		return t;
	};
	_proto._Object4_i = function () {
		var t = {};
		t.icon = "language_4_png";
		t.label = "日本語";
		return t;
	};
	return HomeView;
})(eui.Skin);generateEUI.paths['resource/eui/JDPage1.exml'] = window.JDPage1 = (function (_super) {
	__extends(JDPage1, _super);
	var JDPage1$Skin22 = 	(function (_super) {
		__extends(JDPage1$Skin22, _super);
		var JDPage1$Skin22$Skin23 = 		(function (_super) {
			__extends(JDPage1$Skin22$Skin23, _super);
			function JDPage1$Skin22$Skin23() {
				_super.call(this);
				this.skinParts = ["thumb"];
				
				this.elementsContent = [this._Rect1_i(),this.thumb_i()];
			}
			var _proto = JDPage1$Skin22$Skin23.prototype;

			_proto._Rect1_i = function () {
				var t = new eui.Rect();
				t.fillColor = 0x65DDDB;
				t.percentHeight = 100;
				t.percentWidth = 100;
				return t;
			};
			_proto.thumb_i = function () {
				var t = new eui.Rect();
				this.thumb = t;
				t.fillColor = 0xf5f5f5;
				t.height = 30;
				t.width = 20;
				return t;
			};
			return JDPage1$Skin22$Skin23;
		})(eui.Skin);

		function JDPage1$Skin22() {
			_super.call(this);
			this.skinParts = ["verticalScrollBar"];
			
			this.elementsContent = [this.verticalScrollBar_i()];
		}
		var _proto = JDPage1$Skin22.prototype;

		_proto.verticalScrollBar_i = function () {
			var t = new eui.VScrollBar();
			this.verticalScrollBar = t;
			t.autoVisibility = false;
			t.percentHeight = 100;
			t.right = 5;
			t.width = 20;
			t.skinName = JDPage1$Skin22$Skin23;
			return t;
		};
		return JDPage1$Skin22;
	})(eui.Skin);

	var JDPage1$Skin24 = 	(function (_super) {
		__extends(JDPage1$Skin24, _super);
		function JDPage1$Skin24() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","jd_h_img2_png"),
						new eui.SetProperty("_Image1","alpha",0.8),
						new eui.SetProperty("labelDisplay","textColor",0x93b5ea)
					])
				,
				new eui.State ("disabled",
					[
						new eui.SetProperty("_Image1","source","jd_h_img2_png")
					])
			];
		}
		var _proto = JDPage1$Skin24.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.percentHeight = 100;
			t.source = "jd_h_img2_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.anchorOffsetX = 0;
			t.fontFamily = "norfolk";
			t.height = 50;
			t.left = 21;
			t.right = 8;
			t.size = 24;
			t.textAlign = "center";
			t.textColor = 0x759de2;
			t.verticalAlign = "middle";
			t.verticalCenter = 12;
			return t;
		};
		return JDPage1$Skin24;
	})(eui.Skin);

	var JDPage1$Skin25 = 	(function (_super) {
		__extends(JDPage1$Skin25, _super);
		function JDPage1$Skin25() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","jd_h_img3_png"),
						new eui.SetProperty("_Image1","alpha",0.8),
						new eui.SetProperty("labelDisplay","textColor",0x93b5ea)
					])
				,
				new eui.State ("disabled",
					[
						new eui.SetProperty("_Image1","source","jd_h_img3_png")
					])
			];
		}
		var _proto = JDPage1$Skin25.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.percentHeight = 100;
			t.source = "jd_h_img3_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.anchorOffsetX = 0;
			t.fontFamily = "norfolk";
			t.height = 50;
			t.left = 21;
			t.right = 30;
			t.size = 24;
			t.textAlign = "center";
			t.textColor = 0x759de2;
			t.verticalAlign = "middle";
			t.verticalCenter = 12;
			return t;
		};
		return JDPage1$Skin25;
	})(eui.Skin);

	function JDPage1() {
		_super.call(this);
		this.skinParts = ["title_bg","t1","t1_value","time_d","time_d_t","time_h","time_h_t","time_m","time_m_t","t4","t2","t3","btn1","back","btn2","btn3","loadingImg"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this._Rect1_i(),this.title_bg_i(),this._Image1_i(),this._Image2_i(),this._Group1_i(),this._Group2_i(),this._Group3_i(),this.t2_i(),this._Image7_i(),this._Image8_i(),this._Scroller1_i(),this.btn1_i(),this.back_i(),this.btn2_i(),this.btn3_i(),this.loadingImg_i()];
	}
	var _proto = JDPage1.prototype;

	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.bottom = 0;
		t.fillColor = 0xFFFFFF;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto.title_bg_i = function () {
		var t = new eui.Image();
		this.title_bg = t;
		t.right = 0;
		t.source = "jd_h_title_bg_ch_png";
		t.top = 0;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.bottom = 0;
		t.left = 0;
		t.source = "jd_h_bg2_png";
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.anchorOffsetY = 0;
		t.bottom = 143;
		t.horizontalCenter = 0;
		t.scale9Grid = new egret.Rectangle(87,123,527,408);
		t.source = "jd_h_img1_png";
		t.top = 757;
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.x = 19.36;
		t.y = 448.85;
		t.elementsContent = [this._Image3_i(),this.t1_i(),this.t1_value_i()];
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.source = "jd_h_img4_png";
		t.x = 6.14;
		t.y = 0;
		return t;
	};
	_proto.t1_i = function () {
		var t = new eui.Label();
		this.t1 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolkBold";
		t.height = 102;
		t.text = "残りのクレジット：";
		t.textAlign = "center";
		t.verticalAlign = "middle";
		t.width = 295;
		t.x = 13;
		t.y = 19.69;
		return t;
	};
	_proto.t1_value_i = function () {
		var t = new eui.Label();
		this.t1_value = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolkBold";
		t.height = 116.03;
		t.size = 60;
		t.text = "1000.000 ETH";
		t.textAlign = "left";
		t.verticalAlign = "middle";
		t.width = 419.45;
		t.x = 302.5;
		t.y = 11.01;
		return t;
	};
	_proto._Group2_i = function () {
		var t = new eui.Group();
		t.x = 40;
		t.y = 602.5;
		t.elementsContent = [this._Image4_i(),this.time_d_i(),this.time_d_t_i(),this.time_h_i(),this.time_h_t_i(),this.time_m_i(),this.time_m_t_i()];
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.source = "jd_h_img7_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.time_d_i = function () {
		var t = new eui.Label();
		this.time_d = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolkBold";
		t.size = 34;
		t.text = "00";
		t.textAlign = "center";
		t.textColor = 0xFF8A00;
		t.verticalAlign = "bottom";
		t.x = 122;
		t.y = 36.5;
		return t;
	};
	_proto.time_d_t_i = function () {
		var t = new eui.Label();
		this.time_d_t = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolkBold";
		t.size = 30;
		t.text = "d - ";
		t.textAlign = "center";
		t.textColor = 0xfdc54a;
		t.verticalAlign = "bottom";
		t.x = 168;
		t.y = 42.5;
		return t;
	};
	_proto.time_h_i = function () {
		var t = new eui.Label();
		this.time_h = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolkBold";
		t.size = 34;
		t.text = "00";
		t.textAlign = "center";
		t.textColor = 0xFF8A00;
		t.verticalAlign = "bottom";
		t.x = 225;
		t.y = 36.5;
		return t;
	};
	_proto.time_h_t_i = function () {
		var t = new eui.Label();
		this.time_h_t = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolkBold";
		t.size = 30;
		t.text = "h - ";
		t.textAlign = "center";
		t.textColor = 0xFDC54A;
		t.verticalAlign = "bottom";
		t.x = 278;
		t.y = 42.5;
		return t;
	};
	_proto.time_m_i = function () {
		var t = new eui.Label();
		this.time_m = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolkBold";
		t.size = 36;
		t.text = "00";
		t.textAlign = "center";
		t.textColor = 0xFF8A00;
		t.verticalAlign = "bottom";
		t.x = 335;
		t.y = 36.5;
		return t;
	};
	_proto.time_m_t_i = function () {
		var t = new eui.Label();
		this.time_m_t = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolkBold";
		t.size = 30;
		t.text = "m";
		t.textAlign = "center";
		t.textColor = 0xFDC54A;
		t.verticalAlign = "bottom";
		t.x = 375;
		t.y = 42.5;
		return t;
	};
	_proto._Group3_i = function () {
		var t = new eui.Group();
		t.x = 212;
		t.y = 686.76;
		t.elementsContent = [this._Image5_i(),this._Image6_i(),this.t4_i()];
		return t;
	};
	_proto._Image5_i = function () {
		var t = new eui.Image();
		t.source = "jd_h_img6_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Image6_i = function () {
		var t = new eui.Image();
		t.source = "jd_h_img5_png";
		t.x = 441.01;
		t.y = 18.24;
		return t;
	};
	_proto.t4_i = function () {
		var t = new eui.Label();
		this.t4 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolkBold";
		t.height = 83.03;
		t.size = 34;
		t.text = "  ";
		t.textAlign = "center";
		t.textColor = 0x916bd1;
		t.verticalAlign = "middle";
		t.width = 422.48;
		t.x = 8.73;
		t.y = 15.48;
		return t;
	};
	_proto.t2_i = function () {
		var t = new eui.Label();
		this.t2 = t;
		t.fontFamily = "norfolkBold";
		t.size = 36;
		t.text = "活動ルール";
		t.textColor = 0x3cb9b7;
		t.top = 832;
		t.x = 151;
		return t;
	};
	_proto._Image7_i = function () {
		var t = new eui.Image();
		t.right = 55;
		t.source = "jd_h_arrow_png";
		t.top = 839;
		return t;
	};
	_proto._Image8_i = function () {
		var t = new eui.Image();
		t.bottom = 179;
		t.right = 55;
		t.scaleY = -1;
		t.source = "jd_h_arrow_png";
		return t;
	};
	_proto._Scroller1_i = function () {
		var t = new eui.Scroller();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bottom = 220;
		t.left = 76;
		t.right = 56;
		t.top = 876;
		t.skinName = JDPage1$Skin22;
		t.viewport = this._Group4_i();
		return t;
	};
	_proto._Group4_i = function () {
		var t = new eui.Group();
		t.elementsContent = [this.t3_i()];
		return t;
	};
	_proto.t3_i = function () {
		var t = new eui.Label();
		this.t3 = t;
		t.anchorOffsetX = 0;
		t.fontFamily = "norfolk";
		t.left = 7;
		t.right = 31;
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 24;
		t.text = "今月最業上の";
		t.textColor = 0x65dddb;
		t.y = 0;
		return t;
	};
	_proto.btn1_i = function () {
		var t = new eui.Button();
		this.btn1 = t;
		t.bottom = 27;
		t.label = "Election Ranking";
		t.left = 25;
		t.skinName = JDPage1$Skin24;
		return t;
	};
	_proto.back_i = function () {
		var t = new eui.Component();
		this.back = t;
		t.skinName = "BackBtn";
		t.x = 0;
		t.y = 27;
		return t;
	};
	_proto.btn2_i = function () {
		var t = new eui.Button();
		this.btn2 = t;
		t.bottom = 27;
		t.label = "Election Voting";
		t.right = 25;
		t.skinName = JDPage1$Skin25;
		return t;
	};
	_proto.btn3_i = function () {
		var t = new eui.Image();
		this.btn3 = t;
		t.source = "jd_h_img5_png";
		t.x = 652.3;
		t.y = 704.61;
		return t;
	};
	_proto.loadingImg_i = function () {
		var t = new eui.Image();
		this.loadingImg = t;
		t.anchorOffsetX = 25;
		t.anchorOffsetY = 26;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "tool_loading_h_png";
		t.y = 264;
		return t;
	};
	return JDPage1;
})(eui.Skin);generateEUI.paths['resource/eui/JDPage3.exml'] = window.JDPage3 = (function (_super) {
	__extends(JDPage3, _super);
	function JDPage3() {
		_super.call(this);
		this.skinParts = ["back","title","group","list","loadingImg","content"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this._Rect1_i(),this.back_i(),this.title_i(),this.list_i(),this.loadingImg_i(),this._Image1_i(),this.content_i()];
	}
	var _proto = JDPage3.prototype;

	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.bottom = 0;
		t.fillColor = 0xFFFFFF;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto.back_i = function () {
		var t = new eui.Component();
		this.back = t;
		t.skinName = "BackBtn";
		t.x = 0;
		t.y = 25.24;
		return t;
	};
	_proto.title_i = function () {
		var t = new eui.Label();
		this.title = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolkBold";
		t.horizontalCenter = -0.5;
		t.lineSpacing = 6;
		t.size = 48;
		t.text = "Records";
		t.textAlign = "center";
		t.textColor = 0x375591;
		t.verticalAlign = "middle";
		t.width = 591.34;
		t.y = 39.8;
		return t;
	};
	_proto.list_i = function () {
		var t = new eui.Scroller();
		this.list = t;
		t.anchorOffsetY = 0;
		t.bottom = 142;
		t.left = 0;
		t.right = 0;
		t.top = 114;
		t.viewport = this.group_i();
		return t;
	};
	_proto.group_i = function () {
		var t = new eui.Group();
		this.group = t;
		return t;
	};
	_proto.loadingImg_i = function () {
		var t = new eui.Image();
		this.loadingImg = t;
		t.anchorOffsetX = 25;
		t.anchorOffsetY = 26;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "tool_loading_h_png";
		t.y = 229;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.anchorOffsetY = 0;
		t.bottom = 15;
		t.height = 121;
		t.horizontalCenter = 0.5;
		t.scale9Grid = new egret.Rectangle(77,14,465,87);
		t.source = "jd3_content_bg_png";
		return t;
	};
	_proto.content_i = function () {
		var t = new eui.Label();
		this.content = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bottom = 24;
		t.fontFamily = "norfolk";
		t.height = 100;
		t.horizontalCenter = 0;
		t.lineSpacing = 4;
		t.size = 24;
		t.text = " The amount of GL to be divided is determined at  the end of the event and will be transferred to the address you provided within 3 days";
		t.textAlign = "center";
		t.verticalAlign = "middle";
		t.width = 520;
		return t;
	};
	return JDPage3;
})(eui.Skin);generateEUI.paths['resource/eui/JDPage4.exml'] = window.JDPage4 = (function (_super) {
	__extends(JDPage4, _super);
	function JDPage4() {
		_super.call(this);
		this.skinParts = ["back","title","group1","list","loadingImg","msg1","t1","t2"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this._Rect1_i(),this._Image1_i(),this.back_i(),this.title_i(),this.list_i(),this.loadingImg_i(),this._Rect2_i(),this.msg1_i(),this.t1_i(),this.t2_i()];
	}
	var _proto = JDPage4.prototype;

	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.bottom = 0;
		t.fillColor = 0xFFFFFF;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.right = 0;
		t.source = "jd4_topImg_png";
		t.top = 0;
		return t;
	};
	_proto.back_i = function () {
		var t = new eui.Component();
		this.back = t;
		t.skinName = "BackBtn";
		t.x = 0;
		t.y = 25.24;
		return t;
	};
	_proto.title_i = function () {
		var t = new eui.Label();
		this.title = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolkBold";
		t.horizontalCenter = -0.5;
		t.lineSpacing = 6;
		t.size = 48;
		t.text = "Election Ranking";
		t.textAlign = "center";
		t.textColor = 0x375591;
		t.verticalAlign = "middle";
		t.width = 591.34;
		t.y = 39.8;
		return t;
	};
	_proto.list_i = function () {
		var t = new eui.Scroller();
		this.list = t;
		t.anchorOffsetY = 0;
		t.bottom = 129;
		t.left = 0;
		t.right = 0;
		t.top = 265;
		t.viewport = this.group1_i();
		return t;
	};
	_proto.group1_i = function () {
		var t = new eui.Group();
		this.group1 = t;
		return t;
	};
	_proto.loadingImg_i = function () {
		var t = new eui.Image();
		this.loadingImg = t;
		t.anchorOffsetX = 25;
		t.anchorOffsetY = 26;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "tool_loading_h_png";
		t.y = 229;
		return t;
	};
	_proto._Rect2_i = function () {
		var t = new eui.Rect();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bottom = 18;
		t.fillAlpha = 0.88;
		t.fillColor = 0x759de2;
		t.height = 96;
		t.left = 0;
		t.right = 0;
		return t;
	};
	_proto.msg1_i = function () {
		var t = new eui.Label();
		this.msg1 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bottom = 17;
		t.fontFamily = "norfolk                             ";
		t.height = 100;
		t.horizontalCenter = 0;
		t.lineSpacing = 4;
		t.size = 24;
		t.text = "After the event,  the top 7 users became selected nodes";
		t.textAlign = "center";
		t.verticalAlign = "middle";
		t.width = 520;
		return t;
	};
	_proto.t1_i = function () {
		var t = new eui.Label();
		this.t1 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk                             ";
		t.lineSpacing = 4;
		t.text = "My votes：";
		t.textColor = 0x759de2;
		t.x = 40;
		t.y = 154;
		return t;
	};
	_proto.t2_i = function () {
		var t = new eui.Label();
		this.t2 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk                             ";
		t.lineSpacing = 4;
		t.text = "0 ETH";
		t.textColor = 0x2db9b9;
		t.x = 173.22;
		t.y = 154;
		return t;
	};
	return JDPage4;
})(eui.Skin);generateEUI.paths['resource/eui/JDPage4Item1.exml'] = window.JDPage4Item1 = (function (_super) {
	__extends(JDPage4Item1, _super);
	function JDPage4Item1() {
		_super.call(this);
		this.skinParts = ["bg","num","account","nickname"];
		
		this.height = 146;
		this.width = 700;
		this.elementsContent = [this.bg_i(),this.num_i(),this.account_i(),this.nickname_i()];
	}
	var _proto = JDPage4Item1.prototype;

	_proto.bg_i = function () {
		var t = new eui.Image();
		this.bg = t;
		t.left = 0;
		t.source = "jd4_item_bg3_png";
		t.top = 0;
		return t;
	};
	_proto.num_i = function () {
		var t = new eui.Label();
		this.num = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolk                             ";
		t.lineSpacing = 4;
		t.right = 26;
		t.size = 48;
		t.text = " ";
		t.textAlign = "right";
		t.textColor = 0xffffff;
		t.y = 67;
		return t;
	};
	_proto.account_i = function () {
		var t = new eui.Label();
		this.account = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.lineSpacing = 4;
		t.size = 24;
		t.text = "***";
		t.textAlign = "right";
		t.textColor = 0xFFFFFF;
		t.x = 110;
		t.y = 56;
		return t;
	};
	_proto.nickname_i = function () {
		var t = new eui.Label();
		this.nickname = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.lineSpacing = 4;
		t.text = " ";
		t.textAlign = "right";
		t.textColor = 0xFFFFFF;
		t.x = 110;
		t.y = 92;
		return t;
	};
	return JDPage4Item1;
})(eui.Skin);generateEUI.paths['resource/eui/JDPage4Item2.exml'] = window.JDPage4Item2 = (function (_super) {
	__extends(JDPage4Item2, _super);
	function JDPage4Item2() {
		_super.call(this);
		this.skinParts = ["bg","num","account","nickname","idTxt"];
		
		this.height = 114;
		this.width = 700;
		this.elementsContent = [this.bg_i(),this.num_i(),this.account_i(),this.nickname_i(),this.idTxt_i()];
	}
	var _proto = JDPage4Item2.prototype;

	_proto.bg_i = function () {
		var t = new eui.Image();
		this.bg = t;
		t.left = 0;
		t.source = "jd4_item_bg_png";
		t.top = 0;
		return t;
	};
	_proto.num_i = function () {
		var t = new eui.Label();
		this.num = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.lineSpacing = 4;
		t.right = 26;
		t.size = 48;
		t.text = " ";
		t.textAlign = "right";
		t.textColor = 0x759de2;
		t.verticalCenter = 0;
		return t;
	};
	_proto.account_i = function () {
		var t = new eui.Label();
		this.account = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.lineSpacing = 4;
		t.size = 24;
		t.text = "***";
		t.textAlign = "right";
		t.textColor = 0x759de2;
		t.x = 110;
		t.y = 25;
		return t;
	};
	_proto.nickname_i = function () {
		var t = new eui.Label();
		this.nickname = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.lineSpacing = 4;
		t.text = " ";
		t.textAlign = "right";
		t.textColor = 0x759de2;
		t.x = 110;
		t.y = 61;
		return t;
	};
	_proto.idTxt_i = function () {
		var t = new eui.Label();
		this.idTxt = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolkBold                   ";
		t.height = 60.33;
		t.lineSpacing = 4;
		t.size = 34;
		t.text = "00";
		t.textAlign = "center";
		t.textColor = 0xffffff;
		t.verticalAlign = "middle";
		t.verticalCenter = 0;
		t.width = 77;
		t.x = 5.99;
		return t;
	};
	return JDPage4Item2;
})(eui.Skin);generateEUI.paths['resource/eui/JDPageItem.exml'] = window.JDPageItem = (function (_super) {
	__extends(JDPageItem, _super);
	function JDPageItem() {
		_super.call(this);
		this.skinParts = ["t1","t2","t3","t4","t5","txt4","txt1","txt2","txt3"];
		
		this.height = 392;
		this.width = 698;
		this.elementsContent = [this._Image1_i(),this.t1_i(),this.t2_i(),this.t3_i(),this.t4_i(),this.t5_i(),this.txt4_i(),this.txt1_i(),this.txt2_i(),this.txt3_i()];
	}
	var _proto = JDPageItem.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.left = 0;
		t.source = "jd3_item_bg_png";
		t.top = 0;
		return t;
	};
	_proto.t1_i = function () {
		var t = new eui.Label();
		this.t1 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolkBold";
		t.height = 65.03;
		t.size = 30;
		t.text = " ";
		t.textAlign = "left";
		t.verticalAlign = "middle";
		t.x = 37.5;
		t.y = 10;
		return t;
	};
	_proto.t2_i = function () {
		var t = new eui.Label();
		this.t2 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.size = 24;
		t.text = " ";
		t.textAlign = "left";
		t.textColor = 0x759de2;
		t.verticalAlign = "top";
		t.x = 38;
		t.y = 108;
		return t;
	};
	_proto.t3_i = function () {
		var t = new eui.Label();
		this.t3 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.size = 24;
		t.text = " ";
		t.textAlign = "left";
		t.textColor = 0x759DE2;
		t.verticalAlign = "top";
		t.x = 38;
		t.y = 148;
		return t;
	};
	_proto.t4_i = function () {
		var t = new eui.Label();
		this.t4 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.size = 24;
		t.text = " ";
		t.textAlign = "left";
		t.textColor = 0x759DE2;
		t.verticalAlign = "top";
		t.x = 38;
		t.y = 188;
		return t;
	};
	_proto.t5_i = function () {
		var t = new eui.Label();
		this.t5 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.size = 24;
		t.text = " ";
		t.textAlign = "left";
		t.textColor = 0x759DE2;
		t.verticalAlign = "top";
		t.x = 38;
		t.y = 227;
		return t;
	};
	_proto.txt4_i = function () {
		var t = new eui.Label();
		this.txt4 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.lineSpacing = 8;
		t.size = 24;
		t.text = " ";
		t.textAlign = "left";
		t.textColor = 0x2db9b9;
		t.verticalAlign = "top";
		t.width = 458;
		t.x = 38;
		t.y = 267;
		return t;
	};
	_proto.txt1_i = function () {
		var t = new eui.Label();
		this.txt1 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.size = 24;
		t.text = " ";
		t.textAlign = "left";
		t.textColor = 0x2db9b9;
		t.verticalAlign = "top";
		t.x = 228;
		t.y = 108;
		return t;
	};
	_proto.txt2_i = function () {
		var t = new eui.Label();
		this.txt2 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.size = 24;
		t.text = " ";
		t.textAlign = "left";
		t.textColor = 0x2db9b9;
		t.verticalAlign = "top";
		t.x = 228;
		t.y = 148;
		return t;
	};
	_proto.txt3_i = function () {
		var t = new eui.Label();
		this.txt3 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.size = 24;
		t.text = " ";
		t.textAlign = "left";
		t.textColor = 0x2db9b9;
		t.verticalAlign = "top";
		t.x = 228;
		t.y = 188;
		return t;
	};
	return JDPageItem;
})(eui.Skin);generateEUI.paths['resource/eui/LoginView.exml'] = window.LoginView = (function (_super) {
	__extends(LoginView, _super);
	var LoginView$Skin26 = 	(function (_super) {
		__extends(LoginView$Skin26, _super);
		function LoginView$Skin26() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","reg_login_btn_on_png")
					])
				,
				new eui.State ("disabled",
					[
						new eui.SetProperty("_Image1","source","reg_login_btn_on_png")
					])
			];
		}
		var _proto = LoginView$Skin26.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.percentHeight = 100;
			t.source = "reg_login_btn_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.top = 25;
			return t;
		};
		return LoginView$Skin26;
	})(eui.Skin);

	function LoginView() {
		_super.call(this);
		this.skinParts = ["account","warn0","password","warn1","login","back","tool_loading","loadPane"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this._Rect1_i(),this._Image1_i(),this._Group1_i(),this._Group2_i(),this.login_i(),this.back_i(),this.loadPane_i()];
	}
	var _proto = LoginView.prototype;

	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.bottom = 0;
		t.fillColor = 0xffffff;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "reg2_txt_title_png";
		t.y = 156;
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.verticalCenter = -211;
		t.width = 302;
		t.x = 227;
		t.elementsContent = [this.account_i(),this.warn0_i(),this._Label1_i(),this._Image2_i()];
		return t;
	};
	_proto.account_i = function () {
		var t = new eui.TextInput();
		this.account = t;
		t.height = 100;
		t.horizontalCenter = 0;
		t.width = 380;
		t.y = 0.68;
		return t;
	};
	_proto.warn0_i = function () {
		var t = new eui.Image();
		this.warn0 = t;
		t.bottom = 0;
		t.height = 40;
		t.left = -96;
		t.source = "tool_icon_warn_png";
		t.visible = false;
		t.width = 40;
		return t;
	};
	_proto._Label1_i = function () {
		var t = new eui.Label();
		t.bold = true;
		t.fontFamily = "norfolk";
		t.horizontalCenter = 0.5;
		t.size = 28;
		t.text = "EMAIL";
		t.textColor = 0x000000;
		t.top = 0;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.bottom = -2;
		t.horizontalCenter = 0;
		t.source = "reg_line_png";
		t.width = 380;
		return t;
	};
	_proto._Group2_i = function () {
		var t = new eui.Group();
		t.horizontalCenter = 0;
		t.verticalCenter = 12;
		t.width = 302;
		t.elementsContent = [this.password_i(),this.warn1_i(),this._Image3_i(),this._Label2_i(),this._Image4_i()];
		return t;
	};
	_proto.password_i = function () {
		var t = new eui.TextInput();
		this.password = t;
		t.displayAsPassword = true;
		t.height = 100;
		t.horizontalCenter = 0;
		t.width = 360;
		t.y = 0.68;
		return t;
	};
	_proto.warn1_i = function () {
		var t = new eui.Image();
		this.warn1 = t;
		t.bottom = 0;
		t.height = 40;
		t.left = -96;
		t.source = "tool_icon_warn_png";
		t.visible = false;
		t.width = 40;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "reg_txt3_png";
		t.visible = false;
		t.y = 0;
		return t;
	};
	_proto._Label2_i = function () {
		var t = new eui.Label();
		t.bold = true;
		t.fontFamily = "norfolk";
		t.horizontalCenter = 0.5;
		t.size = 28;
		t.text = "PASSWORD";
		t.textColor = 0x000000;
		t.top = 0;
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.bottom = -2;
		t.horizontalCenter = 0;
		t.source = "reg_line_png";
		t.width = 380;
		return t;
	};
	_proto.login_i = function () {
		var t = new eui.Button();
		this.login = t;
		t.bottom = 213;
		t.horizontalCenter = 0;
		t.label = "";
		t.skinName = LoginView$Skin26;
		return t;
	};
	_proto.back_i = function () {
		var t = new eui.Component();
		this.back = t;
		t.left = 20;
		t.skinName = "BackBtn";
		t.top = 46;
		return t;
	};
	_proto.loadPane_i = function () {
		var t = new eui.Group();
		this.loadPane = t;
		t.bottom = 209;
		t.horizontalCenter = 0.5;
		t.visible = false;
		t.elementsContent = [this._Image5_i(),this.tool_loading_i()];
		return t;
	};
	_proto._Image5_i = function () {
		var t = new eui.Image();
		t.source = "reg_load_btn_bg_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.tool_loading_i = function () {
		var t = new eui.Image();
		this.tool_loading = t;
		t.anchorOffsetX = 25;
		t.anchorOffsetY = 26;
		t.source = "tool_loading_png";
		t.x = 137;
		t.y = 50;
		return t;
	};
	return LoginView;
})(eui.Skin);generateEUI.paths['resource/eui/UserToolUI.exml'] = window.UserToolUI = (function (_super) {
	__extends(UserToolUI, _super);
	function UserToolUI() {
		_super.call(this);
		this.skinParts = ["account","txt"];
		
		this.height = 70;
		this.width = 587;
		this.elementsContent = [this._Rect1_i(),this._Rect2_i(),this._Image1_i(),this._Image2_i(),this._Image3_i(),this.account_i(),this.txt_i()];
	}
	var _proto = UserToolUI.prototype;

	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.ellipseHeight = 70;
		t.ellipseWidth = 70;
		t.fillColor = 0x759fe0;
		t.height = 61;
		t.right = 2;
		t.verticalCenter = 0;
		t.width = 395;
		return t;
	};
	_proto._Rect2_i = function () {
		var t = new eui.Rect();
		t.anchorOffsetY = 0;
		t.ellipseHeight = 70;
		t.ellipseWidth = 70;
		t.fillAlpha = 1;
		t.fillColor = 0xffffff;
		t.height = 61;
		t.strokeColor = 0xd2d2d2;
		t.strokeWeight = 1;
		t.verticalCenter = 0;
		t.width = 240;
		t.x = 0;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.right = 307;
		t.source = "user_icon_heard_png";
		t.verticalCenter = 3;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.source = "user_tool_icon_png";
		t.verticalCenter = 0.5;
		t.x = 18;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.right = 357;
		t.source = "user_tool_arrow_png";
		t.verticalCenter = 0.5;
		return t;
	};
	_proto.account_i = function () {
		var t = new eui.Label();
		this.account = t;
		t.anchorOffsetX = 0;
		t.fontFamily = "norfolk";
		t.multiline = false;
		t.size = 24;
		t.text = "dear";
		t.textColor = 0xffffff;
		t.x = 289;
		t.y = 21;
		return t;
	};
	_proto.txt_i = function () {
		var t = new eui.Label();
		this.txt = t;
		t.anchorOffsetX = 0;
		t.fontFamily = "norfolk";
		t.multiline = false;
		t.right = 380;
		t.size = 24;
		t.text = "dear";
		t.textColor = 0xbfbfbf;
		t.width = 141;
		t.y = 21;
		return t;
	};
	return UserToolUI;
})(eui.Skin);generateEUI.paths['resource/eui/MainView.exml'] = window.MainView = (function (_super) {
	__extends(MainView, _super);
	var MainView$Skin27 = 	(function (_super) {
		__extends(MainView$Skin27, _super);
		function MainView$Skin27() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","main_transfer_btn_off_png"),
						new eui.SetProperty("labelDisplay","textColor",0x5eee7b)
					])
				,
				new eui.State ("disabled",
					[
						new eui.SetProperty("_Image1","source","main_transfer_btn_off_png")
					])
			];
		}
		var _proto = MainView$Skin27.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.percentHeight = 100;
			t.source = "main_transfer_btn_on_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.bold = true;
			t.fontFamily = "norfolk";
			t.horizontalCenter = 0;
			t.size = 22;
			t.textColor = 0xFFFFFF;
			t.verticalCenter = -10;
			return t;
		};
		return MainView$Skin27;
	})(eui.Skin);

	var MainView$Skin28 = 	(function (_super) {
		__extends(MainView$Skin28, _super);
		function MainView$Skin28() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","main_withdrawal_btn_on_png"),
						new eui.SetProperty("_Image1","alpha",0.95),
						new eui.SetProperty("labelDisplay","textColor",0x2f63bc)
					])
				,
				new eui.State ("disabled",
					[
						new eui.SetProperty("_Image1","source","main_withdrawal_btn_on_png")
					])
			];
		}
		var _proto = MainView$Skin28.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.bottom = 0;
			t.left = -20;
			t.right = -20;
			t.scale9Grid = new egret.Rectangle(17,9,106,21);
			t.source = "main_withdrawal_btn_on_png";
			t.top = 0;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.bold = true;
			t.fontFamily = "norfolk";
			t.horizontalCenter = 0;
			t.size = 22;
			t.textColor = 0xFFFFFF;
			t.verticalCenter = -10;
			return t;
		};
		return MainView$Skin28;
	})(eui.Skin);

	function MainView() {
		_super.call(this);
		this.skinParts = ["user","time","time_icon","time_icon_pan","nav_icon","nav","mygl_txt","mygl_txt2","mygl_icon","m_transferBtn","m_transferBtn0","otTxt1","mc_img","gra_rect","mc_img0","gra_pane","speed_title","speed","speed2","team_btn","mc_img1","mc_img2","mc_img3","mc_img4","mc_img5","mc_img6","mc_img7","mc_img_pane","top_group","otTxt2","slide_index1","slide_index2","slide_index3","slide_index4","slide_index5","slide_index6","slide_index","min_nav1","min_nav2","min_nav3","min_nav6","min_nav5","min_nav4","min_nav_pan","bannerImg2","bannerImg1","bannerImgTouch","versionT"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this._Rect1_i(),this.top_group_i(),this.otTxt2_i(),this._Group3_i(),this.min_nav_pan_i(),this.bannerImgTouch_i(),this.versionT_i()];
	}
	var _proto = MainView.prototype;

	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.bottom = 0;
		t.fillColor = 0xffffff;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto.top_group_i = function () {
		var t = new eui.Group();
		this.top_group = t;
		t.x = 21;
		t.y = 0;
		t.elementsContent = [this._Image1_i(),this.user_i(),this.time_icon_pan_i(),this.nav_i(),this._Group1_i(),this.m_transferBtn_i(),this.m_transferBtn0_i(),this.otTxt1_i(),this.gra_pane_i(),this._Group2_i(),this.mc_img_pane_i()];
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.scale9Grid = new egret.Rectangle(88,76,533,461);
		t.source = "mainv_img5_png";
		t.top = 0;
		return t;
	};
	_proto.user_i = function () {
		var t = new eui.Component();
		this.user = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.skinName = "UserToolUI";
		t.x = 11;
		t.y = 13;
		return t;
	};
	_proto.time_icon_pan_i = function () {
		var t = new eui.Group();
		this.time_icon_pan = t;
		t.verticalCenter = -68.5;
		t.x = 29;
		t.elementsContent = [this.time_i(),this.time_icon_i()];
		return t;
	};
	_proto.time_i = function () {
		var t = new eui.Label();
		this.time = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.height = 48.18;
		t.multiline = false;
		t.size = 32;
		t.text = "00:00:00";
		t.textColor = 0xD81E06;
		t.verticalAlign = "middle";
		t.width = 188;
		t.x = 54.93;
		t.y = 0;
		return t;
	};
	_proto.time_icon_i = function () {
		var t = new eui.Image();
		this.time_icon = t;
		t.source = "team_icon2_png";
		t.x = 0;
		t.y = 5;
		return t;
	};
	_proto.nav_i = function () {
		var t = new eui.Group();
		this.nav = t;
		t.height = 80;
		t.width = 80;
		t.x = 641;
		t.y = -7;
		t.elementsContent = [this._Rect2_i(),this.nav_icon_i()];
		return t;
	};
	_proto._Rect2_i = function () {
		var t = new eui.Rect();
		t.fillColor = 0xffffff;
		t.height = 80;
		t.width = 80;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.nav_icon_i = function () {
		var t = new eui.Image();
		this.nav_icon = t;
		t.right = 20;
		t.source = "mainv_img23_png";
		t.top = 25;
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.bottom = 234;
		t.x = 29;
		t.elementsContent = [this.mygl_txt_i(),this.mygl_txt2_i(),this.mygl_icon_i()];
		return t;
	};
	_proto.mygl_txt_i = function () {
		var t = new eui.Label();
		this.mygl_txt = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.bottom = 0;
		t.fontFamily = "norfolk";
		t.height = 48;
		t.multiline = true;
		t.size = 36;
		t.text = "my Gl: 0.";
		t.textAlign = "left";
		t.textColor = 0x84f59b;
		t.verticalAlign = "bottom";
		t.x = 0;
		return t;
	};
	_proto.mygl_txt2_i = function () {
		var t = new eui.Label();
		this.mygl_txt2 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.bottom = 22;
		t.fontFamily = "norfolk";
		t.height = 27.5;
		t.multiline = false;
		t.size = 26;
		t.text = "000";
		t.textAlign = "left";
		t.textColor = 0x84F59B;
		t.x = 141;
		return t;
	};
	_proto.mygl_icon_i = function () {
		var t = new eui.Image();
		this.mygl_icon = t;
		t.bottom = 0;
		t.height = 40;
		t.source = "icon_coin_G_png";
		t.width = 40;
		t.x = 208.34;
		return t;
	};
	_proto.m_transferBtn_i = function () {
		var t = new eui.Button();
		this.m_transferBtn = t;
		t.bottom = 139;
		t.label = "Transfer";
		t.right = 549;
		t.skinName = MainView$Skin27;
		return t;
	};
	_proto.m_transferBtn0_i = function () {
		var t = new eui.Button();
		this.m_transferBtn0 = t;
		t.bottom = 139;
		t.label = "提币";
		t.left = 220;
		t.skinName = MainView$Skin28;
		return t;
	};
	_proto.otTxt1_i = function () {
		var t = new eui.Label();
		this.otTxt1 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.bottom = 42;
		t.fontFamily = "norfolk";
		t.height = 48;
		t.multiline = false;
		t.size = 20;
		t.text = "You need to activate your account every 24H.";
		t.textAlign = "left";
		t.textColor = 0xdadde2;
		t.verticalAlign = "middle";
		t.width = 552.76;
		t.x = 29;
		return t;
	};
	_proto.gra_pane_i = function () {
		var t = new eui.Group();
		this.gra_pane = t;
		t.verticalCenter = 14.5;
		t.x = 533.8;
		t.elementsContent = [this.mc_img_i(),this.gra_rect_i(),this.mc_img0_i()];
		return t;
	};
	_proto.mc_img_i = function () {
		var t = new eui.Image();
		this.mc_img = t;
		t.anchorOffsetX = 101.5;
		t.anchorOffsetY = 101.5;
		t.source = "mc_img_r4_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.gra_rect_i = function () {
		var t = new eui.Rect();
		this.gra_rect = t;
		t.anchorOffsetX = 101.5;
		t.anchorOffsetY = 101.5;
		t.fillAlpha = 0;
		t.fillColor = 0x2db9b8;
		t.height = 203;
		t.width = 203;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.mc_img0_i = function () {
		var t = new eui.Image();
		this.mc_img0 = t;
		t.anchorOffsetX = 29;
		t.anchorOffsetY = 31;
		t.source = "mc_img_r_min_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Group2_i = function () {
		var t = new eui.Group();
		t.bottom = 60;
		t.x = 29;
		t.elementsContent = [this.speed_title_i(),this.speed_i(),this.speed2_i(),this.team_btn_i()];
		return t;
	};
	_proto.speed_title_i = function () {
		var t = new eui.Label();
		this.speed_title = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.height = 48;
		t.multiline = false;
		t.size = 26;
		t.text = "YOUR MINING EFFICIENCY: ";
		t.textAlign = "left";
		t.textColor = 0x466A9D;
		t.verticalAlign = "bottom";
		t.x = 0;
		t.y = -3.91;
		return t;
	};
	_proto.speed_i = function () {
		var t = new eui.Label();
		this.speed = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.height = 48;
		t.multiline = false;
		t.size = 32;
		t.text = "0GL/H";
		t.textAlign = "left";
		t.textColor = 0x759de2;
		t.verticalAlign = "bottom";
		t.x = 369;
		t.y = -4;
		return t;
	};
	_proto.speed2_i = function () {
		var t = new eui.Label();
		this.speed2 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.height = 48;
		t.multiline = false;
		t.size = 20;
		t.text = "+10%";
		t.textAlign = "left";
		t.textColor = 0xfdc54a;
		t.verticalAlign = "bottom";
		t.x = 461;
		t.y = -5.91;
		return t;
	};
	_proto.team_btn_i = function () {
		var t = new eui.Group();
		this.team_btn = t;
		t.height = 70;
		t.width = 70;
		t.x = 541.43;
		t.y = -2.66;
		t.elementsContent = [this._Rect3_i(),this._Image2_i()];
		return t;
	};
	_proto._Rect3_i = function () {
		var t = new eui.Rect();
		t.bottom = 0;
		t.fillAlpha = 0.01;
		t.fillColor = 0xffffff;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "teamv_img_add_png";
		t.verticalCenter = 0;
		return t;
	};
	_proto.mc_img_pane_i = function () {
		var t = new eui.Group();
		this.mc_img_pane = t;
		t.anchorOffsetY = 248.5;
		t.height = 467;
		t.touchChildren = true;
		t.touchEnabled = false;
		t.width = 430;
		t.x = 273;
		t.y = 268.5;
		t.elementsContent = [this.mc_img1_i(),this.mc_img2_i(),this.mc_img3_i(),this.mc_img4_i(),this.mc_img5_i(),this.mc_img6_i(),this.mc_img7_i()];
		return t;
	};
	_proto.mc_img1_i = function () {
		var t = new eui.Image();
		this.mc_img1 = t;
		t.anchorOffsetX = 13;
		t.anchorOffsetY = 13;
		t.height = 26;
		t.source = "mc_img_r2_png";
		t.touchEnabled = false;
		t.width = 26;
		t.x = 127;
		t.y = 66;
		return t;
	};
	_proto.mc_img2_i = function () {
		var t = new eui.Image();
		this.mc_img2 = t;
		t.anchorOffsetX = 18;
		t.anchorOffsetY = 18;
		t.height = 36;
		t.source = "mc_img_r3_png";
		t.touchEnabled = false;
		t.width = 36;
		t.x = 238;
		t.y = 17;
		return t;
	};
	_proto.mc_img3_i = function () {
		var t = new eui.Image();
		this.mc_img3 = t;
		t.anchorOffsetX = 17;
		t.anchorOffsetY = 17;
		t.height = 34;
		t.source = "mc_img_r5_png";
		t.touchEnabled = false;
		t.width = 34;
		t.x = 361;
		t.y = 79;
		return t;
	};
	_proto.mc_img4_i = function () {
		var t = new eui.Image();
		this.mc_img4 = t;
		t.anchorOffsetX = 22;
		t.anchorOffsetY = 22;
		t.source = "mc_img_r2_png";
		t.touchEnabled = false;
		t.x = 408;
		t.y = 352;
		return t;
	};
	_proto.mc_img5_i = function () {
		var t = new eui.Image();
		this.mc_img5 = t;
		t.anchorOffsetX = 42;
		t.anchorOffsetY = 42;
		t.source = "mc_img_r1_png";
		t.touchEnabled = false;
		t.x = 306.3;
		t.y = 424.85;
		return t;
	};
	_proto.mc_img6_i = function () {
		var t = new eui.Image();
		this.mc_img6 = t;
		t.anchorOffsetX = 24.5;
		t.anchorOffsetY = 24.5;
		t.source = "mc_img_r3_png";
		t.touchEnabled = false;
		t.x = 133;
		t.y = 386;
		return t;
	};
	_proto.mc_img7_i = function () {
		var t = new eui.Image();
		this.mc_img7 = t;
		t.anchorOffsetX = 40.5;
		t.anchorOffsetY = 40.5;
		t.source = "mc_img_r5_png";
		t.touchEnabled = false;
		t.x = 49;
		t.y = 257.59;
		return t;
	};
	_proto.otTxt2_i = function () {
		var t = new eui.Label();
		this.otTxt2 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.bottom = 412;
		t.fontFamily = "norfolk";
		t.height = 48;
		t.multiline = false;
		t.size = 48;
		t.text = "EXPLORE";
		t.textAlign = "left";
		t.textColor = 0x466a9d;
		t.verticalAlign = "middle";
		t.x = 31;
		return t;
	};
	_proto._Group3_i = function () {
		var t = new eui.Group();
		t.bottom = 35;
		t.horizontalCenter = 0;
		t.width = 360;
		t.elementsContent = [this.slide_index1_i(),this.slide_index2_i(),this.slide_index3_i(),this.slide_index4_i(),this.slide_index5_i(),this.slide_index6_i(),this.slide_index_i()];
		return t;
	};
	_proto.slide_index1_i = function () {
		var t = new eui.Image();
		this.slide_index1 = t;
		t.anchorOffsetX = 5;
		t.anchorOffsetY = 5;
		t.source = "mainv_img8_png";
		t.x = 0;
		t.y = 10;
		return t;
	};
	_proto.slide_index2_i = function () {
		var t = new eui.Image();
		this.slide_index2 = t;
		t.anchorOffsetX = 5;
		t.anchorOffsetY = 5;
		t.source = "mainv_img8_png";
		t.x = 70;
		t.y = 10;
		return t;
	};
	_proto.slide_index3_i = function () {
		var t = new eui.Image();
		this.slide_index3 = t;
		t.anchorOffsetX = 5;
		t.anchorOffsetY = 5;
		t.source = "mainv_img8_png";
		t.x = 140;
		t.y = 10;
		return t;
	};
	_proto.slide_index4_i = function () {
		var t = new eui.Image();
		this.slide_index4 = t;
		t.anchorOffsetX = 5;
		t.anchorOffsetY = 5;
		t.source = "mainv_img8_png";
		t.x = 210;
		t.y = 10;
		return t;
	};
	_proto.slide_index5_i = function () {
		var t = new eui.Image();
		this.slide_index5 = t;
		t.anchorOffsetX = 5;
		t.anchorOffsetY = 5;
		t.source = "mainv_img8_png";
		t.x = 280;
		t.y = 10;
		return t;
	};
	_proto.slide_index6_i = function () {
		var t = new eui.Image();
		this.slide_index6 = t;
		t.anchorOffsetX = 5;
		t.anchorOffsetY = 5;
		t.source = "mainv_img8_png";
		t.x = 350;
		t.y = 10;
		return t;
	};
	_proto.slide_index_i = function () {
		var t = new eui.Image();
		this.slide_index = t;
		t.anchorOffsetX = 10;
		t.anchorOffsetY = 10;
		t.source = "mainv_img7_png";
		t.x = 0;
		t.y = 10;
		return t;
	};
	_proto.min_nav_pan_i = function () {
		var t = new eui.Group();
		this.min_nav_pan = t;
		t.anchorOffsetY = 0;
		t.bottom = 0;
		t.height = 394;
		t.left = 0;
		t.right = 0;
		t.elementsContent = [this._Rect4_i(),this.min_nav1_i(),this.min_nav2_i(),this.min_nav3_i(),this.min_nav6_i(),this.min_nav5_i(),this.min_nav4_i()];
		return t;
	};
	_proto._Rect4_i = function () {
		var t = new eui.Rect();
		t.anchorOffsetY = 0;
		t.bottom = 0;
		t.fillAlpha = 0.01;
		t.fillColor = 0xffffff;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto.min_nav1_i = function () {
		var t = new eui.Image();
		this.min_nav1 = t;
		t.anchorOffsetX = 111.5;
		t.anchorOffsetY = 161.5;
		t.height = 323;
		t.source = "mainv_rect1_png";
		t.width = 223;
		t.x = 888.5;
		t.y = 200;
		return t;
	};
	_proto.min_nav2_i = function () {
		var t = new eui.Image();
		this.min_nav2 = t;
		t.anchorOffsetX = 111.5;
		t.anchorOffsetY = 161.5;
		t.height = 323;
		t.source = "mainv_rect2_png";
		t.width = 223;
		t.x = 888.5;
		t.y = 0;
		return t;
	};
	_proto.min_nav3_i = function () {
		var t = new eui.Image();
		this.min_nav3 = t;
		t.anchorOffsetX = 111.5;
		t.anchorOffsetY = 161.5;
		t.height = 323;
		t.source = "mainv_rect3_png";
		t.width = 223;
		t.x = 888.5;
		t.y = 0;
		return t;
	};
	_proto.min_nav6_i = function () {
		var t = new eui.Image();
		this.min_nav6 = t;
		t.anchorOffsetX = 111.5;
		t.anchorOffsetY = 161.5;
		t.height = 323;
		t.source = "mainv_rect6_png";
		t.width = 223;
		t.x = 888.5;
		t.y = 0;
		return t;
	};
	_proto.min_nav5_i = function () {
		var t = new eui.Image();
		this.min_nav5 = t;
		t.anchorOffsetX = 111.5;
		t.anchorOffsetY = 161.5;
		t.height = 323;
		t.source = "mainv_rect5_png";
		t.width = 223;
		t.x = 888.5;
		t.y = 0;
		return t;
	};
	_proto.min_nav4_i = function () {
		var t = new eui.Image();
		this.min_nav4 = t;
		t.anchorOffsetX = 111.5;
		t.anchorOffsetY = 161.5;
		t.height = 323;
		t.source = "mainv_rect4_png";
		t.width = 223;
		t.x = 888.5;
		t.y = 0;
		return t;
	};
	_proto.bannerImgTouch_i = function () {
		var t = new eui.Group();
		this.bannerImgTouch = t;
		t.bottom = 476;
		t.height = 109;
		t.width = 750;
		t.x = 0;
		t.elementsContent = [this.bannerImg2_i(),this.bannerImg1_i()];
		return t;
	};
	_proto.bannerImg2_i = function () {
		var t = new eui.Image();
		this.bannerImg2 = t;
		t.anchorOffsetX = 348.5;
		t.anchorOffsetY = 108.5;
		t.source = "icon_vote_ch_png";
		t.x = 375;
		t.y = 0;
		return t;
	};
	_proto.bannerImg1_i = function () {
		var t = new eui.Image();
		this.bannerImg1 = t;
		t.anchorOffsetX = 348.5;
		t.anchorOffsetY = 108.5;
		t.source = "icon_vote_ch_png";
		t.x = 375;
		t.y = 0;
		return t;
	};
	_proto.versionT_i = function () {
		var t = new eui.Label();
		this.versionT = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bottom = 25;
		t.fontFamily = "norfolk";
		t.height = 39;
		t.size = 20;
		t.text = "v 1.0.1";
		t.textColor = 0xcfcccf;
		t.verticalAlign = "middle";
		t.width = 104;
		t.x = 28.93;
		return t;
	};
	return MainView;
})(eui.Skin);generateEUI.paths['resource/eui/MorepowerPage.exml'] = window.MorepowerPage = (function (_super) {
	__extends(MorepowerPage, _super);
	function MorepowerPage() {
		_super.call(this);
		this.skinParts = ["back","txt1","txt2","title"];
		
		this.height = 1698;
		this.width = 750;
		this.elementsContent = [this._Rect1_i(),this.back_i(),this._Scroller1_i(),this.title_i()];
	}
	var _proto = MorepowerPage.prototype;

	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.bottom = 0;
		t.fillColor = 0xFFFFFF;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto.back_i = function () {
		var t = new eui.Group();
		this.back = t;
		t.height = 80;
		t.x = 18.03;
		t.y = 25;
		t.elementsContent = [this._Rect2_i(),this._Image1_i()];
		return t;
	};
	_proto._Rect2_i = function () {
		var t = new eui.Rect();
		t.fillColor = 0xFFFFFF;
		t.height = 80;
		t.width = 80;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "icon_back22_png";
		t.verticalCenter = 0;
		return t;
	};
	_proto._Scroller1_i = function () {
		var t = new eui.Scroller();
		t.anchorOffsetY = 0;
		t.bottom = 33;
		t.left = 0;
		t.right = 0;
		t.top = 143;
		t.viewport = this._Group1_i();
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.width = 750;
		t.elementsContent = [this.txt1_i(),this.txt2_i()];
		return t;
	};
	_proto.txt1_i = function () {
		var t = new eui.Image();
		this.txt1 = t;
		t.anchorOffsetY = 0;
		t.height = 1331;
		t.horizontalCenter = 0;
		t.source = "getpower_txt1_en_png";
		t.y = -15;
		return t;
	};
	_proto.txt2_i = function () {
		var t = new eui.Image();
		this.txt2 = t;
		t.horizontalCenter = 0;
		t.source = "getpower_txt2_en_png";
		t.y = 1396;
		return t;
	};
	_proto.title_i = function () {
		var t = new eui.Label();
		this.title = t;
		t.anchorOffsetX = 0;
		t.bold = true;
		t.fontFamily = "norfolkBold";
		t.size = 44;
		t.text = "Calculation";
		t.textAlign = "center";
		t.textColor = 0x5a66b4;
		t.width = 388;
		t.x = 192;
		t.y = 43.65;
		return t;
	};
	return MorepowerPage;
})(eui.Skin);generateEUI.paths['resource/eui/MyButtonSkin.exml'] = window.skins.MyButtonSkin = (function (_super) {
	__extends(MyButtonSkin, _super);
	function MyButtonSkin() {
		_super.call(this);
		this.skinParts = ["labelDisplay","iconDisplay"];
		
		this.minHeight = 50;
		this.minWidth = 100;
		this.elementsContent = [this._Image1_i(),this.labelDisplay_i(),this.iconDisplay_i()];
		this.states = [
			new eui.State ("up",
				[
				])
			,
			new eui.State ("down",
				[
					new eui.SetProperty("_Image1","source","team_btn_bg22_png"),
					new eui.SetProperty("labelDisplay","top",15),
					new eui.SetProperty("labelDisplay","textColor",0xf6c35d)
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("_Image1","alpha",0.5)
				])
		];
	}
	var _proto = MyButtonSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.percentHeight = 100;
		t.scale9Grid = new egret.Rectangle(1,3,8,8);
		t.source = "team_btn_bg_png";
		t.percentWidth = 100;
		return t;
	};
	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.bottom = 21;
		t.fontFamily = "norfolk";
		t.left = 8;
		t.right = 8;
		t.size = 22;
		t.text = "";
		t.textAlign = "center";
		t.textColor = 0xFFFFFF;
		t.top = -5;
		t.verticalAlign = "middle";
		return t;
	};
	_proto.iconDisplay_i = function () {
		var t = new eui.Image();
		this.iconDisplay = t;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		return t;
	};
	return MyButtonSkin;
})(eui.Skin);generateEUI.paths['resource/eui/MyButtonSkin5.exml'] = window.skins.MyButtonSkin5 = (function (_super) {
	__extends(MyButtonSkin5, _super);
	function MyButtonSkin5() {
		_super.call(this);
		this.skinParts = ["labelDisplay","iconDisplay"];
		
		this.minHeight = 50;
		this.minWidth = 100;
		this.elementsContent = [this._Image1_i(),this.labelDisplay_i(),this.iconDisplay_i()];
		this.states = [
			new eui.State ("up",
				[
				])
			,
			new eui.State ("down",
				[
					new eui.SetProperty("_Image1","source","team_btn_bg3_png"),
					new eui.SetProperty("labelDisplay","top",15),
					new eui.SetProperty("labelDisplay","textColor",0xf6c35d)
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("_Image1","alpha",0.5)
				])
		];
	}
	var _proto = MyButtonSkin5.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.percentHeight = 100;
		t.scale9Grid = new egret.Rectangle(1,3,8,8);
		t.source = "team_btn_bg_png";
		t.percentWidth = 100;
		return t;
	};
	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.bottom = 21;
		t.left = 8;
		t.right = 8;
		t.size = 22;
		t.text = "";
		t.textAlign = "center";
		t.textColor = 0xFFFFFF;
		t.top = -5;
		t.verticalAlign = "middle";
		return t;
	};
	_proto.iconDisplay_i = function () {
		var t = new eui.Image();
		this.iconDisplay = t;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		return t;
	};
	return MyButtonSkin5;
})(eui.Skin);generateEUI.paths['resource/eui/MyInput.exml'] = window.MyInput = (function (_super) {
	__extends(MyInput, _super);
	function MyInput() {
		_super.call(this);
		this.skinParts = ["bg","input"];
		
		this.height = 80;
		this.width = 420;
		this.elementsContent = [this.bg_i(),this.input_i()];
	}
	var _proto = MyInput.prototype;

	_proto.bg_i = function () {
		var t = new eui.Rect();
		this.bg = t;
		t.bottom = 0;
		t.ellipseHeight = 28;
		t.ellipseWidth = 28;
		t.fillColor = 0xFFFFFF;
		t.left = 0;
		t.right = 0;
		t.strokeColor = 0xFFFFFF;
		t.top = 0;
		return t;
	};
	_proto.input_i = function () {
		var t = new eui.EditableText();
		this.input = t;
		t.anchorOffsetY = 0;
		t.bottom = "5";
		t.left = "62";
		t.promptColor = 0xc0c0c0;
		t.right = "5";
		t.size = 28;
		t.text = "";
		t.textAlign = "left";
		t.textColor = 0xffd000;
		t.top = "5";
		t.verticalAlign = "middle";
		return t;
	};
	return MyInput;
})(eui.Skin);generateEUI.paths['resource/eui/MyPopWindow.exml'] = window.MyPopWindow = (function (_super) {
	__extends(MyPopWindow, _super);
	function MyPopWindow() {
		_super.call(this);
		this.skinParts = ["bg","title","lableContent","image","btnClose","btnComfirm","loadingImg","btnComfirmGroup"];
		
		this.height = 1334;
		this.width = 750;
		this._TweenGroup1_i();
		this.elementsContent = [this.bg_i(),this._Image1_i(),this.title_i(),this.lableContent_i(),this.image_i(),this.btnClose_i(),this.btnComfirm_i(),this.btnComfirmGroup_i()];
		
		eui.Binding.$bindProperties(this, ["image"],[0],this._TweenItem1,"target");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object1,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object1,"rotation");
		eui.Binding.$bindProperties(this, [1.2],[],this._Object1,"scaleX");
		eui.Binding.$bindProperties(this, [1.2],[],this._Object1,"scaleY");
		eui.Binding.$bindProperties(this, [1],[],this._Object2,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object2,"rotation");
		eui.Binding.$bindProperties(this, [1.4],[],this._Object2,"scaleX");
		eui.Binding.$bindProperties(this, [1.4],[],this._Object2,"scaleY");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object3,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object3,"rotation");
		eui.Binding.$bindProperties(this, [1.2],[],this._Object3,"scaleX");
		eui.Binding.$bindProperties(this, [1.2],[],this._Object3,"scaleY");
	}
	var _proto = MyPopWindow.prototype;

	_proto._TweenGroup1_i = function () {
		var t = new egret.tween.TweenGroup();
		t.items = [this._TweenItem1_i()];
		return t;
	};
	_proto._TweenItem1_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem1 = t;
		t.paths = [this._Set1_i(),this._To1_i(),this._To2_i()];
		return t;
	};
	_proto._Set1_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object1_i();
		return t;
	};
	_proto._Object1_i = function () {
		var t = {};
		this._Object1 = t;
		return t;
	};
	_proto._To1_i = function () {
		var t = new egret.tween.To();
		t.duration = 2000;
		t.ease = "circIn";
		t.props = this._Object2_i();
		return t;
	};
	_proto._Object2_i = function () {
		var t = {};
		this._Object2 = t;
		return t;
	};
	_proto._To2_i = function () {
		var t = new egret.tween.To();
		t.duration = 2000;
		t.ease = "circOut";
		t.props = this._Object3_i();
		return t;
	};
	_proto._Object3_i = function () {
		var t = {};
		this._Object3 = t;
		return t;
	};
	_proto.bg_i = function () {
		var t = new eui.Rect();
		this.bg = t;
		t.bottom = 0;
		t.fillAlpha = 0.05;
		t.fillColor = 0xffffff;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.height = 323;
		t.scale9Grid = new egret.Rectangle(88,76,533,461);
		t.source = "mainv_img5_png";
		t.x = 21;
		t.y = 516;
		return t;
	};
	_proto.title_i = function () {
		var t = new eui.Label();
		this.title = t;
		t.fontFamily = "norfolk";
		t.size = 32;
		t.text = "Attention";
		t.textColor = 0x7f93b4;
		t.x = 315;
		t.y = 575;
		return t;
	};
	_proto.lableContent_i = function () {
		var t = new eui.Label();
		this.lableContent = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.height = 73.58;
		t.horizontalCenter = 21.5;
		t.lineSpacing = 4;
		t.size = 24;
		t.text = "The current mining difficulty is 1, which shall be started after deducting 0,1GL miner's fee";
		t.textColor = 0x7F93B4;
		t.width = 541.31;
		t.y = 634;
		return t;
	};
	_proto.image_i = function () {
		var t = new eui.Image();
		this.image = t;
		t.anchorOffsetX = 138.5;
		t.anchorOffsetY = 89;
		t.scaleX = 1.4;
		t.scaleY = 1.4;
		t.source = "coming_img_bg_png";
		t.visible = false;
		t.x = 367;
		t.y = 666;
		return t;
	};
	_proto.btnClose_i = function () {
		var t = new eui.Image();
		this.btnClose = t;
		t.height = 35;
		t.source = "icon_close_png";
		t.width = 35;
		t.x = 650;
		t.y = 540;
		return t;
	};
	_proto.btnComfirm_i = function () {
		var t = new eui.Button();
		this.btnComfirm = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 44;
		t.horizontalCenter = -10.5;
		t.label = "Mining";
		t.scaleX = 1;
		t.scaleY = 1;
		t.skinName = "skins.ButtonSkin";
		t.width = 95.46;
		t.y = 730;
		return t;
	};
	_proto.btnComfirmGroup_i = function () {
		var t = new eui.Group();
		this.btnComfirmGroup = t;
		t.scaleX = 0.5;
		t.scaleY = 0.5;
		t.visible = false;
		t.x = 297;
		t.y = 722.8;
		t.elementsContent = [this._Image2_i(),this.loadingImg_i()];
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.source = "reg_load_btn_bg_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.loadingImg_i = function () {
		var t = new eui.Image();
		this.loadingImg = t;
		t.anchorOffsetX = 25;
		t.anchorOffsetY = 26;
		t.source = "tool_loading_png";
		t.x = 137;
		t.y = 50;
		return t;
	};
	return MyPopWindow;
})(eui.Skin);generateEUI.paths['resource/eui/NavsUI.exml'] = window.NavsUI = (function (_super) {
	__extends(NavsUI, _super);
	var NavsUI$Skin29 = 	(function (_super) {
		__extends(NavsUI$Skin29, _super);
		function NavsUI$Skin29() {
			_super.call(this);
			this.skinParts = [];
			
			this.height = 60;
			this.elementsContent = [this._Rect1_i(),this._Image1_i(),this._Label1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Rect1","fillColor",0xaaaaaa),
						new eui.SetProperty("_Label1","textColor",0x4665a0)
					])
				,
				new eui.State ("disabled",
					[
					])
			];
			
			eui.Binding.$bindProperties(this, ["hostComponent.data.icon"],[0],this._Image1,"source");
			eui.Binding.$bindProperties(this, ["hostComponent.data.label"],[0],this._Label1,"text");
		}
		var _proto = NavsUI$Skin29.prototype;

		_proto._Rect1_i = function () {
			var t = new eui.Rect();
			this._Rect1 = t;
			t.anchorOffsetX = 0;
			t.anchorOffsetY = 0;
			t.ellipseHeight = 5;
			t.ellipseWidth = 5;
			t.fillColor = 0xeeeeee;
			t.height = 60;
			t.width = 220;
			t.x = 0;
			t.y = 0;
			return t;
		};
		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.height = 38;
			t.verticalCenter = 0;
			t.width = 38;
			t.x = 15;
			return t;
		};
		_proto._Label1_i = function () {
			var t = new eui.Label();
			this._Label1 = t;
			t.bold = true;
			t.horizontalCenter = 8;
			t.size = 24;
			t.textColor = 0x365590;
			t.verticalCenter = 0;
			return t;
		};
		return NavsUI$Skin29;
	})(eui.Skin);

	function NavsUI() {
		_super.call(this);
		this.skinParts = ["bg","close","t2","t3","t4","t5","t6","t7","t8","t9","t10","btn2","btn3","btn4","btn5","btn6","btn7","btn8","btn9","btn10","t11","btn11","languageIcon","languageLabel","languageSelectHeard","languageList"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this.bg_i(),this._Image1_i(),this._Image2_i(),this.close_i(),this._Group1_i(),this.t2_i(),this.t3_i(),this.t4_i(),this.t5_i(),this.t6_i(),this.t7_i(),this.t8_i(),this.t9_i(),this.t10_i(),this.btn2_i(),this.btn3_i(),this.btn4_i(),this.btn5_i(),this.btn6_i(),this.btn7_i(),this.btn8_i(),this.btn9_i(),this.btn10_i(),this.t11_i(),this.btn11_i(),this.languageSelectHeard_i(),this.languageList_i()];
	}
	var _proto = NavsUI.prototype;

	_proto.bg_i = function () {
		var t = new eui.Rect();
		this.bg = t;
		t.bottom = 0;
		t.fillAlpha = 0.1;
		t.fillColor = 0xffffff;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.anchorOffsetY = 0;
		t.height = 1118;
		t.horizontalCenter = 0.5;
		t.scale9Grid = new egret.Rectangle(88,76,533,461);
		t.source = "tool_alert_bg_png";
		t.y = 39;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "nav_img2_png";
		t.y = 59.92;
		return t;
	};
	_proto.close_i = function () {
		var t = new eui.Group();
		this.close = t;
		t.touchChildren = false;
		t.x = 632.6;
		t.y = 43.81;
		t.elementsContent = [this._Rect1_i(),this._Image3_i()];
		return t;
	};
	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.ellipseHeight = 50;
		t.ellipseWidth = 50;
		t.fillColor = 0xFFFFFF;
		t.height = 80;
		t.width = 80;
		t.x = 1.52;
		t.y = 0;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.source = "icon_close_png";
		t.x = 25;
		t.y = 25;
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.x = 81;
		t.y = 1048.79;
		t.elementsContent = [this._Image4_i(),this._Image5_i(),this._Image6_i()];
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.source = "nav_img3_png";
		t.x = 309;
		t.y = 41.3;
		return t;
	};
	_proto._Image5_i = function () {
		var t = new eui.Image();
		t.source = "nav_line_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Image6_i = function () {
		var t = new eui.Image();
		t.source = "nav_img1_png";
		t.x = 249;
		t.y = 41.3;
		return t;
	};
	_proto.t2_i = function () {
		var t = new eui.Label();
		this.t2 = t;
		t.bold = true;
		t.fontFamily = "norfolkBold";
		t.horizontalCenter = 0;
		t.size = 24;
		t.text = "GET MORE POWER";
		t.textAlign = "center";
		t.textColor = 0x365590;
		t.y = 193;
		return t;
	};
	_proto.t3_i = function () {
		var t = new eui.Label();
		this.t3 = t;
		t.bold = true;
		t.fontFamily = "norfolkBold";
		t.horizontalCenter = 0;
		t.size = 24;
		t.text = "GREEN PAPER";
		t.textAlign = "center";
		t.textColor = 0x365590;
		t.y = 260;
		return t;
	};
	_proto.t4_i = function () {
		var t = new eui.Label();
		this.t4 = t;
		t.bold = true;
		t.fontFamily = "norfolkBold";
		t.horizontalCenter = 0;
		t.size = 24;
		t.text = "TEAM";
		t.textAlign = "center";
		t.textColor = 0x365590;
		t.y = 326;
		return t;
	};
	_proto.t5_i = function () {
		var t = new eui.Label();
		this.t5 = t;
		t.bold = true;
		t.fontFamily = "norfolkBold";
		t.horizontalCenter = 0;
		t.size = 24;
		t.text = "CONTACT US";
		t.textAlign = "center";
		t.textColor = 0x365590;
		t.y = 393;
		return t;
	};
	_proto.t6_i = function () {
		var t = new eui.Label();
		this.t6 = t;
		t.bold = true;
		t.fontFamily = "norfolkBold";
		t.horizontalCenter = 0;
		t.size = 24;
		t.text = "CHANGE PASSWORD";
		t.textAlign = "center";
		t.textColor = 0x365590;
		t.y = 459;
		return t;
	};
	_proto.t7_i = function () {
		var t = new eui.Label();
		this.t7 = t;
		t.bold = true;
		t.fontFamily = "norfolkBold";
		t.horizontalCenter = 0;
		t.size = 24;
		t.text = "GOOGLE AUTHENTICATOR";
		t.textAlign = "center";
		t.textColor = 0x365590;
		t.y = 526;
		return t;
	};
	_proto.t8_i = function () {
		var t = new eui.Label();
		this.t8 = t;
		t.bold = true;
		t.fontFamily = "norfolkBold";
		t.horizontalCenter = 0;
		t.size = 24;
		t.text = "GL TRANSFER";
		t.textAlign = "center";
		t.textColor = 0x365590;
		t.y = 592;
		return t;
	};
	_proto.t9_i = function () {
		var t = new eui.Label();
		this.t9 = t;
		t.bold = true;
		t.fontFamily = "norfolkBold";
		t.horizontalCenter = 0;
		t.size = 24;
		t.text = "GIP";
		t.textAlign = "center";
		t.textColor = 0x365590;
		t.y = 658;
		return t;
	};
	_proto.t10_i = function () {
		var t = new eui.Label();
		this.t10 = t;
		t.bold = true;
		t.fontFamily = "norfolkBold";
		t.horizontalCenter = 0;
		t.size = 24;
		t.text = "GL WITHDRAWAL";
		t.textAlign = "center";
		t.textColor = 0x365590;
		t.y = 724;
		return t;
	};
	_proto.btn2_i = function () {
		var t = new eui.Rect();
		this.btn2 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillAlpha = 0.01;
		t.fillColor = 0xffffff;
		t.height = 50;
		t.horizontalCenter = 0;
		t.width = 231;
		t.y = 176;
		return t;
	};
	_proto.btn3_i = function () {
		var t = new eui.Rect();
		this.btn3 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillAlpha = 0.01;
		t.fillColor = 0xFFFFFF;
		t.height = 50;
		t.width = 212;
		t.x = 269;
		t.y = 244;
		return t;
	};
	_proto.btn4_i = function () {
		var t = new eui.Rect();
		this.btn4 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillAlpha = 0.01;
		t.fillColor = 0xFFFFFF;
		t.height = 50;
		t.width = 212;
		t.x = 269;
		t.y = 312;
		return t;
	};
	_proto.btn5_i = function () {
		var t = new eui.Rect();
		this.btn5 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillAlpha = 0.01;
		t.fillColor = 0xFFFFFF;
		t.height = 50;
		t.width = 212;
		t.x = 269;
		t.y = 380;
		return t;
	};
	_proto.btn6_i = function () {
		var t = new eui.Rect();
		this.btn6 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillAlpha = 0.01;
		t.fillColor = 0xFFFFFF;
		t.height = 50;
		t.horizontalCenter = 0;
		t.width = 249;
		t.y = 447.98;
		return t;
	};
	_proto.btn7_i = function () {
		var t = new eui.Rect();
		this.btn7 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillAlpha = 0.01;
		t.fillColor = 0xFFFFFF;
		t.height = 50;
		t.horizontalCenter = 0;
		t.width = 318.33;
		t.y = 515.98;
		return t;
	};
	_proto.btn8_i = function () {
		var t = new eui.Rect();
		this.btn8 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillAlpha = 0.01;
		t.fillColor = 0xFFFFFF;
		t.height = 50;
		t.horizontalCenter = 0.5;
		t.width = 249;
		t.y = 577.98;
		return t;
	};
	_proto.btn9_i = function () {
		var t = new eui.Rect();
		this.btn9 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillAlpha = 0.01;
		t.fillColor = 0xFFFFFF;
		t.height = 50;
		t.horizontalCenter = 0.5;
		t.width = 249;
		t.y = 644.98;
		return t;
	};
	_proto.btn10_i = function () {
		var t = new eui.Rect();
		this.btn10 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillAlpha = 0.01;
		t.fillColor = 0xFFFFFF;
		t.height = 50;
		t.horizontalCenter = 0;
		t.width = 249;
		t.y = 710.98;
		return t;
	};
	_proto.t11_i = function () {
		var t = new eui.Label();
		this.t11 = t;
		t.bold = true;
		t.fontFamily = "norfolkBold";
		t.horizontalCenter = 0;
		t.size = 24;
		t.text = "NODE AUDIT";
		t.textAlign = "center";
		t.textColor = 0x365590;
		t.y = 790;
		return t;
	};
	_proto.btn11_i = function () {
		var t = new eui.Rect();
		this.btn11 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillAlpha = 0.01;
		t.fillColor = 0xFFFFFF;
		t.height = 50;
		t.horizontalCenter = 0.5;
		t.width = 249;
		t.y = 776.98;
		return t;
	};
	_proto.languageSelectHeard_i = function () {
		var t = new eui.Group();
		this.languageSelectHeard = t;
		t.height = 60;
		t.horizontalCenter = 0;
		t.width = 220;
		t.y = 856.55;
		t.elementsContent = [this.languageIcon_i(),this.languageLabel_i(),this._Image7_i()];
		return t;
	};
	_proto.languageIcon_i = function () {
		var t = new eui.Image();
		this.languageIcon = t;
		t.height = 38;
		t.source = "language_1_png";
		t.verticalCenter = 0;
		t.width = 38;
		t.x = 15;
		return t;
	};
	_proto.languageLabel_i = function () {
		var t = new eui.Label();
		this.languageLabel = t;
		t.bold = true;
		t.horizontalCenter = 8;
		t.size = 24;
		t.text = "English";
		t.textColor = 0x365590;
		t.verticalCenter = 0;
		return t;
	};
	_proto._Image7_i = function () {
		var t = new eui.Image();
		t.source = "language_arrow2_png";
		t.x = 186.99;
		t.y = 25.36;
		return t;
	};
	_proto.languageList_i = function () {
		var t = new eui.List();
		this.languageList = t;
		t.height = 240;
		t.right = 265;
		t.selectedIndex = 0;
		t.visible = false;
		t.width = 220;
		t.y = 853.54;
		t.itemRendererSkinName = NavsUI$Skin29;
		t.dataProvider = this._ArrayCollection1_i();
		return t;
	};
	_proto._ArrayCollection1_i = function () {
		var t = new eui.ArrayCollection();
		t.source = [this._Object1_i(),this._Object2_i(),this._Object3_i(),this._Object4_i()];
		return t;
	};
	_proto._Object1_i = function () {
		var t = {};
		t.icon = "language_1_png";
		t.label = "English";
		return t;
	};
	_proto._Object2_i = function () {
		var t = {};
		t.icon = "language_2_png";
		t.label = "中文繁";
		return t;
	};
	_proto._Object3_i = function () {
		var t = {};
		t.icon = "language_3_png";
		t.label = "한글";
		return t;
	};
	_proto._Object4_i = function () {
		var t = {};
		t.icon = "language_4_png";
		t.label = "日本語";
		return t;
	};
	return NavsUI;
})(eui.Skin);generateEUI.paths['resource/eui/PeopleItem.exml'] = window.PeopleItem = (function (_super) {
	__extends(PeopleItem, _super);
	function PeopleItem() {
		_super.call(this);
		this.skinParts = ["chart"];
		
		this.height = 80;
		this.width = 684;
		this.elementsContent = [this._Image1_i(),this._Label1_i(),this.chart_i(),this._Image2_i()];
	}
	var _proto = PeopleItem.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.source = "team_heard_png";
		t.verticalCenter = 0;
		t.x = 27;
		return t;
	};
	_proto._Label1_i = function () {
		var t = new eui.Label();
		t.anchorOffsetX = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.height = 40;
		t.horizontalCenter = 0;
		t.size = 32;
		t.text = "HOUMAN";
		t.textAlign = "center";
		t.verticalAlign = "middle";
		t.verticalCenter = 0;
		t.width = 441;
		return t;
	};
	_proto.chart_i = function () {
		var t = new eui.Component();
		this.chart = t;
		t.height = 83;
		t.right = 27;
		t.skinName = "ChatIcon";
		t.top = 5;
		t.width = 83;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.height = 80;
		t.source = "icon_heard_img4_png";
		t.verticalCenter = 0;
		t.width = 80;
		t.x = 27;
		return t;
	};
	return PeopleItem;
})(eui.Skin);generateEUI.paths['resource/eui/PromptItem.exml'] = window.PromptItem = (function (_super) {
	__extends(PromptItem, _super);
	function PromptItem() {
		_super.call(this);
		this.skinParts = ["bg","title","contents","cancel","sure","account_warn","close_btn"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this.bg_i(),this._Image1_i(),this.title_i(),this.contents_i(),this.cancel_i(),this.sure_i(),this.account_warn_i(),this.close_btn_i()];
	}
	var _proto = PromptItem.prototype;

	_proto.bg_i = function () {
		var t = new eui.Rect();
		this.bg = t;
		t.bottom = 0;
		t.fillAlpha = 0.1;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.anchorOffsetY = 0;
		t.height = 365;
		t.horizontalCenter = 0;
		t.scale9Grid = new egret.Rectangle(88,76,533,461);
		t.source = "mainv_img5_png";
		t.y = 446;
		return t;
	};
	_proto.title_i = function () {
		var t = new eui.Label();
		this.title = t;
		t.anchorOffsetX = 0;
		t.bold = true;
		t.size = 26;
		t.text = "title";
		t.textColor = 0xb5b5b5;
		t.visible = false;
		t.width = 461;
		t.x = 105.03;
		t.y = 462.79;
		return t;
	};
	_proto.contents_i = function () {
		var t = new eui.Label();
		this.contents = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.height = 124.82;
		t.horizontalCenter = 0.5;
		t.lineSpacing = 5;
		t.size = 30;
		t.text = "contents";
		t.textAlign = "center";
		t.textColor = 0xB5B5B5;
		t.verticalAlign = "top";
		t.width = 469;
		t.y = 580.28;
		return t;
	};
	_proto.cancel_i = function () {
		var t = new eui.Button();
		this.cancel = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 60;
		t.label = "cancel";
		t.skinName = "skins.MyButton3Skin";
		t.visible = false;
		t.width = 180;
		t.x = 141;
		t.y = 707;
		return t;
	};
	_proto.sure_i = function () {
		var t = new eui.Button();
		this.sure = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 50;
		t.horizontalCenter = 0;
		t.label = "sured";
		t.skinName = "skins.MyButton3Skin";
		t.visible = false;
		t.y = 717;
		return t;
	};
	_proto.account_warn_i = function () {
		var t = new eui.Image();
		this.account_warn = t;
		t.horizontalCenter = 0;
		t.source = "tool_icon_warn_png";
		t.y = 481.23;
		return t;
	};
	_proto.close_btn_i = function () {
		var t = new eui.Group();
		this.close_btn = t;
		t.x = 638;
		t.y = 447.73;
		t.elementsContent = [this._Rect1_i(),this._Image2_i()];
		return t;
	};
	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.ellipseHeight = 40;
		t.ellipseWidth = 40;
		t.fillAlpha = 0;
		t.fillColor = 0xFFFFFF;
		t.height = 80;
		t.width = 80;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.source = "icon_close_png";
		t.x = 25;
		t.y = 25;
		return t;
	};
	return PromptItem;
})(eui.Skin);generateEUI.paths['resource/eui/PromptItem2.exml'] = window.PromptItem2 = (function (_super) {
	__extends(PromptItem2, _super);
	function PromptItem2() {
		_super.call(this);
		this.skinParts = ["bg","account_warn","contents","close_btn","sure"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this.bg_i(),this._Image1_i(),this.account_warn_i(),this.contents_i(),this.close_btn_i(),this.sure_i()];
	}
	var _proto = PromptItem2.prototype;

	_proto.bg_i = function () {
		var t = new eui.Rect();
		this.bg = t;
		t.bottom = 0;
		t.fillAlpha = 0.1;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.height = 365;
		t.horizontalCenter = 0;
		t.scale9Grid = new egret.Rectangle(88,76,533,461);
		t.source = "mainv_img5_png";
		t.y = 446;
		return t;
	};
	_proto.account_warn_i = function () {
		var t = new eui.Image();
		this.account_warn = t;
		t.horizontalCenter = 0;
		t.scaleX = 0.5;
		t.scaleY = 0.5;
		t.source = "reg2_txt_title_png";
		t.y = 481.23;
		return t;
	};
	_proto.contents_i = function () {
		var t = new eui.Label();
		this.contents = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.height = 124.82;
		t.horizontalCenter = 0.5;
		t.lineSpacing = 5;
		t.size = 26;
		t.text = "contents";
		t.textAlign = "center";
		t.textColor = 0xB5B5B5;
		t.verticalAlign = "top";
		t.width = 469;
		t.y = 575.43;
		return t;
	};
	_proto.close_btn_i = function () {
		var t = new eui.Group();
		this.close_btn = t;
		t.x = 637;
		t.y = 447.73;
		t.elementsContent = [this._Rect1_i(),this._Image2_i()];
		return t;
	};
	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.ellipseHeight = 40;
		t.ellipseWidth = 40;
		t.fillAlpha = 0;
		t.fillColor = 0xFFFFFF;
		t.height = 80;
		t.width = 80;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.source = "icon_close_png";
		t.x = 25;
		t.y = 25;
		return t;
	};
	_proto.sure_i = function () {
		var t = new eui.Button();
		this.sure = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 50;
		t.horizontalCenter = 0;
		t.label = "sure";
		t.skinName = "skins.MyButton3Skin";
		t.visible = false;
		t.width = 180;
		t.y = 717;
		return t;
	};
	return PromptItem2;
})(eui.Skin);generateEUI.paths['resource/eui/PromptItem3.exml'] = window.PromptItem3 = (function (_super) {
	__extends(PromptItem3, _super);
	function PromptItem3() {
		_super.call(this);
		this.skinParts = ["bg","contents","account_warn","close_btn","sure"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this.bg_i(),this._Image1_i(),this.contents_i(),this.account_warn_i(),this.close_btn_i(),this.sure_i()];
	}
	var _proto = PromptItem3.prototype;

	_proto.bg_i = function () {
		var t = new eui.Rect();
		this.bg = t;
		t.bottom = 0;
		t.fillAlpha = 0.7;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "promp_bbg_png";
		t.y = 446;
		return t;
	};
	_proto.contents_i = function () {
		var t = new eui.Label();
		this.contents = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.height = 134.82;
		t.horizontalCenter = 0.5;
		t.lineSpacing = 6;
		t.size = 30;
		t.text = "contents";
		t.textAlign = "center";
		t.textColor = 0xB5B5B5;
		t.verticalAlign = "top";
		t.width = 469;
		t.y = 550.28;
		return t;
	};
	_proto.account_warn_i = function () {
		var t = new eui.Image();
		this.account_warn = t;
		t.horizontalCenter = 0;
		t.source = "promp_bwarn_png";
		t.y = 481.23;
		return t;
	};
	_proto.close_btn_i = function () {
		var t = new eui.Group();
		this.close_btn = t;
		t.x = 653;
		t.y = 339.73;
		t.elementsContent = [this._Rect1_i(),this._Image2_i()];
		return t;
	};
	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.ellipseHeight = 40;
		t.ellipseWidth = 40;
		t.fillAlpha = 0;
		t.fillColor = 0xFFFFFF;
		t.height = 80;
		t.width = 80;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "icon_vote_close_png";
		t.verticalCenter = 0;
		return t;
	};
	_proto.sure_i = function () {
		var t = new eui.Button();
		this.sure = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 50;
		t.horizontalCenter = 0;
		t.label = "sure";
		t.skinName = "skins.MyButton3Skin";
		t.visible = false;
		t.width = 180;
		t.y = 697;
		return t;
	};
	return PromptItem3;
})(eui.Skin);generateEUI.paths['resource/eui/RegisterView.exml'] = window.RegisterView = (function (_super) {
	__extends(RegisterView, _super);
	var RegisterView$Skin30 = 	(function (_super) {
		__extends(RegisterView$Skin30, _super);
		function RegisterView$Skin30() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","reg_send_btn_on_png")
					])
				,
				new eui.State ("disabled",
					[
						new eui.SetProperty("_Image1","source","reg_send_btn_on_png")
					])
			];
		}
		var _proto = RegisterView$Skin30.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.percentHeight = 100;
			t.source = "reg_send_btn_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return RegisterView$Skin30;
	})(eui.Skin);

	var RegisterView$Skin31 = 	(function (_super) {
		__extends(RegisterView$Skin31, _super);
		function RegisterView$Skin31() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","reg_start_btn_on_png")
					])
				,
				new eui.State ("disabled",
					[
						new eui.SetProperty("_Image1","source","reg_start_btn_on_png")
					])
			];
		}
		var _proto = RegisterView$Skin31.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.percentHeight = 100;
			t.source = "reg_start_btn_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return RegisterView$Skin31;
	})(eui.Skin);

	var RegisterView$Skin32 = 	(function (_super) {
		__extends(RegisterView$Skin32, _super);
		function RegisterView$Skin32() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","reg_radio_on_png")
					])
				,
				new eui.State ("disabled",
					[
						new eui.SetProperty("_Image1","source","reg_radio_png")
					])
			];
		}
		var _proto = RegisterView$Skin32.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.percentHeight = 100;
			t.source = "reg_radio_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return RegisterView$Skin32;
	})(eui.Skin);

	function RegisterView() {
		_super.call(this);
		this.skinParts = ["back","input_email","warn0","input_code","warn1","send_btn","sent_time_pane_txt","sent_time_pane","input_password","warn2","input_invite_code","warn3","input_name","warn4","group3","next_btn","tool_loading","loadPane","rad_btn","group2","group1"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this._Rect1_i(),this._Scroller1_i()];
	}
	var _proto = RegisterView.prototype;

	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.bottom = 0;
		t.fillColor = 0xffffff;
		t.height = 1334;
		t.left = -2;
		t.right = 2;
		t.top = 0;
		t.width = 750;
		return t;
	};
	_proto._Scroller1_i = function () {
		var t = new eui.Scroller();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.viewport = this.group1_i();
		return t;
	};
	_proto.group1_i = function () {
		var t = new eui.Group();
		this.group1 = t;
		t.elementsContent = [this.group2_i()];
		return t;
	};
	_proto.group2_i = function () {
		var t = new eui.Group();
		this.group2 = t;
		t.left = 0;
		t.right = 0;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this._Rect2_i(),this.back_i(),this._Image1_i(),this.group3_i(),this.next_btn_i(),this.loadPane_i(),this._Group6_i()];
		return t;
	};
	_proto._Rect2_i = function () {
		var t = new eui.Rect();
		t.fillColor = 0xFFFFFF;
		t.height = 1334;
		t.width = 750;
		t.x = -1;
		t.y = 0;
		return t;
	};
	_proto.back_i = function () {
		var t = new eui.Component();
		this.back = t;
		t.height = 80;
		t.skinName = "BackBtn";
		t.width = 80;
		t.x = 20;
		t.y = 46;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "reg_txt_title_png";
		t.y = 128;
		return t;
	};
	_proto.group3_i = function () {
		var t = new eui.Group();
		this.group3 = t;
		t.bottom = 311;
		t.left = 0;
		t.right = 0;
		t.top = 292;
		t.x = 0;
		t.elementsContent = [this._Group1_i(),this._Group2_i(),this._Group3_i(),this._Group4_i(),this._Group5_i()];
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.height = 100;
		t.horizontalCenter = 0;
		t.verticalCenter = -249.5;
		t.width = 360;
		t.elementsContent = [this.input_email_i(),this.warn0_i(),this._Label1_i(),this._Image2_i(),this._Image3_i()];
		return t;
	};
	_proto.input_email_i = function () {
		var t = new eui.TextInput();
		this.input_email = t;
		t.height = 100;
		t.horizontalCenter = 0;
		t.width = 360;
		t.y = 0.68;
		return t;
	};
	_proto.warn0_i = function () {
		var t = new eui.Image();
		this.warn0 = t;
		t.bottom = 0;
		t.height = 40;
		t.left = -62;
		t.source = "tool_icon_warn_png";
		t.visible = false;
		t.width = 40;
		return t;
	};
	_proto._Label1_i = function () {
		var t = new eui.Label();
		t.bold = true;
		t.fontFamily = "norfolk";
		t.horizontalCenter = 0.5;
		t.size = 28;
		t.text = "EMAIL";
		t.textColor = 0x000000;
		t.top = 0;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "reg_txt1_png";
		t.visible = false;
		t.y = 0;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.bottom = -2;
		t.horizontalCenter = 0;
		t.source = "reg_line_png";
		t.width = 360;
		return t;
	};
	_proto._Group2_i = function () {
		var t = new eui.Group();
		t.height = 100;
		t.horizontalCenter = 0;
		t.verticalCenter = -111.5;
		t.width = 360;
		t.zIndex = 5;
		t.elementsContent = [this.input_code_i(),this.warn1_i(),this._Label2_i(),this._Image4_i(),this._Image5_i(),this.send_btn_i(),this.sent_time_pane_i()];
		return t;
	};
	_proto.input_code_i = function () {
		var t = new eui.TextInput();
		this.input_code = t;
		t.anchorOffsetX = 0;
		t.height = 100;
		t.horizontalCenter = 0;
		t.maxChars = 8;
		t.width = 313;
		t.y = 0.68;
		return t;
	};
	_proto.warn1_i = function () {
		var t = new eui.Image();
		this.warn1 = t;
		t.bottom = 0;
		t.height = 40;
		t.left = -62;
		t.source = "tool_icon_warn_png";
		t.visible = false;
		t.width = 40;
		return t;
	};
	_proto._Label2_i = function () {
		var t = new eui.Label();
		t.bold = true;
		t.fontFamily = "norfolk";
		t.horizontalCenter = 0.5;
		t.size = 28;
		t.text = "VERIFICATION CODE";
		t.textColor = 0x000000;
		t.top = 0;
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "reg_txt4_png";
		t.visible = false;
		t.y = 0;
		return t;
	};
	_proto._Image5_i = function () {
		var t = new eui.Image();
		t.bottom = -2;
		t.horizontalCenter = 0;
		t.source = "reg_line_png";
		t.width = 360;
		return t;
	};
	_proto.send_btn_i = function () {
		var t = new eui.Button();
		this.send_btn = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bottom = -17;
		t.horizontalCenter = 234;
		t.label = "";
		t.skinName = RegisterView$Skin30;
		return t;
	};
	_proto.sent_time_pane_i = function () {
		var t = new eui.Group();
		this.sent_time_pane = t;
		t.bottom = -21;
		t.horizontalCenter = 234.5;
		t.visible = false;
		t.elementsContent = [this._Image6_i(),this.sent_time_pane_txt_i()];
		return t;
	};
	_proto._Image6_i = function () {
		var t = new eui.Image();
		t.source = "reg_time_btn_btn_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.sent_time_pane_txt_i = function () {
		var t = new eui.Label();
		this.sent_time_pane_txt = t;
		t.fontFamily = "norfolkBold";
		t.horizontalCenter = 0;
		t.text = "60S";
		t.top = 12;
		return t;
	};
	_proto._Group3_i = function () {
		var t = new eui.Group();
		t.height = 100;
		t.horizontalCenter = 0;
		t.verticalCenter = 25.5;
		t.width = 360;
		t.elementsContent = [this.input_password_i(),this.warn2_i(),this._Image7_i(),this._Label3_i(),this._Image8_i()];
		return t;
	};
	_proto.input_password_i = function () {
		var t = new eui.TextInput();
		this.input_password = t;
		t.displayAsPassword = true;
		t.height = 100;
		t.horizontalCenter = 0;
		t.width = 360;
		t.y = 0.68;
		return t;
	};
	_proto.warn2_i = function () {
		var t = new eui.Image();
		this.warn2 = t;
		t.bottom = 0;
		t.height = 40;
		t.left = -62;
		t.source = "tool_icon_warn_png";
		t.visible = false;
		t.width = 40;
		return t;
	};
	_proto._Image7_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "reg_txt3_png";
		t.visible = false;
		t.y = 0;
		return t;
	};
	_proto._Label3_i = function () {
		var t = new eui.Label();
		t.bold = true;
		t.fontFamily = "norfolk";
		t.horizontalCenter = 0.5;
		t.size = 28;
		t.text = "PASSWORD";
		t.textColor = 0x000000;
		t.top = 0;
		return t;
	};
	_proto._Image8_i = function () {
		var t = new eui.Image();
		t.bottom = -2;
		t.horizontalCenter = 0;
		t.source = "reg_line_png";
		t.width = 360;
		return t;
	};
	_proto._Group4_i = function () {
		var t = new eui.Group();
		t.height = 100;
		t.horizontalCenter = 0;
		t.verticalCenter = 163.5;
		t.width = 360;
		t.elementsContent = [this.input_invite_code_i(),this.warn3_i(),this._Image9_i(),this._Label4_i(),this._Image10_i()];
		return t;
	};
	_proto.input_invite_code_i = function () {
		var t = new eui.TextInput();
		this.input_invite_code = t;
		t.height = 100;
		t.horizontalCenter = 0;
		t.width = 360;
		t.y = 0.68;
		return t;
	};
	_proto.warn3_i = function () {
		var t = new eui.Image();
		this.warn3 = t;
		t.bottom = 0;
		t.height = 40;
		t.left = -62;
		t.source = "tool_icon_warn_png";
		t.visible = false;
		t.width = 40;
		return t;
	};
	_proto._Image9_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "reg_txt2_png";
		t.visible = false;
		t.y = 0;
		return t;
	};
	_proto._Label4_i = function () {
		var t = new eui.Label();
		t.bold = true;
		t.fontFamily = "norfolk";
		t.horizontalCenter = 0.5;
		t.size = 28;
		t.text = "REFERRAL CODE";
		t.textColor = 0x000000;
		t.top = 0;
		return t;
	};
	_proto._Image10_i = function () {
		var t = new eui.Image();
		t.bottom = -2;
		t.horizontalCenter = 0;
		t.source = "reg_line_png";
		t.width = 360;
		return t;
	};
	_proto._Group5_i = function () {
		var t = new eui.Group();
		t.height = 100;
		t.horizontalCenter = 0;
		t.verticalCenter = 300.5;
		t.width = 360;
		t.elementsContent = [this.input_name_i(),this.warn4_i(),this._Label5_i(),this._Image11_i(),this._Image12_i()];
		return t;
	};
	_proto.input_name_i = function () {
		var t = new eui.TextInput();
		this.input_name = t;
		t.height = 100;
		t.horizontalCenter = 0;
		t.restrict = "a-z 0-9";
		t.width = 360;
		t.y = 0.68;
		return t;
	};
	_proto.warn4_i = function () {
		var t = new eui.Image();
		this.warn4 = t;
		t.bottom = 0;
		t.height = 40;
		t.left = -62;
		t.source = "tool_icon_warn_png";
		t.visible = false;
		t.width = 40;
		return t;
	};
	_proto._Label5_i = function () {
		var t = new eui.Label();
		t.bold = true;
		t.fontFamily = "norfolk";
		t.horizontalCenter = 0.5;
		t.size = 28;
		t.text = "SET NICK NAME";
		t.textColor = 0x000000;
		t.top = 0;
		return t;
	};
	_proto._Image11_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "reg2_txt1_png";
		t.visible = false;
		t.y = 0;
		return t;
	};
	_proto._Image12_i = function () {
		var t = new eui.Image();
		t.bottom = -2;
		t.horizontalCenter = 0;
		t.source = "reg_line_png";
		t.width = 360;
		return t;
	};
	_proto.next_btn_i = function () {
		var t = new eui.Button();
		this.next_btn = t;
		t.bottom = 122;
		t.horizontalCenter = 0;
		t.label = "";
		t.skinName = RegisterView$Skin31;
		return t;
	};
	_proto.loadPane_i = function () {
		var t = new eui.Group();
		this.loadPane = t;
		t.bottom = 122;
		t.horizontalCenter = 0;
		t.visible = false;
		t.elementsContent = [this._Image13_i(),this.tool_loading_i()];
		return t;
	};
	_proto._Image13_i = function () {
		var t = new eui.Image();
		t.source = "reg_load_btn_bg_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.tool_loading_i = function () {
		var t = new eui.Image();
		this.tool_loading = t;
		t.anchorOffsetX = 25;
		t.anchorOffsetY = 26;
		t.source = "tool_loading_png";
		t.x = 137;
		t.y = 50;
		return t;
	};
	_proto._Group6_i = function () {
		var t = new eui.Group();
		t.bottom = 73;
		t.horizontalCenter = 0.5;
		t.elementsContent = [this.rad_btn_i(),this._Label6_i()];
		return t;
	};
	_proto.rad_btn_i = function () {
		var t = new eui.RadioButton();
		this.rad_btn = t;
		t.height = 36;
		t.label = "";
		t.width = 36;
		t.x = 0;
		t.y = 0;
		t.skinName = RegisterView$Skin32;
		return t;
	};
	_proto._Label6_i = function () {
		var t = new eui.Label();
		t.bold = true;
		t.fontFamily = "norfolk";
		t.size = 20;
		t.text = "I agree to the user agreement & privacy terms";
		t.textColor = 0x000000;
		t.verticalCenter = -2;
		t.x = 40.38;
		return t;
	};
	return RegisterView;
})(eui.Skin);generateEUI.paths['resource/eui/saiboPage.exml'] = window.saiboPage = (function (_super) {
	__extends(saiboPage, _super);
	function saiboPage() {
		_super.call(this);
		this.skinParts = ["bg","back","arrow","down","open"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this.bg_i(),this._Image1_i(),this._Image2_i(),this.back_i(),this.arrow_i(),this.down_i(),this.open_i()];
	}
	var _proto = saiboPage.prototype;

	_proto.bg_i = function () {
		var t = new eui.Rect();
		this.bg = t;
		t.bottom = 0;
		t.fillColor = 0x243c6d;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.anchorOffsetY = 0;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.source = "saibo_bg_png";
		t.top = 0;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "saibo_img1_png";
		t.verticalCenter = 22;
		return t;
	};
	_proto.back_i = function () {
		var t = new eui.Group();
		this.back = t;
		t.x = 21.69;
		t.y = 25;
		t.elementsContent = [this._Image3_i(),this._Rect1_i()];
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "back_green_png";
		t.verticalCenter = 0;
		return t;
	};
	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillAlpha = 0;
		t.height = 80;
		t.width = 80;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.arrow_i = function () {
		var t = new eui.Image();
		this.arrow = t;
		t.horizontalCenter = 0;
		t.source = "tool_icon_glarrow_png";
		t.verticalCenter = 528;
		return t;
	};
	_proto.down_i = function () {
		var t = new eui.Image();
		this.down = t;
		t.horizontalCenter = 0.5;
		t.source = "tool_icon_gldownload_png";
		t.verticalCenter = 486.5;
		return t;
	};
	_proto.open_i = function () {
		var t = new eui.Image();
		this.open = t;
		t.horizontalCenter = 0;
		t.source = "tool_icon_glopen_png";
		t.verticalCenter = 485.5;
		return t;
	};
	return saiboPage;
})(eui.Skin);generateEUI.paths['resource/eui/ShareView.exml'] = window.ShareView = (function (_super) {
	__extends(ShareView, _super);
	function ShareView() {
		_super.call(this);
		this.skinParts = ["t1","t2","t3","code"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this._Rect1_i(),this._Image1_i(),this._Image2_i(),this.t1_i(),this.t2_i(),this._Group1_i()];
	}
	var _proto = ShareView.prototype;

	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.bottom = 0;
		t.fillColor = 0x000000;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.anchorOffsetY = 0;
		t.left = 0;
		t.source = "share_bg1_png";
		t.verticalCenter = -268;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.anchorOffsetY = 0;
		t.bottom = 0;
		t.source = "share_bgbg2_png";
		t.x = 0;
		return t;
	};
	_proto.t1_i = function () {
		var t = new eui.Image();
		this.t1 = t;
		t.horizontalCenter = 0;
		t.source = "share_img1_ch_png";
		t.verticalCenter = -334;
		return t;
	};
	_proto.t2_i = function () {
		var t = new eui.Image();
		this.t2 = t;
		t.bottom = 39;
		t.horizontalCenter = 0;
		t.source = "share_img2_ch_png";
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.bottom = 50;
		t.horizontalCenter = 0;
		t.elementsContent = [this.t3_i(),this.code_i()];
		return t;
	};
	_proto.t3_i = function () {
		var t = new eui.Image();
		this.t3 = t;
		t.source = "share_img3_en_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.code_i = function () {
		var t = new eui.Label();
		this.code = t;
		t.bold = true;
		t.size = 32;
		t.text = "ZCSL5O";
		t.textAlign = "left";
		t.x = 176;
		t.y = 11.5;
		return t;
	};
	return ShareView;
})(eui.Skin);generateEUI.paths['resource/eui/TeamPage.exml'] = window.TeamPage = (function (_super) {
	__extends(TeamPage, _super);
	function TeamPage() {
		_super.call(this);
		this.skinParts = ["people1_msg","people2_msg","people3_msg","back","title"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this._Rect1_i(),this._Image1_i(),this._Scroller1_i(),this.back_i(),this.title_i()];
	}
	var _proto = TeamPage.prototype;

	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.bottom = 0;
		t.fillColor = 0xffffff;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0.5;
		t.source = "teamp_title_png";
		t.visible = false;
		t.y = 65.2;
		return t;
	};
	_proto._Scroller1_i = function () {
		var t = new eui.Scroller();
		t.anchorOffsetY = 0;
		t.bottom = 12;
		t.left = 0;
		t.right = 0;
		t.top = 134;
		t.viewport = this._Group1_i();
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 325.76;
		t.width = 750;
		t.elementsContent = [this._Image2_i(),this._Image3_i(),this._Image4_i(),this._Rect2_i(),this._Rect3_i(),this._Rect4_i(),this.people1_msg_i(),this.people2_msg_i(),this.people3_msg_i()];
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.source = "tearmp_img1_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.source = "tearmp_img2_png";
		t.x = 0;
		t.y = 1166;
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.source = "tearmp_img3_png";
		t.x = 0;
		t.y = 2407;
		return t;
	};
	_proto._Rect2_i = function () {
		var t = new eui.Rect();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillColor = 0xe26556;
		t.height = 583.15;
		t.horizontalCenter = 0;
		t.width = 563.4;
		t.y = 507;
		return t;
	};
	_proto._Rect3_i = function () {
		var t = new eui.Rect();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillColor = 0x5b65b4;
		t.height = 583.15;
		t.horizontalCenter = -0.5;
		t.width = 563.4;
		t.y = 1613.67;
		return t;
	};
	_proto._Rect4_i = function () {
		var t = new eui.Rect();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillColor = 0x63c0c2;
		t.height = 583.15;
		t.horizontalCenter = -0.5;
		t.width = 563.4;
		t.y = 2867.03;
		return t;
	};
	_proto.people1_msg_i = function () {
		var t = new eui.Label();
		this.people1_msg = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.height = 582;
		t.horizontalCenter = 0.5;
		t.lineSpacing = 6;
		t.size = 24;
		t.text = "";
		t.textAlign = "left";
		t.width = 557;
		t.y = 507.68;
		return t;
	};
	_proto.people2_msg_i = function () {
		var t = new eui.Label();
		this.people2_msg = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.height = 582;
		t.horizontalCenter = 0.5;
		t.lineSpacing = 6;
		t.size = 24;
		t.text = "";
		t.textAlign = "left";
		t.width = 557;
		t.y = 1680.39;
		return t;
	};
	_proto.people3_msg_i = function () {
		var t = new eui.Label();
		this.people3_msg = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.height = 582;
		t.horizontalCenter = 0.5;
		t.lineSpacing = 6;
		t.size = 24;
		t.text = "";
		t.textAlign = "left";
		t.width = 557;
		t.y = 2880.37;
		return t;
	};
	_proto.back_i = function () {
		var t = new eui.Group();
		this.back = t;
		t.height = 80;
		t.x = 18.03;
		t.y = 27;
		t.elementsContent = [this._Rect5_i(),this._Image5_i()];
		return t;
	};
	_proto._Rect5_i = function () {
		var t = new eui.Rect();
		t.fillColor = 0xffffff;
		t.height = 80;
		t.width = 80;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Image5_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "icon_back22_png";
		t.verticalCenter = 0;
		return t;
	};
	_proto.title_i = function () {
		var t = new eui.Label();
		this.title = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolkBold";
		t.horizontalCenter = -0.5;
		t.lineSpacing = 6;
		t.size = 48;
		t.text = "Contact us";
		t.textAlign = "center";
		t.textColor = 0x5969AF;
		t.verticalAlign = "top";
		t.width = 591.34;
		t.y = 43;
		return t;
	};
	return TeamPage;
})(eui.Skin);generateEUI.paths['resource/eui/TeamView.exml'] = window.TeamView = (function (_super) {
	__extends(TeamView, _super);
	var TeamView$Skin33 = 	(function (_super) {
		__extends(TeamView$Skin33, _super);
		function TeamView$Skin33() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","team_btn_1_off_png"),
						new eui.SetProperty("labelDisplay","textColor",0xf8b43d)
					])
				,
				new eui.State ("disabled",
					[
						new eui.SetProperty("_Image1","source","team_btn_1_off_png")
					])
			];
		}
		var _proto = TeamView$Skin33.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.percentHeight = 100;
			t.source = "team_btn_1_on_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.bold = true;
			t.fontFamily = "norfolk";
			t.horizontalCenter = 0;
			t.size = 32;
			t.textColor = 0xFFFFFF;
			t.verticalCenter = -10;
			return t;
		};
		return TeamView$Skin33;
	})(eui.Skin);

	function TeamView() {
		_super.call(this);
		this.skinParts = ["planet","indexImg","friends_label","nickname","yourfriends_label","label_speed","speed","speed2","time","time_icon","time_icon_pane","speed_pane","nextPeoples","nav1_label","friendsUi","earn","nav2_label","earmUi","invite_btn","friend1","tool"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this._Rect1_i(),this.planet_i(),this._Rect2_i(),this._Rect3_i(),this._Rect4_i(),this._Rect5_i(),this.indexImg_i(),this.friends_label_i(),this.nickname_i(),this._Group1_i(),this.speed_pane_i(),this.friendsUi_i(),this.earmUi_i(),this.invite_btn_i(),this.friend1_i(),this.tool_i()];
	}
	var _proto = TeamView.prototype;

	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.bottom = 0;
		t.fillColor = 0x031f2a;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto.planet_i = function () {
		var t = new eui.Image();
		this.planet = t;
		t.anchorOffsetX = 320;
		t.anchorOffsetY = 240;
		t.horizontalCenter = 0;
		t.source = "planet0001_jpg";
		t.top = 0;
		return t;
	};
	_proto._Rect2_i = function () {
		var t = new eui.Rect();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillColor = 0x031f2a;
		t.height = 10;
		t.left = 0;
		t.right = 0;
		t.y = 475.99;
		return t;
	};
	_proto._Rect3_i = function () {
		var t = new eui.Rect();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillColor = 0x031F2A;
		t.height = 10;
		t.left = 0;
		t.right = 0;
		t.y = -5;
		return t;
	};
	_proto._Rect4_i = function () {
		var t = new eui.Rect();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillColor = 0x031F2A;
		t.height = 480;
		t.width = 10;
		t.x = 49.33;
		t.y = 0;
		return t;
	};
	_proto._Rect5_i = function () {
		var t = new eui.Rect();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillColor = 0x031F2A;
		t.height = 480;
		t.width = 10;
		t.x = 689.97;
		t.y = 0;
		return t;
	};
	_proto.indexImg_i = function () {
		var t = new eui.Image();
		this.indexImg = t;
		t.source = "team_txt1_png";
		t.x = 33;
		t.y = 472;
		return t;
	};
	_proto.friends_label_i = function () {
		var t = new eui.Label();
		this.friends_label = t;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.height = 26;
		t.size = 24;
		t.text = "FRIENDS";
		t.textColor = 0xFFFFFF;
		t.x = 31;
		t.y = 734.66;
		return t;
	};
	_proto.nickname_i = function () {
		var t = new eui.Label();
		this.nickname = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.height = 48.18;
		t.size = 50;
		t.text = "JOELJES";
		t.textAlign = "left";
		t.verticalAlign = "top";
		t.width = 664.66;
		t.x = 32.71;
		t.y = 652.36;
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.x = 33;
		t.y = 1074;
		t.elementsContent = [this._Image1_i(),this.yourfriends_label_i()];
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.source = "team_rect_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.yourfriends_label_i = function () {
		var t = new eui.Label();
		this.yourfriends_label = t;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.horizontalCenter = 0.5;
		t.size = 24;
		t.text = "YOUR FRIENDS";
		t.textColor = 0xffffff;
		t.y = 18.01;
		return t;
	};
	_proto.speed_pane_i = function () {
		var t = new eui.Group();
		this.speed_pane = t;
		t.x = 36.4;
		t.y = 565;
		t.elementsContent = [this._Image2_i(),this.label_speed_i(),this.speed_i(),this.speed2_i(),this.time_icon_pane_i()];
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.source = "team_icon1_png";
		t.x = 0;
		t.y = 5;
		return t;
	};
	_proto.label_speed_i = function () {
		var t = new eui.Label();
		this.label_speed = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.height = 48.18;
		t.size = 32;
		t.text = "SPEED:";
		t.verticalAlign = "middle";
		t.verticalCenter = 0;
		t.x = 54.62;
		return t;
	};
	_proto.speed_i = function () {
		var t = new eui.Label();
		this.speed = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.height = 48.18;
		t.text = "0  GL";
		t.verticalAlign = "middle";
		t.verticalCenter = 0;
		t.x = 178.13;
		return t;
	};
	_proto.speed2_i = function () {
		var t = new eui.Label();
		this.speed2 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.height = 48;
		t.multiline = false;
		t.size = 20;
		t.text = "+10%";
		t.textAlign = "left";
		t.textColor = 0xFDC54A;
		t.verticalAlign = "bottom";
		t.x = 281;
		t.y = -9.91;
		return t;
	};
	_proto.time_icon_pane_i = function () {
		var t = new eui.Group();
		this.time_icon_pane = t;
		t.right = -286;
		t.y = 0;
		t.elementsContent = [this.time_i(),this.time_icon_i()];
		return t;
	};
	_proto.time_i = function () {
		var t = new eui.Label();
		this.time = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.height = 48.18;
		t.size = 32;
		t.text = "12:00:00";
		t.textAlign = "left";
		t.textColor = 0xd81e06;
		t.verticalAlign = "middle";
		t.width = 211.51;
		t.x = 51.58;
		t.y = 0;
		return t;
	};
	_proto.time_icon_i = function () {
		var t = new eui.Image();
		this.time_icon = t;
		t.source = "team_icon2_png";
		t.x = 0;
		t.y = 5;
		return t;
	};
	_proto.friendsUi_i = function () {
		var t = new eui.Group();
		this.friendsUi = t;
		t.x = 33;
		t.y = 793;
		t.elementsContent = [this._Image3_i(),this.nextPeoples_i(),this.nav1_label_i()];
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.source = "team_rect2_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.nextPeoples_i = function () {
		var t = new eui.Label();
		this.nextPeoples = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.height = 48.18;
		t.horizontalCenter = 0;
		t.size = 52;
		t.text = "0";
		t.textAlign = "center";
		t.verticalAlign = "middle";
		t.width = 257.33;
		t.y = 82;
		return t;
	};
	_proto.nav1_label_i = function () {
		var t = new eui.Label();
		this.nav1_label = t;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.horizontalCenter = 0;
		t.size = 26;
		t.text = "YOUR TEAM MEMBER";
		t.textAlign = "center";
		t.textColor = 0xFFFFFF;
		t.y = 42.01;
		return t;
	};
	_proto.earmUi_i = function () {
		var t = new eui.Group();
		this.earmUi = t;
		t.right = 33;
		t.y = 793;
		t.elementsContent = [this._Image4_i(),this.earn_i(),this.nav2_label_i()];
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.source = "team_rect1_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.earn_i = function () {
		var t = new eui.Label();
		this.earn = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.height = 48.18;
		t.horizontalCenter = 0;
		t.size = 36;
		t.text = "0GL";
		t.textAlign = "center";
		t.verticalAlign = "middle";
		t.width = 257.33;
		t.y = 82;
		return t;
	};
	_proto.nav2_label_i = function () {
		var t = new eui.Label();
		this.nav2_label = t;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.horizontalCenter = 0;
		t.size = 26;
		t.text = "YOUR EARN";
		t.textAlign = "center";
		t.textColor = 0xFFFFFF;
		t.y = 42.01;
		return t;
	};
	_proto.invite_btn_i = function () {
		var t = new eui.Button();
		this.invite_btn = t;
		t.horizontalCenter = 0;
		t.label = "INVITE NOW!";
		t.y = 971;
		t.skinName = TeamView$Skin33;
		return t;
	};
	_proto.friend1_i = function () {
		var t = new eui.Component();
		this.friend1 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 80;
		t.horizontalCenter = 0;
		t.skinName = "PeopleItem";
		t.width = 684;
		t.y = 1166;
		return t;
	};
	_proto.tool_i = function () {
		var t = new eui.Component();
		this.tool = t;
		t.skinName = "BackBtn";
		t.x = 4.97;
		t.y = 26.75;
		return t;
	};
	return TeamView;
})(eui.Skin);generateEUI.paths['resource/eui/Toolclose2UI.exml'] = window.Toolclose2UI = (function (_super) {
	__extends(Toolclose2UI, _super);
	function Toolclose2UI() {
		_super.call(this);
		this.skinParts = [];
		
		this.height = 80;
		this.width = 80;
		this.elementsContent = [this._Image1_i()];
	}
	var _proto = Toolclose2UI.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "icon_close2_png";
		t.verticalCenter = 0;
		return t;
	};
	return Toolclose2UI;
})(eui.Skin);generateEUI.paths['resource/eui/ToolView.exml'] = window.ToolView = (function (_super) {
	__extends(ToolView, _super);
	function ToolView() {
		_super.call(this);
		this.skinParts = ["close","more"];
		
		this.height = 44;
		this.width = 120;
		this.elementsContent = [this._Image1_i(),this.close_i(),this.more_i(),this._Image2_i()];
	}
	var _proto = ToolView.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.left = 0;
		t.source = "tool_bg_png";
		t.top = 0;
		return t;
	};
	_proto.close_i = function () {
		var t = new eui.Image();
		this.close = t;
		t.source = "tool_circle_png";
		t.verticalCenter = 0;
		t.x = 75.5;
		return t;
	};
	_proto.more_i = function () {
		var t = new eui.Image();
		this.more = t;
		t.source = "tool_circle3_png";
		t.verticalCenter = 0;
		t.x = 15;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "tool_line_png";
		t.verticalCenter = 0;
		return t;
	};
	return ToolView;
})(eui.Skin);generateEUI.paths['resource/eui/UserInfoUI.exml'] = window.UserInfoUI = (function (_super) {
	__extends(UserInfoUI, _super);
	var UserInfoUI$Skin34 = 	(function (_super) {
		__extends(UserInfoUI$Skin34, _super);
		function UserInfoUI$Skin34() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","icon_btn_bg2_png"),
						new eui.SetProperty("_Image1","alpha",0.7)
					])
				,
				new eui.State ("disabled",
					[
						new eui.SetProperty("_Image1","source","icon_btn_bg2_png")
					])
			];
		}
		var _proto = UserInfoUI$Skin34.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.percentHeight = 100;
			t.source = "icon_btn_bg2_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.bold = true;
			t.fontFamily = "norfolk";
			t.horizontalCenter = 0;
			t.size = 26;
			t.textAlign = "center";
			t.verticalCenter = -6;
			return t;
		};
		return UserInfoUI$Skin34;
	})(eui.Skin);

	function UserInfoUI() {
		_super.call(this);
		this.skinParts = ["bg","close","txt1","nickname","txt2","time","txt3","who","txt4","invitation","exit","copy_btn"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this.bg_i(),this._Image1_i(),this.close_i(),this._Image3_i(),this._Image4_i(),this.txt1_i(),this.nickname_i(),this.txt2_i(),this.time_i(),this.txt3_i(),this.who_i(),this.txt4_i(),this.invitation_i(),this.exit_i(),this.copy_btn_i()];
	}
	var _proto = UserInfoUI.prototype;

	_proto.bg_i = function () {
		var t = new eui.Rect();
		this.bg = t;
		t.bottom = 0;
		t.fillAlpha = 0.1;
		t.fillColor = 0xffffff;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.anchorOffsetY = 0;
		t.height = 829;
		t.horizontalCenter = 0;
		t.source = "tool_alert_bg_png";
		t.y = 34.49;
		return t;
	};
	_proto.close_i = function () {
		var t = new eui.Group();
		this.close = t;
		t.x = 625;
		t.y = 52.93;
		t.elementsContent = [this._Rect1_i(),this._Image2_i()];
		return t;
	};
	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillColor = 0xffffff;
		t.height = 80;
		t.width = 80;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.source = "icon_close_png";
		t.x = 25;
		t.y = 25;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "icon_heard_img1_png";
		t.y = 117;
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "nav_line_png";
		t.y = 790;
		return t;
	};
	_proto.txt1_i = function () {
		var t = new eui.Label();
		this.txt1 = t;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.horizontalCenter = 0.5;
		t.size = 16;
		t.text = "NICK NAME";
		t.textColor = 0x4c6ca5;
		t.y = 270.29;
		return t;
	};
	_proto.nickname_i = function () {
		var t = new eui.Label();
		this.nickname = t;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.horizontalCenter = 0.5;
		t.size = 22;
		t.text = "dear";
		t.textColor = 0x4C6CA5;
		t.y = 290.29;
		return t;
	};
	_proto.txt2_i = function () {
		var t = new eui.Label();
		this.txt2 = t;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.horizontalCenter = 0;
		t.size = 16;
		t.text = "SINGUP TIME";
		t.textColor = 0x4C6CA5;
		t.y = 367.29;
		return t;
	};
	_proto.time_i = function () {
		var t = new eui.Label();
		this.time = t;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.horizontalCenter = 0;
		t.size = 24;
		t.text = "2019-10-29";
		t.textColor = 0x4C6CA5;
		t.y = 394.29;
		return t;
	};
	_proto.txt3_i = function () {
		var t = new eui.Label();
		this.txt3 = t;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.horizontalCenter = 0;
		t.size = 16;
		t.text = "WHO INVITED ME";
		t.textColor = 0x4C6CA5;
		t.y = 468.29;
		return t;
	};
	_proto.who_i = function () {
		var t = new eui.Label();
		this.who = t;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.horizontalCenter = 0;
		t.size = 24;
		t.text = "WHO";
		t.textColor = 0x4C6CA5;
		t.y = 496.29;
		return t;
	};
	_proto.txt4_i = function () {
		var t = new eui.Label();
		this.txt4 = t;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.horizontalCenter = 0.5;
		t.size = 16;
		t.text = "REFERRAL CODE";
		t.textColor = 0x4C6CA5;
		t.y = 565.63;
		return t;
	};
	_proto.invitation_i = function () {
		var t = new eui.Label();
		this.invitation = t;
		t.anchorOffsetX = 0;
		t.bold = true;
		t.horizontalCenter = 0;
		t.size = 26;
		t.text = "FIO3O5";
		t.textAlign = "center";
		t.textColor = 0x4C6CA5;
		t.width = 189.34;
		t.y = 595.63;
		return t;
	};
	_proto.exit_i = function () {
		var t = new eui.Button();
		this.exit = t;
		t.horizontalCenter = 0;
		t.label = "EXIT";
		t.y = 696;
		t.skinName = UserInfoUI$Skin34;
		return t;
	};
	_proto.copy_btn_i = function () {
		var t = new eui.Group();
		this.copy_btn = t;
		t.x = 434;
		t.y = 577.63;
		t.elementsContent = [this._Image5_i(),this._Rect2_i()];
		return t;
	};
	_proto._Image5_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "icon_copy_png";
		t.verticalCenter = 0;
		return t;
	};
	_proto._Rect2_i = function () {
		var t = new eui.Rect();
		t.fillAlpha = 0.05;
		t.fillColor = 0xffffff;
		t.height = 60;
		t.width = 60;
		t.x = 0;
		t.y = 0;
		return t;
	};
	return UserInfoUI;
})(eui.Skin);generateEUI.paths['resource/eui/UserInfoUIGIP.exml'] = window.UserInfoUIGIP = (function (_super) {
	__extends(UserInfoUIGIP, _super);
	var UserInfoUIGIP$Skin35 = 	(function (_super) {
		__extends(UserInfoUIGIP$Skin35, _super);
		function UserInfoUIGIP$Skin35() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","icon_btn_bg2_gip_png"),
						new eui.SetProperty("_Image1","alpha",0.7)
					])
				,
				new eui.State ("disabled",
					[
						new eui.SetProperty("_Image1","source","icon_btn_bg2_gip_png")
					])
			];
		}
		var _proto = UserInfoUIGIP$Skin35.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.percentHeight = 100;
			t.source = "icon_btn_bg2_gip_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.bold = true;
			t.fontFamily = "norfolk";
			t.horizontalCenter = 0;
			t.size = 26;
			t.textAlign = "center";
			t.verticalCenter = -6;
			return t;
		};
		return UserInfoUIGIP$Skin35;
	})(eui.Skin);

	function UserInfoUIGIP() {
		_super.call(this);
		this.skinParts = ["bg","close","txt1","nickname","txt2","time","txt3","who","txt4","invitation","exit","copy_btn"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this.bg_i(),this._Image1_i(),this.close_i(),this._Image3_i(),this._Image4_i(),this.txt1_i(),this.nickname_i(),this.txt2_i(),this.time_i(),this.txt3_i(),this.who_i(),this.txt4_i(),this.invitation_i(),this.exit_i(),this.copy_btn_i()];
	}
	var _proto = UserInfoUIGIP.prototype;

	_proto.bg_i = function () {
		var t = new eui.Rect();
		this.bg = t;
		t.bottom = 0;
		t.fillAlpha = 0.1;
		t.fillColor = 0xFFFFFF;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.anchorOffsetY = 0;
		t.height = 829;
		t.horizontalCenter = 0;
		t.source = "tool_alert_bg_gip_png";
		t.y = 34.49;
		return t;
	};
	_proto.close_i = function () {
		var t = new eui.Group();
		this.close = t;
		t.height = 80;
		t.width = 80;
		t.x = 625;
		t.y = 52.93;
		t.elementsContent = [this._Rect1_i(),this._Image2_i()];
		return t;
	};
	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillColor = 0xFFFFFF;
		t.height = 80;
		t.width = 80;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "icon_close_u2_png";
		t.verticalCenter = 0;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "icon_heard_node_png";
		t.y = 117;
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "nav_line_png";
		t.y = 790;
		return t;
	};
	_proto.txt1_i = function () {
		var t = new eui.Label();
		this.txt1 = t;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.horizontalCenter = 0.5;
		t.size = 16;
		t.text = "NICK NAME";
		t.textColor = 0x4C6CA5;
		t.y = 270.29;
		return t;
	};
	_proto.nickname_i = function () {
		var t = new eui.Label();
		this.nickname = t;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.horizontalCenter = 0.5;
		t.size = 22;
		t.text = "dear";
		t.textColor = 0x4C6CA5;
		t.y = 290.29;
		return t;
	};
	_proto.txt2_i = function () {
		var t = new eui.Label();
		this.txt2 = t;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.horizontalCenter = 0;
		t.size = 16;
		t.text = "SINGUP TIME";
		t.textColor = 0x4C6CA5;
		t.y = 367.29;
		return t;
	};
	_proto.time_i = function () {
		var t = new eui.Label();
		this.time = t;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.horizontalCenter = 0;
		t.size = 24;
		t.text = "2019-10-29";
		t.textColor = 0x4C6CA5;
		t.y = 394.29;
		return t;
	};
	_proto.txt3_i = function () {
		var t = new eui.Label();
		this.txt3 = t;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.horizontalCenter = 0;
		t.size = 16;
		t.text = "WHO INVITED ME";
		t.textColor = 0x4C6CA5;
		t.y = 468.29;
		return t;
	};
	_proto.who_i = function () {
		var t = new eui.Label();
		this.who = t;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.horizontalCenter = 0;
		t.size = 24;
		t.text = "WHO";
		t.textColor = 0x4C6CA5;
		t.y = 496.29;
		return t;
	};
	_proto.txt4_i = function () {
		var t = new eui.Label();
		this.txt4 = t;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.horizontalCenter = 0.5;
		t.size = 16;
		t.text = "REFERRAL CODE";
		t.textColor = 0x4C6CA5;
		t.y = 565.63;
		return t;
	};
	_proto.invitation_i = function () {
		var t = new eui.Label();
		this.invitation = t;
		t.anchorOffsetX = 0;
		t.bold = true;
		t.horizontalCenter = 0;
		t.size = 26;
		t.text = "FIO3O5";
		t.textAlign = "center";
		t.textColor = 0x4C6CA5;
		t.width = 189.34;
		t.y = 595.63;
		return t;
	};
	_proto.exit_i = function () {
		var t = new eui.Button();
		this.exit = t;
		t.horizontalCenter = 0;
		t.label = "EXIT";
		t.y = 696;
		t.skinName = UserInfoUIGIP$Skin35;
		return t;
	};
	_proto.copy_btn_i = function () {
		var t = new eui.Group();
		this.copy_btn = t;
		t.x = 439.99;
		t.y = 574.97;
		t.elementsContent = [this._Image5_i(),this._Rect2_i()];
		return t;
	};
	_proto._Image5_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "icon_copy2_png";
		t.verticalCenter = 0;
		return t;
	};
	_proto._Rect2_i = function () {
		var t = new eui.Rect();
		t.fillAlpha = 0.05;
		t.fillColor = 0xFFFFFF;
		t.height = 60;
		t.width = 60;
		t.x = 0;
		t.y = 0;
		return t;
	};
	return UserInfoUIGIP;
})(eui.Skin);generateEUI.paths['resource/eui/UserToolUIGIP.exml'] = window.UserToolUIGIP = (function (_super) {
	__extends(UserToolUIGIP, _super);
	function UserToolUIGIP() {
		_super.call(this);
		this.skinParts = ["txt","account"];
		
		this.height = 70;
		this.width = 587;
		this.elementsContent = [this._Rect1_i(),this._Image1_i(),this.txt_i(),this._Image2_i(),this.account_i()];
	}
	var _proto = UserToolUIGIP.prototype;

	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.ellipseHeight = 70;
		t.ellipseWidth = 70;
		t.fillColor = 0x50C9C6;
		t.height = 61;
		t.right = 2;
		t.width = 395;
		t.y = 7;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.bottom = 0;
		t.left = 0;
		t.source = "user_icon_gip_png";
		return t;
	};
	_proto.txt_i = function () {
		var t = new eui.Label();
		this.txt = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolk";
		t.height = 36;
		t.multiline = false;
		t.size = 24;
		t.text = "dear";
		t.textColor = 0x51cac9;
		t.verticalAlign = "middle";
		t.verticalCenter = 1;
		t.width = 141;
		t.x = 97;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.right = 307;
		t.source = "user_icon_heard_png";
		t.verticalCenter = 3;
		return t;
	};
	_proto.account_i = function () {
		var t = new eui.Label();
		this.account = t;
		t.anchorOffsetX = 0;
		t.fontFamily = "norfolk";
		t.multiline = false;
		t.size = 24;
		t.text = "dear";
		t.textColor = 0xffffff;
		t.x = 289;
		t.y = 21;
		return t;
	};
	return UserToolUIGIP;
})(eui.Skin);generateEUI.paths['resource/eui/voteHView.exml'] = window.voteHView = (function (_super) {
	__extends(voteHView, _super);
	function voteHView() {
		_super.call(this);
		this.skinParts = ["back","title","group","list","loadingImg"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this._Image1_i(),this.back_i(),this._Group1_i(),this.list_i(),this.loadingImg_i()];
	}
	var _proto = voteHView.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.left = 0;
		t.source = "vote_bg_png";
		t.top = 0;
		return t;
	};
	_proto.back_i = function () {
		var t = new eui.Component();
		this.back = t;
		t.skinName = "BackBtn";
		t.x = 0;
		t.y = 27;
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 75;
		t.horizontalCenter = 0;
		t.width = 58;
		t.y = 28;
		t.elementsContent = [this.title_i()];
		return t;
	};
	_proto.title_i = function () {
		var t = new eui.Image();
		this.title = t;
		t.horizontalCenter = 0;
		t.source = "vote_h_title_en_png";
		t.verticalCenter = 0;
		return t;
	};
	_proto.list_i = function () {
		var t = new eui.Scroller();
		this.list = t;
		t.anchorOffsetY = 0;
		t.bottom = 30;
		t.left = 0;
		t.right = 0;
		t.top = 130;
		t.viewport = this.group_i();
		return t;
	};
	_proto.group_i = function () {
		var t = new eui.Group();
		this.group = t;
		return t;
	};
	_proto.loadingImg_i = function () {
		var t = new eui.Image();
		this.loadingImg = t;
		t.anchorOffsetX = 25;
		t.anchorOffsetY = 26;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "tool_loading_png";
		t.y = 229;
		return t;
	};
	return voteHView;
})(eui.Skin);generateEUI.paths['resource/eui/voteListA.exml'] = window.voteListA = (function (_super) {
	__extends(voteListA, _super);
	function voteListA() {
		_super.call(this);
		this.skinParts = ["btn","num1","num2","icon","imask","num3"];
		
		this.height = 136;
		this.width = 346;
		this.elementsContent = [this._Image1_i(),this.btn_i(),this.num1_i(),this._Image2_i(),this.num2_i(),this._Image3_i(),this.icon_i(),this.imask_i(),this.num3_i()];
	}
	var _proto = voteListA.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.left = 0;
		t.source = "vote_listbg_img1_png";
		t.top = 0;
		t.touchEnabled = false;
		return t;
	};
	_proto.btn_i = function () {
		var t = new eui.Button();
		this.btn = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 42;
		t.label = "Vote";
		t.name = "vote55";
		t.skinName = "skins.MyButton3Skin";
		t.width = 106;
		t.x = 215.67;
		t.y = 73;
		return t;
	};
	_proto.num1_i = function () {
		var t = new eui.Label();
		this.num1 = t;
		t.anchorOffsetX = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.size = 26;
		t.text = "00";
		t.textAlign = "left";
		t.width = 48.67;
		t.x = 8.99;
		t.y = 9;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.source = "icon_certificate_min_png";
		t.touchEnabled = false;
		t.x = 217.67;
		t.y = 24;
		return t;
	};
	_proto.num2_i = function () {
		var t = new eui.Label();
		this.num2 = t;
		t.anchorOffsetX = 0;
		t.bold = true;
		t.fontFamily = "norfolkBold";
		t.size = 28;
		t.text = "0";
		t.textAlign = "left";
		t.textColor = 0xfe9601;
		t.touchEnabled = false;
		t.verticalAlign = "bottom";
		t.width = 144;
		t.x = 257.47;
		t.y = 25.99;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.height = 70;
		t.source = "vote_head_icon_max_png";
		t.touchEnabled = false;
		t.verticalCenter = 0;
		t.width = 70;
		t.x = 27;
		return t;
	};
	_proto.icon_i = function () {
		var t = new eui.Image();
		this.icon = t;
		t.height = 50;
		t.mask = this.imask;
		t.source = "logo_png";
		t.touchEnabled = false;
		t.verticalCenter = 0;
		t.width = 50;
		t.x = 37;
		return t;
	};
	_proto.imask_i = function () {
		var t = new eui.Rect();
		this.imask = t;
		t.ellipseHeight = 50;
		t.ellipseWidth = 50;
		t.height = 50;
		t.verticalCenter = 0;
		t.width = 50;
		t.x = 37;
		if(this.icon)
		{
			this.icon.mask = this.imask;
		}
		return t;
	};
	_proto.num3_i = function () {
		var t = new eui.Label();
		this.num3 = t;
		t.anchorOffsetX = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.height = 60;
		t.size = 24;
		t.text = "";
		t.textAlign = "left";
		t.touchEnabled = false;
		t.verticalAlign = "middle";
		t.verticalCenter = 0;
		t.width = 107;
		t.x = 101.66;
		return t;
	};
	return voteListA;
})(eui.Skin);generateEUI.paths['resource/eui/voteListH.exml'] = window.voteListH = (function (_super) {
	__extends(voteListH, _super);
	function voteListH() {
		_super.call(this);
		this.skinParts = ["num2","num1","icon","imask"];
		
		this.height = 116;
		this.width = 702;
		this.elementsContent = [this._Image1_i(),this.num2_i(),this.num1_i(),this._Image2_i(),this.icon_i(),this.imask_i()];
	}
	var _proto = voteListH.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.left = 0;
		t.source = "vote_listbg_img3_png";
		t.top = 0;
		t.touchEnabled = false;
		return t;
	};
	_proto.num2_i = function () {
		var t = new eui.Label();
		this.num2 = t;
		t.anchorOffsetX = 0;
		t.bold = true;
		t.fontFamily = "norfolkBold";
		t.size = 28;
		t.text = "2020.02.10 15:35";
		t.textAlign = "right";
		t.textColor = 0xFE9601;
		t.width = 273;
		t.x = 369.5;
		t.y = 44.5;
		return t;
	};
	_proto.num1_i = function () {
		var t = new eui.Label();
		this.num1 = t;
		t.anchorOffsetX = 0;
		t.bold = true;
		t.fontFamily = "norfolkBold";
		t.size = 28;
		t.text = "";
		t.textAlign = "left";
		t.textColor = 0xFFFFFF;
		t.verticalCenter = 0;
		t.width = 246;
		t.x = 139.5;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.height = 80;
		t.source = "vote_head_icon_max_png";
		t.verticalCenter = 0;
		t.width = 80;
		t.x = 52.76;
		return t;
	};
	_proto.icon_i = function () {
		var t = new eui.Image();
		this.icon = t;
		t.height = 55;
		t.source = "logo_png";
		t.verticalCenter = 0.5;
		t.width = 55;
		t.x = 65;
		return t;
	};
	_proto.imask_i = function () {
		var t = new eui.Rect();
		this.imask = t;
		t.ellipseHeight = 55;
		t.ellipseWidth = 55;
		t.height = 55;
		t.verticalCenter = 0;
		t.width = 55;
		t.x = 65;
		return t;
	};
	return voteListH;
})(eui.Skin);generateEUI.paths['resource/eui/voteListS.exml'] = window.voteListS = (function (_super) {
	__extends(voteListS, _super);
	function voteListS() {
		_super.call(this);
		this.skinParts = ["btn","num1","num2","num3","icon","imask"];
		
		this.height = 116;
		this.width = 702;
		this.elementsContent = [this._Image1_i(),this.btn_i(),this.num1_i(),this._Image2_i(),this.num2_i(),this.num3_i(),this._Image3_i(),this.icon_i(),this.imask_i()];
	}
	var _proto = voteListS.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.left = 0;
		t.source = "vote_listbg_img2_png";
		t.top = 0;
		t.touchEnabled = false;
		return t;
	};
	_proto.btn_i = function () {
		var t = new eui.Button();
		this.btn = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 42;
		t.label = "Vote";
		t.name = "vote55";
		t.skinName = "skins.MyButton3Skin";
		t.verticalCenter = 0;
		t.width = 106;
		t.x = 551;
		return t;
	};
	_proto.num1_i = function () {
		var t = new eui.Label();
		this.num1 = t;
		t.anchorOffsetX = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.size = 26;
		t.text = "1";
		t.textAlign = "left";
		t.touchEnabled = false;
		t.width = 65;
		t.x = 7;
		t.y = 9;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.source = "icon_certificate_min_png";
		t.touchEnabled = false;
		t.x = 358;
		t.y = 40.5;
		return t;
	};
	_proto.num2_i = function () {
		var t = new eui.Label();
		this.num2 = t;
		t.anchorOffsetX = 0;
		t.bold = true;
		t.fontFamily = "norfolkBold";
		t.height = 30;
		t.size = 26;
		t.text = "0";
		t.textAlign = "left";
		t.textColor = 0xFE9601;
		t.touchEnabled = false;
		t.verticalAlign = "bottom";
		t.width = 171;
		t.x = 394.5;
		t.y = 39.5;
		return t;
	};
	_proto.num3_i = function () {
		var t = new eui.Label();
		this.num3 = t;
		t.anchorOffsetX = 0;
		t.bold = true;
		t.fontFamily = "norfolkBold";
		t.height = 30;
		t.size = 28;
		t.text = "0";
		t.textAlign = "left";
		t.textColor = 0xffffff;
		t.touchEnabled = false;
		t.verticalCenter = 0;
		t.width = 224;
		t.x = 131.5;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.height = 70;
		t.source = "vote_head_icon_max_png";
		t.touchEnabled = false;
		t.verticalCenter = 0;
		t.width = 70;
		t.x = 53;
		return t;
	};
	_proto.icon_i = function () {
		var t = new eui.Image();
		this.icon = t;
		t.height = 50;
		t.mask = this.imask;
		t.source = "logo_png";
		t.touchEnabled = false;
		t.verticalCenter = 0;
		t.width = 50;
		t.x = 63;
		return t;
	};
	_proto.imask_i = function () {
		var t = new eui.Rect();
		this.imask = t;
		t.ellipseHeight = 50;
		t.ellipseWidth = 50;
		t.height = 50;
		t.verticalCenter = 0;
		t.width = 50;
		t.x = 63;
		if(this.icon)
		{
			this.icon.mask = this.imask;
		}
		return t;
	};
	return voteListS;
})(eui.Skin);generateEUI.paths['resource/eui/voteSureUi.exml'] = window.voteSureUi = (function (_super) {
	__extends(voteSureUi, _super);
	function voteSureUi() {
		_super.call(this);
		this.skinParts = ["btn","txt1","txt2","icon","imask","txt3","successPane","loadingImg","btnComfirmGroup","close"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this._Rect1_i(),this._Image1_i(),this.btn_i(),this.txt1_i(),this.txt2_i(),this._Image2_i(),this.icon_i(),this.imask_i(),this.successPane_i(),this.btnComfirmGroup_i(),this.close_i()];
	}
	var _proto = voteSureUi.prototype;

	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.bottom = 0;
		t.fillAlpha = 0.92;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "vote_tj_frame_bg_png";
		t.y = 150;
		return t;
	};
	_proto.btn_i = function () {
		var t = new eui.Button();
		this.btn = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 42;
		t.horizontalCenter = 0;
		t.label = "Vote";
		t.name = "vote55";
		t.skinName = "skins.MyButton3Skin";
		t.width = 123;
		t.y = 765;
		return t;
	};
	_proto.txt1_i = function () {
		var t = new eui.Image();
		this.txt1 = t;
		t.horizontalCenter = 0;
		t.source = "vote_tp_txt1_ko_png";
		t.y = 197;
		return t;
	};
	_proto.txt2_i = function () {
		var t = new eui.Label();
		this.txt2 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.height = 62;
		t.horizontalCenter = 0;
		t.size = 26;
		t.text = "Contact us:";
		t.textAlign = "center";
		t.width = 420;
		t.y = 537.34;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.height = 76;
		t.horizontalCenter = 0;
		t.source = "vote_head_icon_max_png";
		t.width = 76;
		t.y = 629;
		return t;
	};
	_proto.icon_i = function () {
		var t = new eui.Image();
		this.icon = t;
		t.height = 55;
		t.horizontalCenter = 0.5;
		t.mask = this.imask;
		t.source = "logo_png";
		t.width = 55;
		t.y = 639;
		return t;
	};
	_proto.imask_i = function () {
		var t = new eui.Rect();
		this.imask = t;
		t.ellipseHeight = 55;
		t.ellipseWidth = 55;
		t.height = 55;
		t.horizontalCenter = 0;
		t.width = 55;
		t.y = 639;
		if(this.icon)
		{
			this.icon.mask = this.imask;
		}
		return t;
	};
	_proto.successPane_i = function () {
		var t = new eui.Group();
		this.successPane = t;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.visible = false;
		t.elementsContent = [this._Rect2_i(),this._Image3_i(),this._Image4_i(),this.txt3_i()];
		return t;
	};
	_proto._Rect2_i = function () {
		var t = new eui.Rect();
		t.bottom = 0;
		t.fillAlpha = 0.6;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.source = "vote_tp_msgbg_png";
		t.x = 24;
		t.y = 401.92;
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.source = "vote_tp_msg_statu_png";
		t.x = 121;
		t.y = 450.16;
		return t;
	};
	_proto.txt3_i = function () {
		var t = new eui.Image();
		this.txt3 = t;
		t.anchorOffsetX = 0;
		t.horizontalCenter = 50;
		t.source = "vote_tp_msgI_statu_ja_png";
		t.y = 467.16;
		return t;
	};
	_proto.btnComfirmGroup_i = function () {
		var t = new eui.Group();
		this.btnComfirmGroup = t;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.visible = false;
		t.y = 765;
		t.elementsContent = [this._Rect3_i(),this.loadingImg_i()];
		return t;
	};
	_proto._Rect3_i = function () {
		var t = new eui.Rect();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.ellipseHeight = 42;
		t.ellipseWidth = 42;
		t.fillColor = 0xbfbfbf;
		t.height = 42;
		t.width = 123;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.loadingImg_i = function () {
		var t = new eui.Image();
		this.loadingImg = t;
		t.anchorOffsetX = 25;
		t.anchorOffsetY = 26;
		t.horizontalCenter = 0;
		t.scaleX = 0.6;
		t.scaleY = 0.6;
		t.source = "tool_loading_png";
		t.verticalCenter = 0;
		return t;
	};
	_proto.close_i = function () {
		var t = new eui.Image();
		this.close = t;
		t.horizontalCenter = 312;
		t.source = "icon_vote_close_png";
		t.x = 649.63;
		t.y = 69.16;
		return t;
	};
	return voteSureUi;
})(eui.Skin);generateEUI.paths['resource/eui/voteTJUi.exml'] = window.voteTJUi = (function (_super) {
	__extends(voteTJUi, _super);
	function voteTJUi() {
		_super.call(this);
		this.skinParts = ["txt1","txt2","txt3","close"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this._Rect1_i(),this._Image1_i(),this.txt1_i(),this.txt2_i(),this.txt3_i(),this._Label1_i(),this.close_i()];
	}
	var _proto = voteTJUi.prototype;

	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.bottom = 0;
		t.fillAlpha = 0.92;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "vote_tp_frame__png";
		t.y = 150;
		return t;
	};
	_proto.txt1_i = function () {
		var t = new eui.Image();
		this.txt1 = t;
		t.horizontalCenter = 0;
		t.source = "vote_tj_img1_ch_png";
		t.y = 197;
		return t;
	};
	_proto.txt2_i = function () {
		var t = new eui.Image();
		this.txt2 = t;
		t.horizontalCenter = 0;
		t.source = "vote_tj_img2_ch_png";
		t.y = 391;
		return t;
	};
	_proto.txt3_i = function () {
		var t = new eui.Label();
		this.txt3 = t;
		t.anchorOffsetX = 0;
		t.size = 26;
		t.text = "Contact us:";
		t.width = 432;
		t.x = 58;
		t.y = 699.34;
		return t;
	};
	_proto._Label1_i = function () {
		var t = new eui.Label();
		t.fontFamily = "norfolk";
		t.size = 26;
		t.text = "greenlightofficial5@gmail.com";
		t.x = 58;
		t.y = 742.05;
		return t;
	};
	_proto.close_i = function () {
		var t = new eui.Image();
		this.close = t;
		t.source = "icon_vote_close_png";
		t.x = 649.63;
		t.y = 58.73;
		return t;
	};
	return voteTJUi;
})(eui.Skin);generateEUI.paths['resource/eui/VoteView.exml'] = window.VoteView = (function (_super) {
	__extends(VoteView, _super);
	function VoteView() {
		_super.call(this);
		this.skinParts = ["back","record_btn","title","tj_txt","tj_btn","clear_btn","list_bg","vote_title_img","vote_title_t1","vote_title_t2","p2","p1","p3","icon1","imask1","icon2","imask2","icon3","imask3","group","list"];
		
		this.height = 1514.91;
		this.width = 750;
		this.elementsContent = [this._Image1_i(),this.back_i(),this.record_btn_i(),this.title_i(),this.tj_btn_i(),this.clear_btn_i(),this.list_i()];
	}
	var _proto = VoteView.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.left = 0;
		t.source = "vote_bg_png";
		t.top = 0;
		return t;
	};
	_proto.back_i = function () {
		var t = new eui.Component();
		this.back = t;
		t.skinName = "BackBtn";
		t.x = 0;
		t.y = 30.24;
		return t;
	};
	_proto.record_btn_i = function () {
		var t = new eui.Image();
		this.record_btn = t;
		t.source = "vote_icon_img1_png";
		t.x = 673.64;
		t.y = 148;
		return t;
	};
	_proto.title_i = function () {
		var t = new eui.Label();
		this.title = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolkBold";
		t.horizontalCenter = -0.5;
		t.lineSpacing = 6;
		t.size = 48;
		t.text = "Vote";
		t.textAlign = "center";
		t.textColor = 0xfe9601;
		t.verticalAlign = "middle";
		t.width = 591.34;
		t.y = 44.8;
		return t;
	};
	_proto.tj_btn_i = function () {
		var t = new eui.Group();
		this.tj_btn = t;
		t.x = 496;
		t.y = 51.71;
		t.elementsContent = [this._Image2_i(),this.tj_txt_i()];
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.source = "vote_icon_img2_png";
		t.x = 188;
		t.y = 0;
		return t;
	};
	_proto.tj_txt_i = function () {
		var t = new eui.Label();
		this.tj_txt = t;
		t.anchorOffsetX = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.size = 24;
		t.text = "Recomamend";
		t.textAlign = "right";
		t.verticalAlign = "bottom";
		t.width = 178;
		t.x = 0;
		t.y = 6.53;
		return t;
	};
	_proto.clear_btn_i = function () {
		var t = new eui.Button();
		this.clear_btn = t;
		t.label = "Clear";
		t.skinName = "skins.MyButton3Skin";
		t.x = 552.79;
		t.y = 143.44;
		return t;
	};
	_proto.list_i = function () {
		var t = new eui.Scroller();
		this.list = t;
		t.anchorOffsetY = 0;
		t.bottom = 40;
		t.left = 0;
		t.right = 0;
		t.top = 214;
		t.viewport = this.group_i();
		return t;
	};
	_proto.group_i = function () {
		var t = new eui.Group();
		this.group = t;
		t.elementsContent = [this.list_bg_i(),this._Group1_i(),this._Image3_i(),this._Image4_i(),this._Image5_i(),this.p2_i(),this.p1_i(),this.p3_i(),this.icon1_i(),this.imask1_i(),this.icon2_i(),this.imask2_i(),this.icon3_i(),this.imask3_i()];
		return t;
	};
	_proto.list_bg_i = function () {
		var t = new eui.Rect();
		this.list_bg = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 20;
		t.width = 1;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.touchEnabled = false;
		t.x = 22.000000000000004;
		t.y = 2.759999999999991;
		t.elementsContent = [this.vote_title_img_i(),this.vote_title_t1_i(),this.vote_title_t2_i()];
		return t;
	};
	_proto.vote_title_img_i = function () {
		var t = new eui.Image();
		this.vote_title_img = t;
		t.source = "vote_titlebg_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.vote_title_t1_i = function () {
		var t = new eui.Label();
		this.vote_title_t1 = t;
		t.anchorOffsetX = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.height = 130;
		t.size = 60;
		t.text = "Which exchange \n GL will launch on ";
		t.textAlign = "center";
		t.textColor = 0xfe9601;
		t.verticalAlign = "middle";
		t.visible = false;
		t.width = 651;
		t.x = 28;
		t.y = 32;
		return t;
	};
	_proto.vote_title_t2_i = function () {
		var t = new eui.Label();
		this.vote_title_t2 = t;
		t.anchorOffsetX = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.size = 24;
		t.text = "Community voting";
		t.textAlign = "center";
		t.visible = false;
		t.width = 651;
		t.x = 28;
		t.y = 166;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "vote_rank1_png";
		t.touchEnabled = false;
		t.x = 287;
		t.y = 231.76000000000005;
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "vote_rank2_png";
		t.touchEnabled = false;
		t.x = 85;
		t.y = 285.76000000000005;
		return t;
	};
	_proto._Image5_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "vote_rank3_png";
		t.touchEnabled = false;
		t.x = 529.0000000000001;
		t.y = 284.76;
		return t;
	};
	_proto.p2_i = function () {
		var t = new eui.Component();
		this.p2 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 180;
		t.scaleX = 1;
		t.scaleY = 1;
		t.skinName = "bzItem";
		t.width = 250;
		t.x = 28;
		t.y = 470.76;
		return t;
	};
	_proto.p1_i = function () {
		var t = new eui.Component();
		this.p1 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 180;
		t.scaleX = 1;
		t.scaleY = 1;
		t.skinName = "bzItem";
		t.width = 250;
		t.x = 250;
		t.y = 470.76;
		return t;
	};
	_proto.p3_i = function () {
		var t = new eui.Component();
		this.p3 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 180;
		t.scaleX = 1;
		t.scaleY = 1;
		t.skinName = "bzItem";
		t.width = 250;
		t.x = 472.00000000000006;
		t.y = 470.76;
		return t;
	};
	_proto.icon1_i = function () {
		var t = new eui.Image();
		this.icon1 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 130;
		t.mask = this.imask1;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "logo_png";
		t.width = 130;
		t.x = 309;
		t.y = 308.76;
		return t;
	};
	_proto.imask1_i = function () {
		var t = new eui.Rect();
		this.imask1 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.ellipseHeight = 130;
		t.ellipseWidth = 130;
		t.height = 130;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 130;
		t.x = 309;
		t.y = 308.76;
		if(this.icon1)
		{
			this.icon1.mask = this.imask1;
		}
		return t;
	};
	_proto.icon2_i = function () {
		var t = new eui.Image();
		this.icon2 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 100;
		t.mask = this.imask2;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "logo_png";
		t.width = 100;
		t.x = 103;
		t.y = 341.76;
		return t;
	};
	_proto.imask2_i = function () {
		var t = new eui.Rect();
		this.imask2 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.ellipseHeight = 100;
		t.ellipseWidth = 100;
		t.height = 100;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 100;
		t.x = 103;
		t.y = 341.76;
		if(this.icon2)
		{
			this.icon2.mask = this.imask2;
		}
		return t;
	};
	_proto.icon3_i = function () {
		var t = new eui.Image();
		this.icon3 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 100;
		t.mask = this.imask3;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "logo_png";
		t.width = 100;
		t.x = 547;
		t.y = 341.76;
		return t;
	};
	_proto.imask3_i = function () {
		var t = new eui.Rect();
		this.imask3 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.ellipseHeight = 100;
		t.ellipseWidth = 100;
		t.height = 100;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 100;
		t.x = 547;
		t.y = 341.76;
		if(this.icon3)
		{
			this.icon3.mask = this.imask3;
		}
		return t;
	};
	return VoteView;
})(eui.Skin);generateEUI.paths['resource/eui/WalletHistoryItem.exml'] = window.WalletHistoryItem = (function (_super) {
	__extends(WalletHistoryItem, _super);
	function WalletHistoryItem() {
		_super.call(this);
		this.skinParts = ["t1","t_num","t2","t_time","t3","t_address"];
		
		this.height = 245;
		this.width = 750;
		this.elementsContent = [this._Image1_i(),this._Image2_i(),this.t1_i(),this.t_num_i(),this.t2_i(),this.t_time_i(),this.t3_i(),this.t_address_i(),this._Label1_i()];
	}
	var _proto = WalletHistoryItem.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "wallet_list_bg_png";
		t.top = 0;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.source = "icon_imgw_eth_png";
		t.x = 59.8;
		t.y = 16.8;
		return t;
	};
	_proto.t1_i = function () {
		var t = new eui.Label();
		this.t1 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolkBold";
		t.left = 209;
		t.lineSpacing = 6;
		t.size = 24;
		t.text = "充币数量：";
		t.textAlign = "left";
		t.textColor = 0x375591;
		t.top = 63;
		t.verticalAlign = "top";
		return t;
	};
	_proto.t_num_i = function () {
		var t = new eui.Label();
		this.t_num = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolkBold";
		t.left = 209;
		t.lineSpacing = 6;
		t.size = 24;
		t.text = "0.00";
		t.textAlign = "left";
		t.textColor = 0x8c8c8c;
		t.top = 94;
		t.verticalAlign = "top";
		t.width = 230;
		return t;
	};
	_proto.t2_i = function () {
		var t = new eui.Label();
		this.t2 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolkBold";
		t.left = 466;
		t.lineSpacing = 6;
		t.size = 24;
		t.text = "更新时间：";
		t.textAlign = "left";
		t.textColor = 0x375591;
		t.top = 63;
		t.verticalAlign = "top";
		return t;
	};
	_proto.t_time_i = function () {
		var t = new eui.Label();
		this.t_time = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolkBold";
		t.left = 466;
		t.lineSpacing = 6;
		t.size = 24;
		t.text = "";
		t.textAlign = "left";
		t.textColor = 0x8C8C8C;
		t.top = 94;
		t.verticalAlign = "top";
		t.width = 242;
		return t;
	};
	_proto.t3_i = function () {
		var t = new eui.Label();
		this.t3 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolkBold";
		t.left = 209;
		t.lineSpacing = 6;
		t.size = 24;
		t.text = "充币地址： ";
		t.textAlign = "left";
		t.textColor = 0x375591;
		t.top = 133;
		t.verticalAlign = "top";
		return t;
	};
	_proto.t_address_i = function () {
		var t = new eui.Label();
		this.t_address = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolkBold";
		t.left = 209;
		t.lineSpacing = 6;
		t.size = 24;
		t.text = "";
		t.textAlign = "left";
		t.textColor = 0x8C8C8C;
		t.top = 164;
		t.verticalAlign = "top";
		t.width = 383;
		return t;
	};
	_proto._Label1_i = function () {
		var t = new eui.Label();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolkBold";
		t.left = 49;
		t.lineSpacing = 6;
		t.size = 30;
		t.text = "ETH";
		t.textAlign = "center";
		t.textColor = 0x375591;
		t.top = 99;
		t.verticalAlign = "top";
		t.width = 83;
		return t;
	};
	return WalletHistoryItem;
})(eui.Skin);generateEUI.paths['resource/eui/WalletHistoryUi.exml'] = window.WalletHistoryUi = (function (_super) {
	__extends(WalletHistoryUi, _super);
	function WalletHistoryUi() {
		_super.call(this);
		this.skinParts = ["back","title","group","list","loadingImg"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this._Rect1_i(),this.back_i(),this.title_i(),this.list_i(),this.loadingImg_i()];
	}
	var _proto = WalletHistoryUi.prototype;

	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.bottom = 0;
		t.fillColor = 0xFFFFFF;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto.back_i = function () {
		var t = new eui.Component();
		this.back = t;
		t.skinName = "BackBtn";
		t.x = 0;
		t.y = 39.8;
		return t;
	};
	_proto.title_i = function () {
		var t = new eui.Label();
		this.title = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolkBold";
		t.horizontalCenter = -0.5;
		t.lineSpacing = 6;
		t.size = 48;
		t.text = "Vote";
		t.textAlign = "center";
		t.textColor = 0x375591;
		t.verticalAlign = "middle";
		t.width = 591.34;
		t.y = 44.8;
		return t;
	};
	_proto.list_i = function () {
		var t = new eui.Scroller();
		this.list = t;
		t.anchorOffsetY = 0;
		t.bottom = 35;
		t.left = 0;
		t.right = 0;
		t.top = 132;
		t.viewport = this.group_i();
		return t;
	};
	_proto.group_i = function () {
		var t = new eui.Group();
		this.group = t;
		return t;
	};
	_proto.loadingImg_i = function () {
		var t = new eui.Image();
		this.loadingImg = t;
		t.anchorOffsetX = 25;
		t.anchorOffsetY = 26;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "tool_loading_h_png";
		t.y = 229;
		return t;
	};
	return WalletHistoryUi;
})(eui.Skin);generateEUI.paths['resource/eui/WalletView.exml'] = window.WalletView = (function (_super) {
	__extends(WalletView, _super);
	var WalletView$Skin36 = 	(function (_super) {
		__extends(WalletView$Skin36, _super);
		function WalletView$Skin36() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","wallet_btn_bg_png"),
						new eui.SetProperty("_Image1","alpha",0.7),
						new eui.SetProperty("labelDisplay","textColor",0xdfdfdf)
					])
				,
				new eui.State ("disabled",
					[
						new eui.SetProperty("_Image1","source","wallet_btn_bg_png")
					])
			];
		}
		var _proto = WalletView$Skin36.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.percentHeight = 100;
			t.source = "wallet_btn_bg_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.fontFamily = "norfolk";
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return WalletView$Skin36;
	})(eui.Skin);

	var WalletView$Skin37 = 	(function (_super) {
		__extends(WalletView$Skin37, _super);
		function WalletView$Skin37() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","wallet_btn_bg_png"),
						new eui.SetProperty("_Image1","alpha",0.1)
					])
				,
				new eui.State ("disabled",
					[
						new eui.SetProperty("_Image1","source","wallet_btn_bg_png")
					])
			];
		}
		var _proto = WalletView$Skin37.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.percentHeight = 100;
			t.scale9Grid = new egret.Rectangle(19,14,507,52);
			t.source = "wallet_btn_bg_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.fontFamily = "norfolk";
			t.horizontalCenter = 0;
			t.textColor = 0xdfdfdf;
			t.verticalCenter = 0;
			return t;
		};
		return WalletView$Skin37;
	})(eui.Skin);

	var WalletView$Skin38 = 	(function (_super) {
		__extends(WalletView$Skin38, _super);
		function WalletView$Skin38() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","icon_imgw_copy_png"),
						new eui.SetProperty("_Image1","alpha",0.6)
					])
				,
				new eui.State ("disabled",
					[
						new eui.SetProperty("_Image1","source","icon_imgw_copy_png")
					])
			];
		}
		var _proto = WalletView$Skin38.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.percentHeight = 100;
			t.source = "icon_imgw_copy_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return WalletView$Skin38;
	})(eui.Skin);

	function WalletView() {
		_super.call(this);
		this.skinParts = ["back","history_btn","title","btn1","btn2","total_num","qrImg","t2","t_address","btn3","t4","msg","loadingImg"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this._Rect1_i(),this.back_i(),this.history_btn_i(),this.title_i(),this.btn1_i(),this.btn2_i(),this._Image1_i(),this._Label1_i(),this._Label2_i(),this.total_num_i(),this._Image2_i(),this.qrImg_i(),this.t2_i(),this.t_address_i(),this.btn3_i(),this.t4_i(),this.msg_i(),this._Image3_i(),this.loadingImg_i()];
	}
	var _proto = WalletView.prototype;

	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.bottom = 0;
		t.fillColor = 0xffffff;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto.back_i = function () {
		var t = new eui.Component();
		this.back = t;
		t.skinName = "BackBtn";
		t.x = 0;
		t.y = 25.24;
		return t;
	};
	_proto.history_btn_i = function () {
		var t = new eui.Image();
		this.history_btn = t;
		t.right = 32;
		t.source = "icon_imgw_history_png";
		t.y = 46.12;
		return t;
	};
	_proto.title_i = function () {
		var t = new eui.Label();
		this.title = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolkBold";
		t.horizontalCenter = -0.5;
		t.lineSpacing = 6;
		t.size = 48;
		t.text = "Vote";
		t.textAlign = "center";
		t.textColor = 0x375591;
		t.verticalAlign = "middle";
		t.width = 591.34;
		t.y = 39.8;
		return t;
	};
	_proto.btn1_i = function () {
		var t = new eui.Button();
		this.btn1 = t;
		t.label = "充币";
		t.x = 25.34;
		t.y = 159;
		t.skinName = WalletView$Skin36;
		return t;
	};
	_proto.btn2_i = function () {
		var t = new eui.Button();
		this.btn2 = t;
		t.anchorOffsetX = 0;
		t.currentState = "down";
		t.label = "提币";
		t.width = 174;
		t.x = 551.1;
		t.y = 159;
		t.skinName = WalletView$Skin37;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.source = "wallet_item_bg_png";
		t.x = 27.28;
		t.y = 316;
		return t;
	};
	_proto._Label1_i = function () {
		var t = new eui.Label();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolkBold";
		t.lineSpacing = 6;
		t.size = 30;
		t.text = "ETH";
		t.textAlign = "left";
		t.textColor = 0xffffff;
		t.verticalAlign = "top";
		t.x = 144;
		t.y = 379;
		return t;
	};
	_proto._Label2_i = function () {
		var t = new eui.Label();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolkBold";
		t.lineSpacing = 6;
		t.size = 30;
		t.text = "ETH";
		t.textAlign = "left";
		t.textColor = 0xFFFFFF;
		t.verticalAlign = "top";
		t.x = 144;
		t.y = 379;
		return t;
	};
	_proto.total_num_i = function () {
		var t = new eui.Label();
		this.total_num = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolk";
		t.lineSpacing = 6;
		t.size = 36;
		t.text = " ";
		t.textAlign = "right";
		t.textColor = 0xFFFFFF;
		t.verticalAlign = "top";
		t.width = 483.33;
		t.x = 47;
		t.y = 480;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.height = 190;
		t.source = "wallet_rect1_png";
		t.x = 218.35;
		t.y = 624;
		return t;
	};
	_proto.qrImg_i = function () {
		var t = new eui.Image();
		this.qrImg = t;
		t.anchorOffsetX = 95;
		t.anchorOffsetY = 95;
		t.height = 190;
		t.scale9Grid = new egret.Rectangle(24,22,459,136);
		t.source = "wallet_rect1_png";
		t.width = 190;
		t.x = 116.25;
		t.y = 719.36;
		return t;
	};
	_proto.t2_i = function () {
		var t = new eui.Label();
		this.t2 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolkBold";
		t.lineSpacing = 6;
		t.size = 30;
		t.text = "";
		t.textAlign = "left";
		t.textColor = 0x375591;
		t.verticalAlign = "top";
		t.x = 248;
		t.y = 649.99;
		return t;
	};
	_proto.t_address_i = function () {
		var t = new eui.Label();
		this.t_address = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 65.34;
		t.lineSpacing = 8;
		t.size = 26;
		t.text = " ";
		t.textAlign = "left";
		t.textColor = 0x375591;
		t.verticalAlign = "top";
		t.width = 386;
		t.x = 248;
		t.y = 714.28;
		return t;
	};
	_proto.btn3_i = function () {
		var t = new eui.Button();
		this.btn3 = t;
		t.label = "";
		t.x = 636;
		t.y = 708;
		t.skinName = WalletView$Skin38;
		return t;
	};
	_proto.t4_i = function () {
		var t = new eui.Label();
		this.t4 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "norfolkBold";
		t.left = 34;
		t.lineSpacing = 30;
		t.right = 34;
		t.size = 28;
		t.text = "注意事项：";
		t.textAlign = "left";
		t.textColor = 0x848484;
		t.verticalAlign = "top";
		t.y = 848;
		return t;
	};
	_proto.msg_i = function () {
		var t = new eui.Label();
		this.msg = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "norfolkBold";
		t.left = 34;
		t.lineSpacing = 22;
		t.right = 34;
		t.size = 28;
		t.text = "• 任何非ETH资产充值到ETH地址后不可找回\n• 使用ETH地址充币需要12个网络确认才能到账 \n• 充币最小额度";
		t.textAlign = "left";
		t.textColor = 0x848484;
		t.verticalAlign = "top";
		t.y = 918;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.source = "icon_imgw_eth_png";
		t.x = 61.73;
		t.y = 332.67;
		return t;
	};
	_proto.loadingImg_i = function () {
		var t = new eui.Image();
		this.loadingImg = t;
		t.anchorOffsetX = 25;
		t.anchorOffsetY = 26;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "tool_loading_h_png";
		t.y = 122;
		return t;
	};
	return WalletView;
})(eui.Skin);generateEUI.paths['resource/eui/WhitePage.exml'] = window.WhitePage = (function (_super) {
	__extends(WhitePage, _super);
	function WhitePage() {
		_super.call(this);
		this.skinParts = ["groupc","back"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this._Rect1_i(),this._Scroller1_i(),this.back_i()];
	}
	var _proto = WhitePage.prototype;

	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.bottom = 0;
		t.fillColor = 0x000000;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto._Scroller1_i = function () {
		var t = new eui.Scroller();
		t.anchorOffsetY = 0;
		t.bottom = 12;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.viewport = this.groupc_i();
		return t;
	};
	_proto.groupc_i = function () {
		var t = new eui.Group();
		this.groupc = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 325.76;
		t.width = 750;
		return t;
	};
	_proto.back_i = function () {
		var t = new eui.Group();
		this.back = t;
		t.height = 80;
		t.x = 18.03;
		t.y = 44;
		t.elementsContent = [this._Rect2_i(),this._Image1_i()];
		return t;
	};
	_proto._Rect2_i = function () {
		var t = new eui.Rect();
		t.fillAlpha = 0.001;
		t.fillColor = 0xFFFFFF;
		t.height = 80;
		t.width = 80;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "icon_back2_png";
		t.verticalCenter = 0;
		return t;
	};
	return WhitePage;
})(eui.Skin);